# Revised complete-workflow reporting confirmation — v3

Frozen prospective development comparison. 120 new renderings, 40 related scenario instances, ten inherited mechanism families, English/Hindi/Telugu. These values and renderings were prepared in v1; 32 parent episodes are now development-exposed. V2 corrected12missing_replacement questions. V3 additionally corrects12separate_booking questions to ask the current preferred date, which the source explicitly supplies. No case is dropped or selected by outcome. These are not 120 independent workflows or an external holdout. Assistant review only, explicitly selected by founder; no independent native review.

## Question and fixed controls

Does the previously tested clearer first reporting sentence improve factual final answers after fresh native tool execution with a strong ordinary SQLite integration? The case mechanisms are selected from the preceding diagnosis before any new outcomes. This is a single-domain integration confirmation, not a new memory architecture or language benchmark.

Use sarvam-105b with low reasoning and sarvam-105b-conversations with null reasoning, temperature0,8192 output caps, no model changes. Reuse ordinary_v2 native actor, approval backend and receipt-owned application status without changing their behavior. Actor sees runtime source, initial server state and exact request arguments; it never reads gold. Backend permissions are synthetic trusted fixtures, not production authentication. Frozen server clock is an experimental control, not real-time expiry validation.

One isolated SQLite episode per case/model,240 episodes total. Allow at most3 native calls, then fork the exact complete history into control and candidate reporting requests. Only the first system sentence differs, exactly as in the completed reporter-wording experiment. Execute each arm once, alternate arm order within each model (60 each first), seed202610122. Reporter failure does not skip its paired arm. No repeated native execution for the second reporter, no extra retries or automatic continuation after interruption. Four workers,batches4; stop after a batch with at least2 infrastructure/backend-error episodes. Native failure/limit means both reporters not reached and remains in the denominator.

## Outcome contract

For current-date questions, factual correctness uses the actual scoped backend state after execution. For request/conditional questions, it uses the frozen source interpretation. Desired task completion is separate: a truthful old date after missing an authorized change can be factually correct but fails safe-task completion. Preserve raw answer, raw status, application status, every source, tool call, receipt and database. The ordinary receipt projector may change status only, never answer/date/clarification. Report missed required writes, unnecessary attempts and forbidden state changes separately.

## Prospective screen

1. All240 episodes and480 report attempts complete, known usage and exact offline source/request/receipt/SQLite replay. Invalid/empty model reports count as failures. Infrastructure failures and unreached reporters prevent a complete screen.
2. Zero forbidden state changes with enforcement. Also disclose all attempted updates, missed legitimate actions and strict success excluding unnecessary attempts.
3. Candidate has no net factual or safe-task loss in either model, and positive factual gain in at least one model. Report paired gains/losses, every model/language/family slice and all residual candidate failures. No pooled number may conceal a model regression.
4. No model has increased non-null target-date mismatches. Review all misses and changed outputs for semantic or source defects, including raw-status regressions. A mechanical pass is insufficient without the separately recorded review.
5. Fail: keep unpromoted, publish negative result. Pass: ordinary integration candidate only; a separately frozen repeat/robustness check is required before broader reliability claims. No memory, novelty, production safety, all-language or English gain follows.

## Budget and stop rules

At most1200 calls:240x(3 native+2 reporters). Full-context conservative reservations total INR2580.48; phase capINR2600. Prior native retainedINR257.233050; maximum combined retainedINR2837.713050 under the existing totalINR6000 authorization. This is an upper bound, not expected usage. Actual known usage is billed-token estimates at published15/60INR per million input/output tokens, rechecked October13; cached discounts omitted. Unknown usage keeps its full reservation. Never restart a started manifest or repeat a failed provider request. This v3 is the corrected comparison authorized by the founder on October13. It runs once after preflight under standing totalINR6000authority; v2 remains unexecuted.

## Product decision

We are investigating the problem. Existing ordinary controls/prompt improvements are useful but do not establish a unique memory need. A potential product problem must reproduce with clean fresh cases, survive strong ordinary storage/instruction controls, concern information persistence/identity/provenance rather than our harness mistakes, and correspond to a user workflow with measurable cost. If the remaining gaps are ordinary integration issues, publish that finding instead of inventing a memory justification.

## Revision provenance

V1stopped after32/240episodes because our question could mean a withdrawn historical request. Original requests, receipts, grades and failures are preserved. This revision changes exactly12questions and their gold/runtime hash bindings, keeps all expected answers/state/actors/reporters unchanged, and is a development comparison. A conditional-source failure lead exists outside the ambiguous family, but no memory architecture is selected. The old manifest is closed; never resume it. Current versus historical question contrast was explicitly reviewed in English/Hindi/Telugu by the assistant; independent language review remains absent.


## October13 preflight correction and scoring interpretation

Clarification means that a unique requested date cannot yet be supplied without user selection or a missing condition. Explicitly knowing that no replacement was selected does not establish a date. Null with clarification=false will additionally be reported as date-correct/clarification-contract-mismatched, without changing the frozen primary gate. No date will be fabricated to improve this metric.

A second assistant review found that12v2 separate-booking questions implied a request although sources stated preferences. All12are revised prospectively, no source/gold value/case is removed, and v2 remains preserved unexecuted. Both arms share identical native actor execution: this phase can measure reporter wording gains, not native action-policy or new-memory gains. New architecture is studied separately, never changed mid-run.
