"""Compact descriptive tables from the closed audit; no scoring changes."""
import argparse
import json
import math
import statistics
from collections import Counter
from pathlib import Path


def summarize(root):
    audit = json.loads((root / 'audit.json').read_text())
    assert audit['complete'] and len(audit['rows']) == 720
    table = {}
    for key, group in audit['groups']['model/arm'].items():
        model, arm = key.split('/', 1)
        rows = [r for r in audit['rows'] if r['model'] == model and r['arm'] == arm]
        latencies = sorted(r['elapsed_seconds'] for r in rows if r['elapsed_seconds'] is not None)
        table[key] = dict(group, accuracy_percent=100 * group['factual_correct'] / group['n'],
                          terminal_counts=dict(Counter(r['terminal'] for r in rows)),
                          median_request_seconds=statistics.median(latencies),
                          p95_request_seconds=latencies[math.ceil(.95 * len(latencies)) - 1])
    selected = {}
    for name, contrasts in audit['contrasts'].items():
        selected[name] = {key: {k: value[k] for k in (
            'n', 'left_correct', 'right_correct', 'gain', 'loss', 'net',
            'restored_from_invalid', 'corrected_usable_answer', 'scenario_cluster_bootstrap')}
            for key, value in contrasts.items() if not key.endswith('/all')}
    return {
        'status': 'DESCRIPTIVE_TABLES_FROM_FROZEN_AUDIT',
        'model_arm': table, 'paired_contrasts': selected,
        'language_arm': audit['groups']['model/language/arm'],
        'family_arm': audit['groups']['model/family/arm'],
        'mechanical_gate': audit['screen_gate'],
        'latency_scope': 'Observed reporter request duration, not end-to-end native workflow or voice latency.',
        'ci_scope': 'Descriptive 40-scenario cluster bootstrap on a synthetic development-exposed bank.',
        'known_microinr': audit['known_microinr'],
        'retained_microinr': audit['retained_microinr'],
    }


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('root', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    result = summarize(args.root)
    with args.output.open('x') as stream:
        json.dump(result, stream, indent=2, ensure_ascii=False)
        stream.write('\n')
    print(json.dumps(result['model_arm'], indent=2))
