"""Post-run descriptive error slices. No new grades, answer repair or causal claims."""
import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path


def analyze(root):
    audit = json.loads((root / 'audit.json').read_text())
    inputs = {x['id']: x for x in json.loads((root / 'inputs.json').read_text())}
    cases = {x['id']: x for x in json.loads((root / 'provenance/parent/runtime.json').read_text())}
    result, summary = [], defaultdict(Counter)
    for row in audit['rows']:
        item = inputs[row['history_id']]
        original = json.loads((root / 'provenance/parent/paired' / (item['id'] + '.json')).read_text())['original']
        case = cases[row['case_id']]
        appointments = [x for x in original['final_backend']['appointments']
                        if x['id'] == case['appointment_id'] and all(x[k] == v for k, v in case['caller'].items())]
        assert len(appointments) == 1
        backend_date = appointments[0]['date']
        raw, target = row['raw'], row['actual_question_answer']
        labels = []
        if not row['valid_final']:
            labels.append('missing_or_invalid_final')
        else:
            if raw['answer'] == target['answer'] and raw['needs_clarification'] != target['needs_clarification']:
                labels.append('correct_date_value_wrong_clarification')
            if row['wrong_non_null_date']:
                labels.append('wrong_non_null_date')
                if raw['answer'] == backend_date and target['answer'] != backend_date:
                    labels.append('wrong_answer_matches_current_backend_date')
            if row['false_abstention']:
                labels.append('false_abstention_on_known_target')
            if raw['answer'] is not None and target['answer'] is None:
                labels.append('definite_answer_on_unknown_target')
            if not row['raw_status_matches_execution']:
                labels.append('raw_action_status_wrong')
                if row['application_status_matches_execution']:
                    labels.append('wrong_status_repaired_by_existing_receipt_projection')
        key = row['model'] + '/' + row['arm']
        summary[key].update(labels)
        if labels:
            result.append({'id': row['id'], 'history_id': row['history_id'], 'family': row['family'],
                           'model': row['model'], 'arm': row['arm'], 'language': row['language'],
                           'raw': raw, 'target': target, 'current_backend_date': backend_date,
                           'labels': labels, 'primary_correct': row['factual_answer_correct']})
    return {'status': 'DESCRIPTIVE_ERROR_ATTRIBUTION_NOT_CAUSAL_IDENTIFICATION',
            'rows_checked': len(audit['rows']), 'summary': {k: dict(v) for k, v in summary.items()},
            'error_rows': result, 'limitations': [
                'Labels can overlap; their totals are not a new accuracy denominator.',
                'A wrong answer equaling the backend date does not prove why the model chose it.',
                'Receipt projection is the same existing deterministic layer in every arm.',
                'No gold, model answer, prior score or advancement criterion is changed.']}


if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('root', type=Path); p.add_argument('output', type=Path)
    args = p.parse_args(); result = analyze(args.root)
    with args.output.open('x') as f: json.dump(result, f, indent=2, ensure_ascii=False); f.write('\n')
    print(json.dumps({'rows_checked': result['rows_checked'], 'error_rows': len(result['error_rows'])}))
