"""Compare two independently implemented raw audits; never create model answers."""
import argparse
import hashlib
import json
from pathlib import Path


def verify(root):
    primary = json.loads((root / 'audit.json').read_text())
    independent = json.loads((root / 'independent-aggregation.json').read_text())
    a = {row['id']: row for row in primary['rows']}
    b = {row['id']: row for row in independent['rows']}
    assert len(a) == len(b) == 720 and a.keys() == b.keys()
    mapping = {'raw': 'raw', 'terminal': 'terminal', 'valid_final': 'valid_final',
               'actual_question_answer': 'target', 'factual_answer_correct': 'factual_correct',
               'wrong_non_null_date': 'wrong_non_null_date', 'false_abstention': 'false_abstention',
               'raw_status_matches_execution': 'raw_status_correct',
               'treated_actor_prose': 'treated_actor_prose', 'model': 'model', 'arm': 'arm'}
    for ident in a:
        for left, right in mapping.items():
            assert a[ident][left] == b[ident][right], (ident, left)
    for key in ('known_microinr', 'retained_microinr'):
        assert primary[key] == independent[key], key
    assert [row['id'] for row in primary['actual_dispatch_order']] == independent['actual_dispatch_order']
    contrasts = 0
    for contrast, slices in primary['contrasts'].items():
        for scope_model, result in slices.items():
            scope, model = scope_model.split('/', 1)
            if model == 'all':
                continue
            other = independent['contrasts'][f'{contrast}/{model}/{scope}']
            for key in ('n', 'gain', 'loss', 'net', 'restored_from_invalid', 'corrected_usable_answer'):
                assert result[key] == other[key], (contrast, scope_model, key)
            assert result['left_correct'] == other['before_correct']
            assert result['right_correct'] == other['after_correct']
            contrasts += 1
    return {'status': 'TWO_RAW_AUDITS_AGREE', 'planned_rows_compared': 720,
            'fields_per_row': len(mapping), 'paired_model_slice_contrasts_compared': contrasts,
            'cost_and_local_release_order_match': True,
            'primary_sha256': hashlib.sha256((root / 'audit.json').read_bytes()).hexdigest(),
            'independent_sha256': hashlib.sha256((root / 'independent-aggregation.json').read_bytes()).hexdigest(),
            'semantic_review_is_separate': True}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('root', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    result = verify(args.root)
    with args.output.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(result))
