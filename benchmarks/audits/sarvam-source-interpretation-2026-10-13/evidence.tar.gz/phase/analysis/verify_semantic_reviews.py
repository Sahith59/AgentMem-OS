"""Offline coverage and consistency check for three assistant language reviews.

This normalizes each review's native schema by frozen reporter job ID. It neither
regrades source meaning nor implies human or native-speaker language validation.
"""

import argparse
import hashlib
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

ARMS = {"chronological", "grouped_lossless", "grouped_actor_prose_withheld"}
FILES = {
    "en": "english-review.json",
    "hi": "hindi-review.json",
    "te": "telugu-review.json",
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def unique_pairs(items):
    result = {}
    for key, value in items:
        require(key not in result, f"Duplicate JSON key: {key}")
        result[key] = value
    return result


def read(path):
    return json.loads(Path(path).read_text(), object_pairs_hook=unique_pairs)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def verdict(value, *, valid_final, context):
    require(value in {"correct", "incorrect", "invalid_or_missing"},
            f"Unexpected verdict {context}: {value}")
    if value == "invalid_or_missing":
        require(not valid_final, f"Invalid verdict on valid final: {context}")
    return value == "correct"


def verify(root):
    root = Path(root)
    manifest = read(root / "manifest.json")
    audit = read(root / "audit.json")
    jobs = {job["id"]: job for job in manifest["jobs"]}
    rows = {row["id"]: row for row in audit["rows"]}
    require(len(jobs) == len(rows) == 720 and set(jobs) == set(rows),
            "Manifest/audit job coverage is not exactly 720")
    require(audit["verified"] is True and audit["complete"] is True,
            "Primary audit is not verified and complete")
    expected = {language: {job_id for job_id, row in rows.items()
                           if row["language"] == language} for language in FILES}
    require(all(len(ids) == 240 for ids in expected.values()),
            "Manifest/audit language allocation differs from 240 each")
    expected_cases = {language: {rows[job_id]["case_id"] for job_id in ids}
                      for language, ids in expected.items()}
    expected_histories = {language: {rows[job_id]["history_id"] for job_id in ids}
                          for language, ids in expected.items()}
    require(all(len(expected_cases[language]) == 40
                and len(expected_histories[language]) == 80 for language in FILES),
            "Source case or native history census differs")

    reviews = {language: read(root / "reviews" / filename)
               for language, filename in FILES.items()}
    review_hashes = {language: sha(root / "reviews" / filename)
                     for language, filename in FILES.items()}
    manifest_hash = sha(root / "manifest.json")
    execution_hash = sha(root / "execution.json")
    en, hi, te = (reviews[language] for language in FILES)
    require(en["status"] == "ASSISTANT_ENGLISH_REVIEW_COMPLETE"
            and en["independent_native_human_review"] is False
            and en["phase_manifest_sha256"] == manifest_hash,
            "English review completion or provenance changed")
    require(hi["review_status"] == "ASSISTANT_HINDI_SEMANTIC_REVIEW_COMPLETE"
            and hi["language"] == "hi"
            and "no independent native human review" in hi["reviewer"].lower()
            and hi["manifest_sha256"] == manifest_hash
            and hi["execution_sha256"] == execution_hash,
            "Hindi review completion or provenance changed")
    require(te["status"] == "ASSISTANT_TELUGU_LANGUAGE_REVIEW_COMPLETE"
            and te["language"] == "te"
            and te["independent_native_human_review"] is False
            and te["provenance"]["manifest_file_sha256"] == manifest_hash
            and te["provenance"]["execution_file_sha256"] == execution_hash,
            "Telugu review completion or provenance changed")

    normalized = {}
    file_checks = Counter()

    def add(language, job_id, factual, raw_status, *, case_id, history_id,
            result_hash, receipt_hash, request_hash=None, invalid_label=False):
        require(job_id in expected[language] and job_id not in normalized,
                f"Unexpected or duplicate reviewed job: {job_id}")
        row = rows[job_id]
        require(case_id == row["case_id"] and history_id == row["history_id"],
                f"Reviewed source mapping changed: {job_id}")
        require(type(factual) is bool and type(raw_status) is bool,
                f"Non-Boolean normalized verdict: {job_id}")
        require(result_hash == sha(root / f"{job_id}.result.json"),
                f"Reviewed result file changed: {job_id}")
        require(receipt_hash == sha(root / "calls" / f"{job_id}.receipt.json"),
                f"Reviewed receipt file changed: {job_id}")
        file_checks["result"] += 1
        file_checks["receipt"] += 1
        if request_hash is not None:
            require(request_hash == sha(root / "calls" / f"{job_id}.request.json"),
                    f"Reviewed request file changed: {job_id}")
            file_checks["request"] += 1
        require(factual == row["factual_answer_correct"]
                and raw_status == row["raw_status_matches_execution"],
                f"Semantic verdict differs from raw primary audit: {job_id}")
        if invalid_label:
            require(not row["valid_final"], f"Invalid label on valid output: {job_id}")
        normalized[job_id] = {
            "language": language,
            "factual_correct": factual,
            "raw_status_correct": raw_status,
            "valid_final": row["valid_final"],
        }

    # English: one source-case list, one episode list, one flat reporter list.
    en_cases = {case["id"] for case in en["source_case_reviews"]}
    require(len(en["source_case_reviews"]) == len(en_cases) == 40
            and en_cases == expected_cases["en"]
            and all(case["source_gold_ambiguity_flag"] is False
                    for case in en["source_case_reviews"]),
            "English source-case coverage or ambiguity")
    en_histories = {episode["id"] for episode in en["episodes"]}
    require(len(en["episodes"]) == len(en_histories) == 80
            and en_histories == expected_histories["en"],
            "English native-history coverage")
    for report in en["reporter_reviews"]:
        job_id = report["id"]
        require(report["source_gold_ambiguity_flag"] is False
                and report["arm"] in ARMS
                and job_id == report["episode_id"] + "-source-" + report["arm"],
                f"English reporter source/arm ambiguity: {job_id}")
        add("en", job_id, report["primary_factual_correct"], report["raw_status_correct"],
            case_id=report["case_id"], history_id=report["episode_id"],
            result_hash=report["result_sha256"], receipt_hash=report["receipt_sha256"],
            request_hash=report["request_file_sha256"])
    require(len(en["reporter_reviews"]) == 240,
            "English reporter review count")

    # Hindi: native-history cases contain three report dictionaries.
    hi_history_ids = {case["history_id"] for case in hi["cases"]}
    hi_case_ids = {case["case_id"] for case in hi["cases"]}
    require(len(hi["cases"]) == len(hi_history_ids) == 80
            and hi_history_ids == expected_histories["hi"]
            and len(hi_case_ids) == 40 and hi_case_ids == expected_cases["hi"],
            "Hindi source/history coverage")
    for case in hi["cases"]:
        require(case["source_gold_ambiguous"] is False
                and case["source_ambiguity_flags"] == []
                and set(case["reports"]) == ARMS,
                f"Hindi source ambiguity or arm coverage: {case['history_id']}")
        for arm, report in case["reports"].items():
            job_id = report["job_id"]
            require(job_id == case["history_id"] + "-source-" + arm
                    and report["arm"] == arm,
                    f"Hindi reporter arm mapping changed: {job_id}")
            factual_value = report["factual_verdict"]
            status_value = report["raw_status_verdict"]
            factual = verdict(factual_value, valid_final=rows[job_id]["valid_final"],
                              context=job_id + "/factual")
            status = verdict(status_value, valid_final=rows[job_id]["valid_final"],
                             context=job_id + "/status")
            add("hi", job_id, factual, status,
                case_id=case["case_id"], history_id=case["history_id"],
                result_hash=report["result_file_sha256"],
                receipt_hash=report["receipt_file_sha256"],
                invalid_label="invalid_or_missing" in (factual_value, status_value))
            require(report["request_sha256"] == jobs[job_id]["request_sha256"],
                    f"Hindi request payload binding changed: {job_id}")
            file_checks["request_payload"] += 1
    require(set(hi["planned_job_ids"]) == set(hi["reviewed_job_ids"]) == expected["hi"]
            and len(hi["planned_job_ids"]) == len(hi["reviewed_job_ids"]) == 240
            and hi["summary"]["source_gold_ambiguities"] == 0,
            "Hindi declared job coverage or ambiguity")

    # Telugu: native-history rows plus a separately indexed flat judgment list.
    te_history_ids = {case["history_id"] for case in te["rows"]}
    te_case_ids = {case["case_id"] for case in te["rows"]}
    require(len(te["rows"]) == len(te_history_ids) == 80
            and te_history_ids == expected_histories["te"]
            and len(te_case_ids) == 40 and te_case_ids == expected_cases["te"]
            and set(te["reviewed_history_ids"]) == te_history_ids
            and set(te["reviewed_case_ids"]) == te_case_ids
            and te["source_gold_ambiguities"] == [],
            "Telugu source/history coverage or ambiguity")
    nested_te = {}
    for case in te["rows"]:
        require(case["source_gold_ambiguous"] is False
                and set(case["reports"]) == ARMS,
                f"Telugu source ambiguity or arm coverage: {case['history_id']}")
        for arm, report in case["reports"].items():
            job_id = report["id"]
            require(job_id == case["history_id"] + "-source-" + arm
                    and report["arm"] == arm,
                    f"Telugu reporter arm mapping changed: {job_id}")
            factual = verdict(report["factual_verdict"],
                              valid_final=rows[job_id]["valid_final"],
                              context=job_id + "/factual")
            status = verdict(report["raw_status_verdict"],
                             valid_final=rows[job_id]["valid_final"],
                             context=job_id + "/status")
            add("te", job_id, factual, status,
                case_id=case["case_id"], history_id=case["history_id"],
                result_hash=report["result_file_sha256"],
                receipt_hash=report["receipt_file_sha256"],
                request_hash=report["request_file_sha256"])
            nested_te[job_id] = report
    te_judgments = {judgment["job_id"]: judgment for judgment in te["judgments"]}
    require(len(te["judgments"]) == len(te_judgments) == 240
            and set(te_judgments) == set(nested_te)
            and set(te["reviewed_job_ids"]) == set(nested_te)
            and len(te["reviewed_job_ids"]) == 240,
            "Telugu flat/nested job coverage")
    for job_id, judgment in te_judgments.items():
        report = nested_te[job_id]
        require(judgment["factual_verdict"] == report["factual_verdict"]
                and judgment["raw_status_verdict"] == report["raw_status_verdict"]
                and judgment["result_file_sha256"] == report["result_file_sha256"],
                f"Telugu flat/nested verdict differs: {job_id}")

    require(len(normalized) == 720 and set(normalized) == set(jobs)
            and all({job_id for job_id, row in normalized.items()
                     if row["language"] == language} == expected[language]
                    for language in FILES),
            "Union of assistant language reviews is not exact planned coverage")
    require(file_checks["result"] == file_checks["receipt"] == 720,
            "Result/receipt hash coverage differs")
    require(file_checks["request"] == 480 and file_checks["request_payload"] == 240,
            "Request hash/digest coverage differs")
    summary = {}
    for language in FILES:
        subset = [normalized[job_id] for job_id in expected[language]]
        summary[language] = {
            "planned_and_reviewed_jobs": len(subset),
            "factual_correct": sum(row["factual_correct"] for row in subset),
            "raw_status_correct": sum(row["raw_status_correct"] for row in subset),
            "invalid_or_missing_final": sum(not row["valid_final"] for row in subset),
            "source_cases": len(expected_cases[language]),
            "native_histories": len(expected_histories[language]),
            "source_gold_ambiguities": 0,
        }
    return {
        "status": "ASSISTANT_LANGUAGE_REVIEWS_EXACT_COVERAGE_AND_RAW_AUDIT_MATCH",
        "verified_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "manifest_file_sha256": manifest_hash,
        "audit_file_sha256": sha(root / "audit.json"),
        "execution_file_sha256": execution_hash,
        "language_review_file_sha256": review_hashes,
        "planned_and_reviewed_unique_reporter_jobs": len(normalized),
        "per_language": summary,
        "raw_result_files_hash_checked": file_checks["result"],
        "raw_receipt_files_hash_checked": file_checks["receipt"],
        "raw_request_files_hash_checked": file_checks["request"],
        "hindi_request_payload_digests_checked": file_checks["request_payload"],
        "factual_verdict_disagreements_with_audit": 0,
        "raw_status_verdict_disagreements_with_audit": 0,
        "source_gold_ambiguity_flags": 0,
        "assistant_review_only": True,
        "independent_native_human_review": False,
        "scope_limit": "Coverage/hash/verdict consistency; this does not independently translate or validate source meaning and is not human/native-speaker review.",
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("root", nargs="?", type=Path,
                        default=Path(__file__).resolve().parents[1])
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = verify(args.root)
    encoded = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.output is None:
        print(encoded, end="")
    else:
        with args.output.open("x") as handle:
            handle.write(encoded)


if __name__ == "__main__":
    main()
