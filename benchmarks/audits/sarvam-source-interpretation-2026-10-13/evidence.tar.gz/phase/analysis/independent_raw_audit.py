"""Offline, stdlib-only raw replay for the 720-call source-interpretation screen.

This intentionally does not import the campaign runner or scorer. It reads frozen
requests, raw provider receipts, original state and sealed labels only after the
campaign has finished. It makes no provider requests and writes no files.
"""

import argparse
import hashlib
import json
import sqlite3
from collections import Counter, defaultdict
from pathlib import Path

MODELS = {"sarvam-105b": 131072, "sarvam-105b-conversations": 32768}
ARMS = ("chronological", "grouped_lossless", "grouped_actor_prose_withheld")
INPUT_RATE, OUTPUT_RATE = 15, 60  # micro-INR per token


def require(value, message):
    if not value:
        raise ValueError(message)


def pairs(items):
    result = {}
    for key, value in items:
        require(key not in result, "duplicate JSON key")
        result[key] = value
    return result


def parse_json(text):
    return json.loads(text, object_pairs_hook=pairs)


def read(path):
    return parse_json(Path(path).read_text())


def digest(value):
    encoded = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(encoded.encode()).hexdigest()


def file_hash(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def parse_answer(content):
    try:
        value = parse_json(content)
    except (TypeError, ValueError):
        return None
    if (
        not isinstance(value, dict)
        or set(value) != {"answer", "needs_clarification", "action_status"}
        or not (value["answer"] is None or isinstance(value["answer"], str))
        or type(value["needs_clarification"]) is not bool
        or value["action_status"]
        not in {"not_requested", "not_performed", "confirmed", "rejected", "already_applied"}
    ):
        return None
    return value


def expected_status(case, original):
    status = "not_requested" if case["intent"] == "read" else "not_performed"
    if any(
        row["arguments"] == case["requested_change"] for row in original["seed_receipts"]
    ):
        status = "already_applied"
    updates = [row for row in original["tool_trace"] if row["name"] == "update_appointment"]
    if updates:
        status = updates[-1]["response"].get("status")
    return status


def expected_answer(case, label, original):
    target = label["question_target"]
    if target == "source_request_or_condition":
        return label["expected_answer"]
    require(target == "actual_current_date", "unknown question target")
    rows = [
        row
        for row in original["final_backend"]["appointments"]
        if row["id"] == case["appointment_id"]
        and all(row[key] == value for key, value in case["caller"].items())
    ]
    require(len(rows) == 1, "ambiguous scoped appointment")
    return {"answer": rows[0]["date"], "needs_clarification": False}


def receipt_output(receipt, request, reservation):
    require(receipt["status"] == 200, "non-200 provider receipt")
    body = parse_json(receipt["body_text"])
    require(body["model"] == request["model"], "returned model differs")
    usage = body["usage"]
    prompt, completion, total = (
        usage["prompt_tokens"],
        usage["completion_tokens"],
        usage["total_tokens"],
    )
    require(
        all(type(x) is int and x >= 0 for x in (prompt, completion, total))
        and total == prompt + completion
        and prompt <= MODELS[request["model"]]
        and completion <= request["max_tokens"],
        "unknown or invalid provider usage",
    )
    expected_reservation = (
        MODELS[request["model"]] * INPUT_RATE + request["max_tokens"] * OUTPUT_RATE
    ) * 5 // 4
    require(reservation == expected_reservation, "reservation changed")
    cost = prompt * INPUT_RATE + completion * OUTPUT_RATE
    charged = (cost * 5 + 3) // 4
    choice = body["choices"][0]
    message = choice["message"]
    if message.get("tool_calls"):
        terminal = "refused_final_tool_request"
    elif choice.get("finish_reason") != "stop":
        terminal = "incomplete"
    else:
        terminal = "answer"
    parsed = parse_answer(message.get("content")) if terminal == "answer" else None
    return (terminal, parsed, cost, charged, prompt, completion, body.get("id"),
            message.get("content"), choice.get("finish_reason"), message.get("tool_calls") or [])


def summarize(rows):
    return {
        "n": len(rows),
        "factual_correct": sum(row["factual_correct"] for row in rows),
        "valid_final": sum(row["valid_final"] for row in rows),
        "wrong_non_null_date": sum(row["wrong_non_null_date"] for row in rows),
        "false_abstention": sum(row["false_abstention"] for row in rows),
        "raw_status_correct": sum(row["raw_status_correct"] for row in rows),
        "known_microinr": sum(row["known_microinr"] for row in rows),
        "retained_microinr": sum(row["retained_microinr"] for row in rows),
    }


def replay(root):
    root = Path(root)
    manifest = read(root / "manifest.json")
    jobs = manifest["jobs"]
    require(len(jobs) == 720 and len({job["id"] for job in jobs}) == 720, "not 720 unique jobs")
    require(Counter(job["arm"] for job in jobs) == {arm: 240 for arm in ARMS}, "arm coverage")
    for name, sha in manifest["files_sha256"].items():
        require(file_hash(root / name) == sha, f"frozen artifact changed: {name}")
    started = read(root / "started.json")
    require(started["manifest_sha256"] == digest(manifest), "started manifest mismatch")
    execution = read(root / "execution.json")
    outcomes = execution["outcomes"]
    require([row["id"] for row in outcomes] == [job["id"] for job in jobs], "outcome order")
    require(execution["attempted"] == 720, "campaign stopped before 720 attempted")
    require(execution["infrastructure_errors"] == 0, "infrastructure errors recorded")
    inputs = {item["id"]: item for item in read(root / "inputs.json")}
    require(len(inputs) == 240, "history coverage")
    cases = {case["id"]: case for case in read(root / "provenance/parent/runtime.json")}
    labels = read(root / "sealed/gold.json")
    with sqlite3.connect(f"file:{root / 'calls/meter.sqlite'}?mode=ro", uri=True) as db:
        meter = {
            row[0]: row[1:]
            for row in db.execute(
                "SELECT id,stage,reservation,charged,usage_cost,status FROM calls"
            )
        }
    require(set(meter) == {job["id"] for job in jobs}, "meter inventory differs")
    rows = []
    response_ids = set()
    dispatch = {}
    for job, outcome in zip(jobs, outcomes):
        job_id = job["id"]
        request_record = read(root / "calls" / f"{job_id}.request.json")
        request = request_record["request"]
        require(
            request_record["endpoint"] == "https://api.sarvam.ai/v1/chat/completions"
            and request_record["sha256"] == job["request_sha256"] == digest(request),
            f"request digest differs: {job_id}",
        )
        require(
            request["model"] == inputs[job["history_id"]]["model"]
            and request["max_tokens"] == 8192
            and "tools" not in request
            and "tool_choice" not in request,
            f"request model/cap/tools differ: {job_id}",
        )
        receipt = read(root / "calls" / f"{job_id}.receipt.json")
        require(
            receipt["job"] == job_id
            and receipt["request_sha256"] == job["request_sha256"],
            f"receipt request differs: {job_id}",
        )
        stage, reservation, charged, usage_cost, meter_status = meter[job_id]
        require(stage == "source_interpretation" and reservation == job["reservation_microinr"],
                f"meter reservation differs: {job_id}")
        (terminal, parsed, cost, expected_charge, prompt, completion, response_id,
         content, finish_reason, tool_calls) = receipt_output(receipt, request, reservation)
        require(
            charged == expected_charge and usage_cost == cost and meter_status == "known",
            f"meter settlement differs: {job_id}",
        )
        require(response_id and response_id not in response_ids, "missing/duplicate response ID")
        response_ids.add(response_id)
        saved_result = read(root / f"{job_id}.result.json")
        require(
            terminal == outcome["terminal"] == saved_result["terminal"]
            and parsed == saved_result.get("parsed")
            and content == saved_result.get("content")
            and finish_reason == saved_result.get("finish_reason")
            and tool_calls == saved_result.get("tool_calls"),
            f"raw/result classification differs: {job_id}",
        )
        dispatch[job_id] = read(root / "calls" / f"{job_id}.dispatch.json")["dispatch_time"]
        item = inputs[job["history_id"]]
        case = cases[item["case_id"]]
        label = labels[item["case_id"]]
        require(digest(case) == label["runtime_sha256"], "gold/runtime binding differs")
        pair = read(root / "provenance/parent/paired" / f"{item['id']}.json")
        original = pair["original"]
        require(file_hash(root / "provenance/parent/paired" / f"{item['id']}.json")
                == item["parent_paired_sha256"], f"parent pair differs: {job_id}")
        target = expected_answer(case, label, original)
        expected_action = expected_status(case, original)
        valid = parsed is not None
        factual = valid and all(parsed[key] == value for key, value in target.items())
        rows.append({
            "id": job_id,
            "history_id": job["history_id"],
            "scenario": item["scenario"],
            "family": item["family"],
            "language": item["language"],
            "model": item["model"],
            "arm": job["arm"],
            "position": job["position"],
            "treated_actor_prose": job["treated_actor_prose"],
            "terminal": terminal,
            "valid_final": valid,
            "raw": parsed,
            "target": target,
            "expected_action_status": expected_action,
            "factual_correct": bool(factual),
            "wrong_non_null_date": bool(valid and parsed["answer"] is not None
                                        and parsed["answer"] != target["answer"]),
            "false_abstention": bool(valid and target["answer"] is not None
                                     and (parsed["answer"] is None
                                          or parsed["needs_clarification"] is True)),
            "raw_status_correct": bool(valid and parsed["action_status"] == expected_action),
            "known_microinr": cost,
            "retained_microinr": charged,
            "prompt_tokens": prompt,
            "completion_tokens": completion,
            "elapsed_seconds": receipt["elapsed_seconds"],
            "dispatch_time": dispatch[job_id],
        })
    for suffix in ("request", "receipt", "dispatch"):
        seen = {path.name.removesuffix(f".{suffix}.json")
                for path in (root / "calls").glob(f"*.{suffix}.json")}
        require(seen == set(meter), f"{suffix} inventory differs")
    result_ids = {path.name.removesuffix(".result.json") for path in root.glob("*.result.json")}
    require(result_ids == set(meter), "result inventory differs")
    by_history = defaultdict(dict)
    for row in rows:
        by_history[row["history_id"]][row["arm"]] = row
    require(len(by_history) == 240 and all(set(value) == set(ARMS) for value in by_history.values()),
            "paired coverage differs")
    requests = {job["id"]: job["request_sha256"] for job in jobs}
    for history_id, arms in by_history.items():
        b, c = arms[ARMS[1]], arms[ARMS[2]]
        if not c["treated_actor_prose"]:
            require(requests[b["id"]] == requests[c["id"]],
                    f"no-treatment B/C requests differ: {history_id}")
    contrasts = {}
    for name, before_arm, after_arm in (("A_to_B", ARMS[0], ARMS[1]),
                                         ("B_to_C", ARMS[1], ARMS[2]),
                                         ("A_to_C", ARMS[0], ARMS[2])):
        for model in MODELS:
            for scope in ("all", "treated", "no_treatment"):
                pairs = [(arms[before_arm], arms[after_arm]) for arms in by_history.values()
                         if arms[before_arm]["model"] == model
                         and (scope == "all" or arms[before_arm]["treated_actor_prose"]
                              == (scope == "treated"))]
                gains = [(x, y) for x, y in pairs if not x["factual_correct"] and y["factual_correct"]]
                losses = [(x, y) for x, y in pairs if x["factual_correct"] and not y["factual_correct"]]
                contrasts[f"{name}/{model}/{scope}"] = {
                    "n": len(pairs),
                    "before_correct": sum(x["factual_correct"] for x, _ in pairs),
                    "after_correct": sum(y["factual_correct"] for _, y in pairs),
                    "gain": len(gains),
                    "loss": len(losses),
                    "net": len(gains) - len(losses),
                    "restored_from_invalid": sum(not x["valid_final"] for x, _ in gains),
                    "corrected_usable_answer": sum(x["valid_final"] for x, _ in gains),
                    "gain_ids": [x["history_id"] for x, _ in gains],
                    "loss_ids": [x["history_id"] for x, _ in losses],
                }
    by_group = defaultdict(list)
    for row in rows:
        by_group[(row["model"], row["arm"])].append(row)
    grouped = {f"{model}/{arm}": summarize(values)
               for (model, arm), values in sorted(by_group.items())}
    return {
        "status": "INDEPENDENT_STDLIB_RAW_REPLAY",
        "scope": "All 720 prospective outputs; no imports from campaign code; no human/native review",
        "manifest_sha256": digest(manifest),
        "rows": rows,
        "model_arm": grouped,
        "contrasts": contrasts,
        "treated_histories": sum(arms[ARMS[2]]["treated_actor_prose"]
                                 for arms in by_history.values()),
        "known_microinr": sum(row["known_microinr"] for row in rows),
        "retained_microinr": sum(row["retained_microinr"] for row in rows),
        "actual_dispatch_order": [job_id for job_id, _ in sorted(dispatch.items(),
                                                                key=lambda pair: pair[1])],
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=Path)
    args = parser.parse_args()
    print(json.dumps(replay(args.root), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
