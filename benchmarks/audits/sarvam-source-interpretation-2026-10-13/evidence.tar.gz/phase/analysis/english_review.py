"""Offline assistant English source/output review; never runs a provider call.

This reads only completed result/receipt pairs. It refuses to write the final
review unless every one of the 240 planned English outputs is present.
"""

import argparse
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

from benchmarks.sarvam_native_controls.transcript_finalizer import classify
from benchmarks.sarvam_native_study.transport import digest
from benchmarks.sarvam_receipt_reporting import project

ARMS = ("chronological", "grouped_lossless", "grouped_actor_prose_withheld")


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def source_target(case, label, original):
    if label["question_target"] == "source_request_or_condition":
        return label["expected_answer"]
    require(label["question_target"] == "actual_current_date", "Unknown question target")
    scoped = [row for row in original["final_backend"]["appointments"]
              if row["id"] == case["appointment_id"] and
              all(row[key] == value for key, value in case["caller"].items())]
    require(len(scoped) == 1, "Ambiguous actual scoped backend state")
    return {"answer": scoped[0]["date"], "needs_clarification": False}


def wording(family, target, raw, valid, source_date, expected_status, projected_status):
    if not valid:
        return "No usable final JSON; source question remains unanswerable from this output."
    notes = []
    if raw["answer"] != target["answer"]:
        if target["answer"] is None:
            notes.append("It selects a definite date despite an unresolved source target")
        elif raw["answer"] is None:
            notes.append("It abstains although the source or actual receipt determines a date")
        elif family == "separate_booking" and raw["answer"] == source_date:
            notes.append("It substitutes the backend's current date for the customer's preference")
        else:
            notes.append("Its date does not match the source or scoped confirmed state")
    if raw["needs_clarification"] != target["needs_clarification"]:
        notes.append("Its clarification flag conflicts with the source condition")
    if raw["action_status"] != expected_status:
        notes.append("Its action-status claim conflicts with the actual execution boundary")
    if projected_status is not None and projected_status != expected_status:
        notes.append("The receipt-projected status remains inconsistent with execution")
    if not notes:
        notes.append("Date, clarification and raw status match the source and actual execution")
    return "; ".join(notes) + "."


def build(root, *, require_complete=True):
    root = Path(root)
    parent = root / "provenance" / "parent"
    manifest = read(root / "manifest.json")
    inputs = {row["id"]: row for row in read(root / "inputs.json")}
    runtime = {row["id"]: row for row in read(parent / "runtime.json")}
    gold = read(root / "sealed" / "gold.json")
    prior = read(parent / "semantic-review-en-complete.json")
    prior_rows = {row["episode_id"]: row["source_review"] for row in prior["rows"]}
    jobs = [job for job in manifest["jobs"] if inputs[job["history_id"]]["language"] == "en"]
    require(len(jobs) == 240 and len({job["history_id"] for job in jobs}) == 80,
            "English planned coverage changed")
    complete_jobs = [job for job in jobs if (root / f"{job['id']}.result.json").is_file()]
    stopped_ids = set()
    if (root / "execution.json").is_file():
        execution_rows = {row["id"]: row for row in
                          read(root / "execution.json")["outcomes"]}
        stopped_ids = {row["id"] for row in execution_rows.values()
                       if row["terminal"] == "not_attempted_after_stop"}
    else:
        execution_rows = {}
    if require_complete:
        require(len(execution_rows) == 720, "Campaign execution record incomplete")
        require(len(complete_jobs) + sum(job["id"] in stopped_ids for job in jobs) == 240,
                "English planned-output coverage incomplete")
    case_records, episode_records, reporter_reviews = {}, {}, []
    for job in jobs:
        item = inputs[job["history_id"]]
        episode_id, case_id = item["id"], item["case_id"]
        pair_path = parent / "paired" / f"{episode_id}.json"
        pair = read(pair_path)
        original = pair["original"]
        case, label = runtime[case_id], gold[case_id]
        target = source_target(case, label, original)
        prior_source = prior_rows[episode_id]
        require(prior_source["actual_question_answer"] == target and
                prior_source["source_gold_disagreement"] is False and
                label["runtime_sha256"] == digest(case),
                f"Source/gold ambiguity or mismatch: {episode_id}")
        if case_id not in case_records:
            case_records[case_id] = {
                "id": case_id, "family": case["family"], "question": case["question"],
                "source_messages": case["source_messages"],
                "requested_change": case["requested_change"],
                "source_conditions": case["fixture"],
                "question_target": label["question_target"],
                "label_expected_answer": label["expected_answer"],
                "source_gold_ambiguity_flag": False,
                "assistant_source_reading": prior_source["source_interpretation"],
                "source_file_sha256": sha(parent / "runtime.json"),
            }
        scoped = [row for row in original["final_backend"]["appointments"]
                  if row["id"] == case["appointment_id"] and
                  all(row[key] == value for key, value in case["caller"].items())]
        require(len(scoped) == 1, "Final scoped state ambiguous")
        if episode_id not in episode_records:
            actor_claims = [message for message in original["history"]
                            if message["role"] == "assistant"]
            episode_records[episode_id] = {
                "id": episode_id, "case_id": case_id, "model": item["model"],
                "family": case["family"], "treated_actor_prose": None,
                "original_question": case["question"],
                "original_source_messages": case["source_messages"],
                "source_conditions": case["fixture"],
                "parent_paired_sha256": sha(pair_path),
                "original_actor_terminal": original["terminal"],
                "actor_claims": actor_claims,
                "actual_tool_trace": original["tool_trace"],
                "prior_execution_receipts": original["seed_receipts"],
                "final_scoped_backend_date": scoped[0]["date"],
                "actual_question_answer": target,
                "expected_execution_status": prior_source["expected_execution_status"],
                "source_interpretation": prior_source["source_interpretation"],
                "reporters": {},
            }
        if job not in complete_jobs and job["id"] not in stopped_ids:
            continue
        result_path = root / f"{job['id']}.result.json"
        receipt_path = root / "calls" / f"{job['id']}.receipt.json"
        request_path = root / "calls" / f"{job['id']}.request.json"
        result = read(result_path) if result_path.exists() else {
            "terminal": "not_attempted_after_stop"}
        if execution_rows:
            require(execution_rows[job["id"]]["terminal"] == result["terminal"],
                    "English result/execution terminal mismatch")
        require(result_path.exists() or job["id"] in stopped_ids,
                "Unaccounted English planned output")
        receipt = read(receipt_path) if receipt_path.exists() else {}
        request = read(request_path) if request_path.exists() else {}
        try:
            body = json.loads(receipt["body_text"])
        except (KeyError, ValueError, TypeError):
            body = {}
        if request:
            require(request["sha256"] == job["request_sha256"] ==
                    digest(request["request"]), "Output/request binding changed")
        if receipt:
            require(request and receipt["request_sha256"] == request["sha256"] and
                    receipt["job"] == job["id"], "Output/receipt binding changed")
        if result["terminal"] == "infrastructure_error":
            pass  # The campaign audit, not this language review, reconciles unknown transport.
        elif receipt.get("status") == 200 and body.get("choices"):
            try:
                replay = classify(body)
            except (ValueError, KeyError, TypeError, IndexError):
                raise ValueError("Malformed provider choice not retained as infrastructure failure")
            else:
                require(replay == result, "Raw reporter classification changed")
        elif result["terminal"] not in ("infrastructure_error", "not_attempted_after_stop"):
            raise ValueError("Non-infrastructure result lacks replayable receipt")
        raw = result.get("parsed")
        valid = result.get("terminal") == "answer" and raw is not None
        projected = None
        if valid:
            try:
                projected = project(
                    intent=case["intent"], requested_change=case["requested_change"],
                    prior_receipts=original["seed_receipts"], tool_trace=original["tool_trace"],
                    raw_content=result["content"], completed=True,
                )["application_output"]["action_status"]
            except (ValueError, KeyError, TypeError):
                pass
        status = prior_source["expected_execution_status"]
        factual = bool(valid and raw["answer"] == target["answer"] and
                       raw["needs_clarification"] == target["needs_clarification"])
        review = {
            "id": job["id"], "episode_id": episode_id, "case_id": case_id,
            "model": item["model"], "arm": job["arm"],
            "treated_actor_prose": job["treated_actor_prose"],
            "request_file_sha256": sha(request_path) if request_path.exists() else None,
            "request_payload_sha256": job["request_sha256"],
            "receipt_sha256": sha(receipt_path) if receipt_path.exists() else None,
            "result_sha256": sha(result_path) if result_path.exists() else None,
            "http_status": receipt.get("status"),
            "provider_choice": body["choices"][0] if body.get("choices") else None,
            "raw_final": result, "raw_answer": raw,
            "projected_action_status": projected,
            "actual_question_answer": target,
            "expected_execution_status": status,
            "date_matches_source": bool(valid and raw["answer"] == target["answer"]),
            "clarification_matches_source": bool(valid and
                                                  raw["needs_clarification"] ==
                                                  target["needs_clarification"]),
            "primary_factual_correct": factual,
            "raw_status_correct": bool(valid and raw["action_status"] == status),
            "projected_status_correct": bool(valid and projected == status),
            "valid_final": valid,
            "invalid_cap_or_refusal": result.get("terminal") in
                                     ("incomplete", "refused_final_tool_request") or
                                     (result.get("finish_reason") == "length"),
            "source_gold_ambiguity_flag": False,
            "assistant_semantic_judgment": wording(
                case["family"], target, raw, valid, scoped[0]["date"], status, projected
            ),
        }
        reporter_reviews.append(review)
        episode_records[episode_id]["treated_actor_prose"] = job["treated_actor_prose"]
        episode_records[episode_id]["reporters"][job["arm"]] = review["id"]
    by_episode = defaultdict(dict)
    for review in reporter_reviews:
        by_episode[review["episode_id"]][review["arm"]] = review
    paired = []
    for episode_id, arms in sorted(by_episode.items()):
        if set(arms) != set(ARMS):
            continue
        paired.append({
            "episode_id": episode_id, "treated_actor_prose": arms[ARMS[2]]["treated_actor_prose"],
            "A_to_B": int(arms[ARMS[1]]["primary_factual_correct"]) -
                      int(arms[ARMS[0]]["primary_factual_correct"]),
            "B_to_C": int(arms[ARMS[2]]["primary_factual_correct"]) -
                      int(arms[ARMS[1]]["primary_factual_correct"]),
            "A_to_C": int(arms[ARMS[2]]["primary_factual_correct"]) -
                      int(arms[ARMS[0]]["primary_factual_correct"]),
        })
    contrasts = {}
    for name in ("A_to_B", "B_to_C", "A_to_C"):
        contrasts[name] = {
            "treated_gains": [p["episode_id"] for p in paired
                              if p["treated_actor_prose"] and p[name] > 0],
            "treated_losses": [p["episode_id"] for p in paired
                               if p["treated_actor_prose"] and p[name] < 0],
            "no_treatment_gains": [p["episode_id"] for p in paired
                                 if not p["treated_actor_prose"] and p[name] > 0],
            "no_treatment_losses": [p["episode_id"] for p in paired
                                  if not p["treated_actor_prose"] and p[name] < 0],
        }
    summary = {
        "planned_english_outputs": 240, "completed_english_outputs": len(reporter_reviews),
        "completed_english_histories": len(paired),
        "treated_histories": sum(p["treated_actor_prose"] for p in paired),
        "no_treatment_histories": sum(not p["treated_actor_prose"] for p in paired),
        "terminal_counts": dict(Counter(r["raw_final"]["terminal"] for r in reporter_reviews)),
        "finish_reason_counts": dict(Counter(str(r["raw_final"].get("finish_reason"))
                                          for r in reporter_reviews)),
        "invalid_cap_or_refusal": sum(r["invalid_cap_or_refusal"] for r in reporter_reviews),
        "not_attempted_after_stop": sum(r["raw_final"]["terminal"] ==
                                        "not_attempted_after_stop" for r in reporter_reviews),
        "primary_correct": dict(Counter({arm: sum(r["primary_factual_correct"] for r in
                                                 reporter_reviews if r["arm"] == arm)
                                         for arm in ARMS})),
        "raw_status_correct": {arm: sum(r["raw_status_correct"] for r in reporter_reviews
                                   if r["arm"] == arm) for arm in ARMS},
        "projected_status_correct": {arm: sum(r["projected_status_correct"]
                                         for r in reporter_reviews if r["arm"] == arm)
                                     for arm in ARMS},
        "paired_net": {contrast: sum(row[contrast] for row in paired)
                       for contrast in ("A_to_B", "B_to_C", "A_to_C")},
        "source_gold_ambiguities": 0,
        "invalid_output_ids": [r["id"] for r in reporter_reviews if not r["valid_final"]],
        "contrasts_by_treatment": contrasts,
    }
    return {
        "status": "ASSISTANT_ENGLISH_REVIEW_COMPLETE" if len(reporter_reviews) == 240
                  else "ASSISTANT_ENGLISH_REVIEW_IN_PROGRESS",
        "independent_native_human_review": False,
        "phase_manifest_sha256": sha(root / "manifest.json"),
        "parent_semantic_review_sha256": sha(parent / "semantic-review-en-complete.json"),
        "source_case_reviews": [case_records[k] for k in sorted(case_records)],
        "episodes": [episode_records[k] for k in sorted(episode_records)],
        "reporter_reviews": reporter_reviews, "paired_contrasts": paired,
        "summary": summary,
        "limitations": [
            "Assistant language judgment only; no independent native-speaking human review.",
            "Existing development-exposed source and labels are preserved; no gold rewrites.",
            "This review judges outputs against source and actual receipts; it is not a campaign-wide audit.",
            "A B/C difference with identical requests is run variability, not evidence of the actor-prose treatment.",
        ],
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--allow-incomplete", action="store_true")
    args = parser.parse_args()
    review = build(args.root, require_complete=not args.allow_incomplete)
    if args.output:
        with args.output.open("x") as stream:
            json.dump(review, stream, ensure_ascii=False, indent=2)
            stream.write("\n")
    else:
        print(json.dumps(review["summary"], ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
