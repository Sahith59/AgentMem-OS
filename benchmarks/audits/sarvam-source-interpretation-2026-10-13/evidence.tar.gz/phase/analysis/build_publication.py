"""Package closed synthetic evidence; no API request or answer modification."""
import argparse
import gzip
import hashlib
import io
import json
import shutil
import sqlite3
import tarfile
from pathlib import Path


def publish(root, destination):
    execution = json.loads((root / 'execution.json').read_text())
    assert execution['attempted'] == 720 and execution['infrastructure_errors'] == 0
    decision = json.loads((root / 'decision.json').read_text())
    assert decision['semantic_review_complete'] is True
    verification = json.loads((root / 'comparison-verification.json').read_text())
    assert verification['status'] == 'TWO_RAW_AUDITS_AGREE'
    manifest = json.loads((root / 'manifest.json').read_text())
    paths = {root / name for name in manifest['files_sha256']}
    names = [
        'manifest.json', 'execution.json', 'execution.log', 'started.json',
        'audit.json', 'independent-aggregation.json', 'comparison-verification.json', 'review-verification.json',
        'error-attribution.json', 'summary.json', 'decision.json', 'REPORT.md', 'NEXT_STEP.md',
        'PRODUCT_DECISION.md', 'PRIOR_ART_UPDATE.md', 'pricing-check.json',
        'primary-source-check.json', 'method-review.json', 'frozen-source-review.json',
        'launch-preflight.json', 'clean-preflight-verification.json',
        'parent-replay.json', 'prior-carry-replay.json', 'prior-regression-tests.log',
        'focused-tests.log', 'publication-plan.json',
    ]
    paths.update(root / name for name in names)
    paths.update(root.glob('*.result.json'))
    for folder in ('calls', 'reviews', 'analysis'):
        paths.update(p for p in (root / folder).rglob('*') if p.is_file()
                     and '__pycache__' not in p.parts and p.suffix != '.pyc')
    assert all(p.is_file() and not p.is_symlink() for p in paths)
    assert not any('preservation-before' in p.name or 'closed-artifact-hashes' in p.name
                   or p.name.endswith(('-wal', '-shm')) for p in paths)
    for db_path in (root / 'calls').glob('*.sqlite'):
        with sqlite3.connect(f'file:{db_path}?mode=ro', uri=True) as conn:
            assert conn.execute('pragma integrity_check').fetchone() == ('ok',)
    # Read only for an exact credential-byte exclusion check. Never output it.
    from benchmarks.sarvam_native_study.transport import read_key
    credential = read_key().encode()
    assert credential
    payloads = {}
    for path in sorted(paths):
        data = path.read_bytes()
        assert credential not in data, 'Credential found; publication aborted'
        payloads['phase/' + path.relative_to(root).as_posix()] = data
    for name, expected in manifest['files_sha256'].items():
        assert hashlib.sha256(payloads['phase/' + name]).hexdigest() == expected, name
    destination.mkdir(parents=True, exist_ok=False)
    archive = destination / 'evidence.tar.gz'
    with archive.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode='w') as tar:
                for name, data in sorted(payloads.items()):
                    info = tarfile.TarInfo(name)
                    info.size = len(data)
                    info.mode = 0o644
                    info.mtime = 0
                    tar.addfile(info, io.BytesIO(data))
    receipt = {
        'archive': archive.name,
        'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
        'file_count': len(payloads),
        'files': {name: hashlib.sha256(data).hexdigest() for name, data in sorted(payloads.items())},
        'credential_byte_scan_pass': True,
        'private_founder_inventory_excluded': True,
        'scope': 'All 240 saved histories, 720 reporter calls and frozen source/provenance; no new actor actions.',
        'provider_identity_limitation': 'Local receipt hashes are integrity checks, not provider signatures.',
    }
    (destination / 'artifact-manifest.json').write_text(json.dumps(receipt, indent=2) + '\n')
    for name in ('REPORT.md', 'NEXT_STEP.md', 'PROTOCOL.md', 'PRIOR_ART_UPDATE.md',
                 'audit.json', 'independent-aggregation.json', 'decision.json',
                 'comparison-verification.json', 'review-verification.json', 'error-attribution.json', 'summary.json'):
        shutil.copyfile(root / name, destination / name)
    shutil.copytree(root / 'reviews', destination / 'reviews')
    print(json.dumps({'files': len(payloads), 'archive_sha256': receipt['sha256'],
                      'credential_byte_scan_pass': True}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('root', type=Path)
    parser.add_argument('destination', type=Path)
    args = parser.parse_args()
    publish(args.root, args.destination)
