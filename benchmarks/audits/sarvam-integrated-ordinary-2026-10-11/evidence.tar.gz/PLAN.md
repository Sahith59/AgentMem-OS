# Work order

1. Integrate ordinary execution/approval/reporting and test real failures.
2. Freeze six-case24episode setup, source, labels, budget and stop rules.
3. Execute bounded fixed-model setup, then offline replay all receipts/state.
4. Review every miss; prepare larger comparison only if gate passes.
5. Commit/push independent code and evidence, merge after exact-head CI, update memory.

No new memory architecture or overall accuracy claim is proposed by this phase.
