"""Offline combined replay; use a fresh output path. No credentials or inference."""
import hashlib
import json
import socket
import sqlite3
import sys
from pathlib import Path

from benchmarks.sarvam_native_controls.separated_audit import audit as original_audit
from benchmarks.sarvam_native_controls.finalization_transport import audit as repair_audit
from benchmarks.sarvam_native_study.transport import INPUT, OUTPUT, MODELS, save


def deny(*args, **kwargs):
    raise RuntimeError("Offline archive verification forbids networking")


socket.socket = deny
socket.create_connection = deny
root = Path(sys.argv[1])
read = lambda p: json.loads(p.read_text())
original = original_audit(root, "probe")
assert original == read(root / "probe/verification.json")
repair = repair_audit(root / "transport-repair")
assert repair == read(root / "transport-repair/verification.json")
assert read(root / "probe/gate.json")["pass"] is False
assert not (root / "comparison/started.json").exists()
assert not (root / "comparison/episodes").exists()
assert read(root / "comparison/CLOSED_UNATTEMPTED.json")["calls"] == 0
with sqlite3.connect(f"file:{root}/calls/meter.sqlite?mode=ro", uri=True) as db:
    ledger = db.execute("SELECT id,reservation,charged,usage_cost,status FROM calls").fetchall()
for job, reservation, charged, cost, status in ledger:
    request = read(root / "calls" / (job + ".request.json"))["request"]
    assert reservation == (MODELS[request["model"]] * INPUT + 8192 * OUTPUT) * 5 // 4
    if status != "known":
        assert status == "unknown" and cost is None and charged == reservation
assert len(ledger) == 22
budget = read(root / "budget.json")
new_budget = read(root / "transport-repair/budget.json")
assert new_budget["prior_known_microinr"] == budget["prior_known_microinr"] + sum(r[3] or 0 for r in ledger)
assert new_budget["prior_retained_microinr"] == budget["prior_retained_microinr"] + sum(r[2] for r in ledger)
assert new_budget["prior_calls"] == budget["prior_calls"] + len(ledger)
prior_copy = root / "transport-repair/provenance/prior-meter.sqlite"
assert prior_copy.read_bytes() == (root / "calls/meter.sqlite").read_bytes()
histories = read(root / "transport-repair/histories.json")
assert histories[0]["messages"] == read(root / "probe/episodes/probe-m0-setup-allowed/prefix.json")["messages"]
conv = root / "transport-repair/provenance/m1/attribution-m1-setup-action-te-control-t1.request.json"
assert histories[1]["messages"] == read(conv)["request"]["messages"]
# Actual receipts and SQLite dates bind the offline expected responses.
from benchmarks.sarvam_native_study import backend
for index, history in enumerate(histories):
    tools = [json.loads(m["content"]) for m in history["messages"] if m["role"] == "tool"]
    state = backend.state(root / f"transport-repair/provenance/m{index}/backend.sqlite")
    label = read(root / "transport-repair/expected.json")[index]
    assert tools[-1]["status"] == label["action_status"] == "confirmed"
    assert tools[-1]["date"] == label["answer"] == state["date"]
    assert tools[-1]["version"] == state["version"]
summary = read(root / "summary.json")
assert summary["research_calls"] == repair["research_calls"] == 4974
assert summary["research_known_inr"] == repair["research_known_inr"]
assert summary["research_retained_inr"] == repair["research_retained_inr"]
save(Path(sys.argv[2]), {
    "verified": True, "setup_calls": 22, "repair_calls": 4,
    "comparison_calls": 0, "network_access": False, "credential_access": False,
    "candidate_pass": False, "research_calls": 4974,
    "research_known_inr": repair["research_known_inr"],
    "research_retained_inr": repair["research_retained_inr"],
    "limitation": "Same-code replay does not independently validate language semantics",
})
print("Verified 26 calls, actual states, failed gate and accounting; no network or key access.")
