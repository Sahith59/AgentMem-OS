# Separated native execution and final formatting — prospective protocol

The founder requests continuation of the proposed control. Native Sarvam APIs and ordinary isolated SQLite only; no AgentMem memory engine, real customer actions or outreach. Older failed schema/tool experiments remain immutable and closed.

## Question
Can we preserve real tool execution while producing reliable final JSON? Within each model, compare ordinary JSON-object output with strict schema on the SAME actual execution history. No tools are available during either finalization arm. The only difference between final requests is response_format. This is a mechanism comparison with a shared prefix, not independent autonomous action trials or proof of a new memory architecture.

Base105B remains low reasoning; Conversations explicitly null. Every request has temperature0,8192output cap,n1,no streaming. Original records and question are preserved. Both arms now have the same explicit unknown-value rule: if the requested value is not established, answer=null and needs_clarification=true. Keep English schema keys/status literals in every language. These common prompt changes are prospective; do not compare scores causally to the earlier three probes or silently regrade them.

## Execution
For action cases, allow up to3 native action calls without strict-schema formatting. Execute only available model-requested tools in real SQLite, at most4tool calls in a response. Never force a write; approval remains model-interpreted in this phase. Stop the action phase after an actual confirmed/rejected/already_applied tool outcome, or a complete direct model reply. Truncated or failed action phases get no final generation. A tool-argument repair is a new recorded model turn, not an HTTP retry.

For read-only cases, use the original evidence directly without a needless action call. Generate one ordinary and one strict-schema final answer from identical source/tool histories, with randomized arm order. Both have no executable tools. Do not expose hidden database state, expected labels or evaluator values. Do not erase earlier assistant claims or contradictory source records. A final tool-call attempt is rejected and recorded, never executed. No output rewriting, fence stripping, translation or repair is permitted after generation.

Shared execution is paid once. Report actual unique requests/spend separately from each arm's full-path cost, which includes the complete shared prefix for fairness. Do not sum attributed per-arm costs and present that as actual invoice usage. Equal caps do not establish equal consumed tokens; report tokens/calls/request latency by arm.

## Cases and setup gate
Seven excluded mechanics situations across2models give14shared prefixes and28final responses, at most58requests: allowed Telugu update, denied Hindi update, pending English approval, duplicate Telugu request, closed Hindi booking with explicit rejection request, unknown English telephone number, copied Hindi string. No exact input overlap with the72comparison inputs, but known template/failure ancestry remains.

Gate: all14strict-schema answers must pass the frozen full task contract, actual state and required receipts, with no forbidden action attempts and no unknown-usage requests. The ordinary final arm is measured, not required to pass every formatting contract. Gate evidence is hash-bound, including requests,receipts,states and labels. Any gate failure closes the larger comparison without executing it; do not tune and restart a failed manifest.

If setup passes, run the prepared24synthetic situations×EN/HI/TE=72inputs on2models:144shared prefixes,288final answers, at most396requests.54read-only and18action inputs. Randomized job and arm order, seed202610115,4workers,shared90RPM below founder-confirmed120RPM. Stop if2or more infrastructure-failed pairs occur in a batch of at most8; keep all attempted and unattempted identities. Do not stop for an unfavorable score. All scenarios are same-assistant authored/reviewed; translated renderings are correlated and there is no independent native annotation or real-workflow holdout. Known read-only arithmetic/date labels and actual backend consistency were checked before calls.

## Scoring and interpretation
Offline scorer requires exact keys/types,value,clarification/status,actual final state,permitted attempts and required real receipts. Frozen historical scores stay unchanged. Report valid output, exact answer contract and overall task success separately, plus gains/losses per model/language/family. Separate gains from invalid control formatting from gains where both outputs already had valid format. All gains/losses and substantive misses require source review before interpretation.

A formatting-control lead requires at least5net strict-task gains/72 in a model and no more than1.25×attributed output tokens versus its control. Report either failure too. A passing lead is not production promotion or a factual-memory gain. Workflow-cluster bootstrap (2000resamples) is descriptive only; do not treat assistant-authored workflow sampling as population inference. Shared action states are identical by construction, so report their absolute success/failure rather than claiming schema improved action decisions.

## Budget and evidence
Phase retained ceiling INR500:setup100,comparison400. Prior retained INR87.183984 is debited from the existing INR6000research ceiling; prior known estimate INR58.686555. Full-context+8192output reservations at published INR15/Minput,60/Moutput with25%headroom; unknown usage retains full reservation; no cache discount. Budget and no-retry enforcement reuse the audited ControlMeter and transport. Max phase requests454. Estimates are not a verified invoice.

Freeze source,request builders,bank,labels,review,protocol and budgets before calls. Retain raw requests/replies,actual SQLite,all grades and rejected outputs. Verify by network-blocked replay and clean export. Archive credentials separately, never publish their contents. Update dedicated Sarvam notes/decisions on findings; English current state remains unchanged.

Sources checked2026-10-11: Sarvam describes executing model-selected tools, returning actual tool messages and generating a final answer, and documents JSON schema plus application validation: https://docs.sarvam.ai/api/api-guides-tutorials/chat-completion/overview . Our exact no-tools finalization requests require live verification; documentation alone is not a passing result. Rates remain those checked in the previous phase at https://docs.sarvam.ai/api/getting-started/pricing .
