"""Offline second parser for this fixed two-call diagnostic; no project imports."""
import hashlib
import json
import sqlite3
import sys
from collections import Counter
from pathlib import Path


def read(path):
    return json.loads(path.read_text())


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                     separators=(",", ":")).encode()).hexdigest()


def check(root):
    manifest = read(root / "manifest.json")
    for name, sha in manifest["snapshot_sha256"].items():
        assert hashlib.sha256((root / name).read_bytes()).hexdigest() == sha, name
    pairs = [read(p) for p in sorted((root / "parent/paired").glob("*.json"))]
    assert len(pairs) == 240
    missing = [p for p in pairs if all(p["reports"][a]["terminal"] == "not_reached"
                                      for a in ("control", "candidate"))]
    assert len(missing) == 1
    original = missing[0]["original"]
    assert original["id"] == "confirm-fresh-13-en-m0"
    assert original["terminal"] == "invalid_action_response"
    assert original["initial_backend"] == original["final_backend"]
    assert not original["tool_trace"] and len(original["calls"]) == 1
    actor = original["calls"][0]
    actor_request = read(root / "parent/calls" / f"{actor}.request.json")["request"]
    actor_receipt = read(root / "parent/calls" / f"{actor}.receipt.json")
    actor_body = json.loads(actor_receipt["body_text"])
    assert actor_receipt["status"] == 200
    assert actor_body["choices"][0]["finish_reason"] == "length"
    assert actor_body["choices"][0]["message"].get("content") is None
    assert not actor_body["choices"][0]["message"].get("tool_calls")
    assert actor_body["usage"]["completion_tokens"] == 8192
    plan = read(root / "plan.json")
    claim = read(root / "handoff-claim.json")
    assert claim["plan_sha256"] == plan["plan_sha256"]
    expected = read(root / "sealed/gold.json")[original["case_id"]]["expected_answer"]
    assert expected == {"answer": None, "needs_clarification": True}
    reports, known, retained = {}, 0, 0
    meter_path = root / "calls/meter.sqlite"
    with sqlite3.connect(f"file:{meter_path}?mode=ro", uri=True) as db:
        meter = {r[0]: r for r in db.execute("SELECT * FROM calls")}
    assert len(meter) == 2
    requests = sorted((root / "calls").glob("*.request.json"))
    receipts = sorted((root / "calls").glob("*.receipt.json"))
    assert len(requests) == len(receipts) == 2
    for arm in ("control", "candidate"):
        job = plan["reports"][arm]["job"]
        record = read(root / "calls" / f"{job}.request.json")
        req = record["request"]
        receipt = read(root / "calls" / f"{job}.receipt.json")
        assert record["endpoint"] == "https://api.sarvam.ai/v1/chat/completions"
        assert req == plan["reports"][arm]["request"]
        assert digest(req) == record["sha256"] == receipt["request_sha256"]
        assert req["model"] == "sarvam-105b" and req["reasoning_effort"] == "low"
        assert req["max_tokens"] == 8192 and req["temperature"] == 0
        assert "tools" not in req and "tool_choice" not in req
        assert json.loads(req["messages"][1]["content"]) == {
            "original_messages": actor_request["messages"],
            "original_tool_definitions": actor_request["tools"],
        }
        assert receipt["status"] == 200
        body = json.loads(receipt["body_text"])
        assert body["model"] == req["model"] and len(body["choices"]) == 1
        usage = body["usage"]
        inp, out = usage["prompt_tokens"], usage["completion_tokens"]
        assert type(inp) is int and type(out) is int
        assert inp + out == usage["total_tokens"] and 0 <= out <= 8192
        cost = inp * 15 + out * 60
        charge = (cost * 5 + 3) // 4
        assert meter[job] == (job, "handoff", 3072000, charge, cost, "known")
        known += cost
        retained += charge
        choice = body["choices"][0]
        raw = None
        if choice["finish_reason"] == "stop":
            try:
                candidate = json.loads(choice["message"].get("content"))
                if (isinstance(candidate, dict) and set(candidate) == {
                        "answer", "needs_clarification", "action_status"}
                        and type(candidate["needs_clarification"]) is bool
                        and (candidate["answer"] is None or isinstance(candidate["answer"], str))
                        and candidate["action_status"] in {
                            "not_requested", "not_performed", "confirmed", "rejected",
                            "already_applied"}):
                    raw = candidate
            except (TypeError, ValueError):
                pass
        reports[arm] = {
            "raw": raw, "finish_reason": choice["finish_reason"],
            "valid_output": raw is not None,
            "factual_match": bool(raw is not None and all(raw[k] == v for k, v in expected.items())),
            "raw_status_correct": bool(raw and raw["action_status"] == "not_requested"),
            "prompt_tokens": inp, "completion_tokens": out, "known_microinr": cost,
            "elapsed_seconds": receipt["elapsed_seconds"],
        }
    primary = read(root / "audit.json")
    for arm in reports:
        assert reports[arm]["raw"] == primary["reports"][arm]["raw"]
        assert reports[arm]["factual_match"] == primary["reports"][arm]["factual_match"]
    assert known == primary["new_known_microinr"]
    assert retained == primary["new_retained_microinr"]
    return {
        "verified": True, "parent_episodes": 240,
        "parent_actor_terminals": dict(Counter(p["original"]["terminal"] for p in pairs)),
        "old_missing_episodes": [original["id"]], "new_calls": 2,
        "reports": reports, "new_known_microinr": known, "new_retained_microinr": retained,
        "no_native_or_tool_retry": True, "original_failure_preserved_in_snapshot": True,
        "one_case_not_two_independent_samples": True,
    }


if __name__ == "__main__":
    result = check(Path(sys.argv[1]))
    with Path(sys.argv[2]).open("x") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps(result, ensure_ascii=False))
