# Ordinary approval backend offline regression

Freeze explicit fixtures, requests and expected backend outcomes before the replay. This is deterministic local software evidence, not API/model accuracy. Compare the identical attempt/fixture with server approval enforcement off/on; identity,closed,version,idempotency and transaction checks remain on in both. The supplied caller, clock, global trusted-issuer registry and approvals are trusted application data. The model-facing argument schema cannot override them. This is a research backend, not production authentication or a deployed customer system.

The observed-pending reconstruction uses the saved model-selected booking/date/version/key and adds an explicit synthetic pending approval ID/record. That is added application metadata, not a literal replay of the old pipeline or a new model decision. Both control and candidate get the same added metadata. Do not claim the model learned to avoid the attempt.

Labels remain separate and are consumed only by the offline verifier, never backend.execute. Check actual receipts and final SQLite state including operation counts. Positive writes and duplicates matter equally: blocking every request fails. Malformed arguments,concurrency,rollback and read isolation are additionally covered by source-bound tests. No paid calls or large-comparison authorization is created by this replay.
