"""Verify the transcript diagnostic and offline backend controls without inference."""
import json
import sqlite3
import sys
import tempfile
from pathlib import Path

from benchmarks.sarvam_native_controls.transcript_finalizer import audit
from benchmarks.sarvam_native_controls.approval_replay import exercise
from benchmarks.sarvam_native_study import backend
from benchmarks.sarvam_native_study.transport import save

root = Path(sys.argv[1])
read = lambda p: json.loads(p.read_text())
diagnostic = root / "transcript-diagnostic"
result = audit(diagnostic)  # Denies networking; never accesses credentials.
assert result == read(diagnostic / "verification.json")
assert result["all_four_compatible_and_correct"] is True
histories = read(diagnostic / "histories.json")
labels = read(diagnostic / "expected.json")
for i, history in enumerate(histories):
    trace = [json.loads(m["content"]) for m in history["messages"] if m["role"] == "tool"]
    state = backend.state(diagnostic / f"provenance/m{i}/backend.sqlite")
    assert trace[-1]["status"] == labels[i]["action_status"] == "confirmed"
    assert trace[-1]["date"] == labels[i]["answer"] == state["date"]
    assert trace[-1]["version"] == state["version"]
# Verify carry-forward from the immediate prior completed ledger/verification.
prior = read(diagnostic / "provenance/immediate-prior-verification.json")
budget = read(diagnostic / "budget.json")
assert round(prior["research_known_inr"] * 1e6) == budget["prior_known_microinr"]
assert round(prior["research_retained_inr"] * 1e6) == budget["prior_retained_microinr"]
assert prior["research_calls"] == budget["prior_calls"]
with sqlite3.connect(f"file:{diagnostic}/provenance/immediate-prior-meter.sqlite?mode=ro", uri=True) as db:
    charge, known, count = db.execute("SELECT SUM(charged),SUM(usage_cost),COUNT(*) FROM calls").fetchone()
assert round(prior["known_inr"] * 1e6) == known
assert round(prior["retained_inr"] * 1e6) == charge
assert prior["calls"] == count == 4
with tempfile.TemporaryDirectory() as tmp:
    approval = exercise(root / "approval-regression", Path(tmp) / "replay")
    assert approval == read(root / "approval-regression/executed/results.json")
    from benchmarks.sarvam_native_controls.approval_backend import inspect_state
    for path in (root / "approval-regression/executed").glob("*.sqlite"):
        assert inspect_state(path) == inspect_state(Path(tmp) / "replay" / path.name)
save(Path(sys.argv[2]), {
    "verified": True, "new_api_calls": 4, "api_correct": 4, "backend_cases": 22,
    "backend_variants": 44, "focused_tests": 75, "network_access": False,
    "credential_access": False, "new_known_inr": result["known_inr"],
    "research_known_inr": result["research_known_inr"],
    "research_retained_inr": result["research_retained_inr"],
    "research_calls": result["research_calls"],
    "limits": "Two selected histories; backend is offline; same-code replay is not independent semantics",
})
print("Verified 4 raw model answers and 44 actual SQLite variants, without network or credentials.")
