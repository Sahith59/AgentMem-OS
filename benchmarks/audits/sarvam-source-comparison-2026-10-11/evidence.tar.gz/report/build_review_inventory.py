from pathlib import Path
import collections
import hashlib
import json
import statistics
from datetime import datetime, timezone

from benchmarks.sarvam_native_controls.integrated import read
from benchmarks.sarvam_native_study.transport import digest, save

track = Path('/Volumes/Sahith_SSD/AgentMem-OS/codex-memory-2026-09-08/tracks/sarvam')
phase = track / 'experiments/2026-10-11-ordinary-source-challenge'
report = track / 'experiments/2026-10-11-source-comparison-results'
summary = read(report / 'summary.json')
primary = read(report / 'verification.json')
attribution = read(report / 'attribution.json')
cases = {c['id']: c for c in read(phase / 'comparison-runtime.json')}
labels = read(phase / 'comparison-gold.json')
assert digest(primary) == summary['primary_sha256']
assert digest(attribution) == summary['attribution_sha256']
rows = summary['rows']
assert len(rows) == primary['episodes'] == summary['completed_episodes']
# Independent aggregation from the frozen replay outputs, without summary helpers.
for metric in ['raw_correct_report','application_correct_report','desired_state','prohibited_state_change','safe_task_success','strict_task_success','unnecessary_update_attempt']:
    assert sum(r[metric] for r in primary['rows']) == summary['totals'][metric]
for metric in ['factual_answer_correct','unsafe_change_truthfully_reported','safe_fact_and_state','raw_status_matches_execution','application_status_matches_execution']:
    assert sum(r[metric] for r in attribution['rows']) == summary['totals'][metric]
for group in summary['by_model_arm']:
    selected = [r for r in rows if (r['model'],r['enforce']) == (group['model'],group['enforce'])]
    assert group['episodes'] == len(selected)
    for metric in summary['totals']:
        if metric != 'episodes':
            assert group[metric] == sum(bool(r[metric]) for r in selected)
for pair in summary['pairs']['complete_pairs']:
    lookup = {r['id']:r for r in rows}
    a,b = lookup[pair['control_id']],lookup[pair['guard_id']]
    assert a['case_id'] == b['case_id'] and a['model'] == b['model']
    assert not a['enforce'] and b['enforce']
    for key, values in pair['transitions'].items():
        assert values == [a[key],b[key]]
save(report / 'independent-aggregation.json', {
    'verified': True, 'summary_sha256': digest(summary), 'primary_sha256': digest(primary),
    'attribution_sha256': digest(attribution), 'episodes': len(rows),
    'complete_pairs': len(summary['pairs']['complete_pairs']), 'new_calls': 0,
})

review = report / 'review-packets'
review.mkdir()
failed_cases = sorted({r['case_id'] for r in rows if not r['strict_task_success'] or not r['raw_correct_report'] or not r['factual_answer_correct']})
for case_id in failed_cases:
    selected = [r for r in rows if r['case_id'] == case_id]
    case = cases[case_id]
    evidence = []
    for row in selected:
        result = read(phase / 'comparison/episodes' / row['id'] / 'result.json')
        evidence.append({
            'id': row['id'], 'model': row['model'], 'enforce': row['enforce'],
            'terminal': row['terminal'], 'factual_correct': row['factual_answer_correct'],
            'desired_state': row['desired_state'], 'prohibited_change': row['prohibited_state_change'],
            'strict_success': row['strict_task_success'], 'raw_correct_report': row['raw_correct_report'],
            'raw_output': result.get('final'), 'application': result.get('application'),
            'application_error': result.get('application_error'),
            'tool_trace': result['tool_trace'],
            'initial_state': result['initial_backend'], 'final_state': result['final_backend'],
            'source_messages_sha256': digest(case['source_messages']),
        })
    save(review / f'{case_id}.json', {'case':case, 'gold':labels[case_id], 'episodes':evidence})
    brief = {
        'case_id':case_id, 'family':case['family'], 'question':case['question'],
        'source_messages':case['source_messages'],
        'expected_source_or_desired_answer':labels[case_id]['expected_answer'],
        'episodes':[{k:e[k] for k in ['id','model','enforce','terminal','factual_correct','desired_state','prohibited_change','strict_success','raw_correct_report','raw_output','application_error','tool_trace']} for e in evidence],
    }
    save(review / f'{case_id}.brief.json', brief)

table = ['# All episode outcomes (mechanical inventory; semantic review recorded separately)','', '| Episode | Fact true | Raw desired report | App desired report | Desired state | Unsafe change | Unnecessary call | Strict success |', '|---|---:|---:|---:|---:|---:|---:|---:|']
for row in sorted(rows,key=lambda r:r['id']):
    fields = [row[k] for k in ['factual_answer_correct','raw_correct_report','application_correct_report','desired_state','prohibited_state_change','unnecessary_update_attempt','strict_task_success']]
    table.append('| '+row['id']+' | '+' | '.join('yes' if value else 'no' for value in fields)+' |')
(report / 'ALL_EPISODES.md').write_text('\n'.join(table)+'\n')

usage = []
for model in sorted({r['model'] for r in primary['usage']}):
    selected = [r for r in primary['usage'] if r['model'] == model]
    known = [r for r in selected if r['usage']]
    reasoning = [(r['usage'].get('completion_tokens_details') or {}).get('reasoning_tokens') for r in known]
    reported_reasoning = [v for v in reasoning if type(v) is int]
    usage.append({
        'model': model, 'calls':len(selected),
        'prompt_tokens':sum(r['usage']['prompt_tokens'] for r in known),
        'completion_tokens':sum(r['usage']['completion_tokens'] for r in known),
        'calls_reporting_reasoning_tokens':len(reported_reasoning),
        'reported_reasoning_tokens':sum(reported_reasoning) if reported_reasoning else None,
        'sum_elapsed_seconds':sum(r['elapsed_seconds'] for r in selected),
        'median_elapsed_seconds':statistics.median(r['elapsed_seconds'] for r in selected),
        'maximum_elapsed_seconds':max(r['elapsed_seconds'] for r in selected),
    })
times = [(read(phase/'calls'/(r['id']+'.dispatch.json'))['dispatch_time'], r['elapsed_seconds']) for r in primary['usage']]
first = min(t for t,d in times)
last = max(t+d for t,d in times)
save(report / 'compute.json', {'models':usage, 'summed_latencies_overlap_under_concurrency':True,'same_caps_not_equal_actual_compute':True,'first_dispatch_utc':datetime.fromtimestamp(first,timezone.utc).isoformat(),'last_response_utc_approximate':datetime.fromtimestamp(last,timezone.utc).isoformat(),'dispatch_to_last_response_minutes_approximate':(last-first)/60,'missing_reasoning_telemetry_is_not_zero':True})
status_confusion = collections.Counter()
for row in rows:
    raw, app = row['raw_parsed'], row['application_output']
    status_confusion[(row['model'], raw['action_status'] if raw else 'NO_VALID_FINAL', app['action_status'] if app else 'NO_PROJECTION')] += 1
save(report / 'status-confusion.json', [
    {'model': key[0], 'raw_status': key[1], 'application_status': key[2], 'episodes': number}
    for key, number in sorted(status_confusion.items())
])
paired_counts = []
for model in sorted({p['model'] for p in summary['pairs']['complete_pairs']}):
    pairs = [p for p in summary['pairs']['complete_pairs'] if p['model'] == model]
    for metric in ('factual_answer_correct','desired_state','prohibited_state_change','safe_task_success','strict_task_success'):
        transitions = collections.Counter(tuple(p['transitions'][metric]) for p in pairs)
        paired_counts.append({'model':model,'metric':metric,'pairs':len(pairs),'both_true':transitions[(True,True)],'both_false':transitions[(False,False)],'false_to_true':transitions[(False,True)],'true_to_false':transitions[(True,False)]})
save(report / 'paired-counts.json', paired_counts)
lookup = {r['id']:r for r in rows}
readonly_repeats = []
for model in sorted({p['model'] for p in summary['pairs']['complete_pairs']}):
    pairs = [p for p in summary['pairs']['complete_pairs'] if p['model'] == model and cases[p['case_id']]['intent'] == 'read']
    transitions = collections.Counter(tuple(p['transitions']['factual_answer_correct']) for p in pairs)
    identical = 0
    for pair in pairs:
        outputs = [lookup[pair[key]]['raw_parsed'] for key in ['control_id','guard_id']]
        facts = [None if output is None else {k:output[k] for k in ['answer','needs_clarification']} for output in outputs]
        identical += facts[0] == facts[1]
    readonly_repeats.append({'model':model,'identical_initial_input_pairs':len(pairs),'both_factually_correct':transitions[(True,True)],'exactly_one_factually_correct':transitions[(True,False)]+transitions[(False,True)],'neither_factually_correct':transitions[(False,False)],'identical_final_factual_fields_including_missing':identical})
save(report / 'readonly-repeat-consistency.json', {
    'kind':'POST_HOC_DESCRIPTIVE_VIEW_OF_FROZEN_PAIRED_READ_TASKS',
    'models':readonly_repeats,
    'interpretation':'Approval enforcement is inactive in these read-only tasks. Outcome differences cannot be attributed to an approval guard. These are correlated synthetic pairs, not a population reliability estimate.',
    'new_calls':0,
})
save(report / 'review-inventory.json', {
    'episodes':len(rows), 'cases_requiring_raw_or_task_review':failed_cases,
    'affected_episodes':sum(not r['strict_task_success'] or not r['raw_correct_report'] or not r['factual_answer_correct'] for r in rows),
    'packets_prepared':True, 'semantic_review_status':'pending',
})
print(json.dumps({'totals':summary['totals'],'by_model_arm':summary['by_model_arm'],'cases_to_review':failed_cases,'compute':usage},indent=2))
