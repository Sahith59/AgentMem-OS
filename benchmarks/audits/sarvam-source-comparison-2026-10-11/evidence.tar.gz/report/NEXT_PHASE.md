# Next phase: isolate final reporting before proposing memory

Status: specific proposal based on the completed comparison; no new API calls or new promotion claim. Existing total INR6,000 authority carries forward. Notify the founder at execution; no duplicate blanket approval is needed within that scope. Freeze a separate manifest/budget before any request and preserve all old results.

## Question and one controlled change

Does replacing the ambiguous first sentence of the finalizer recover usable answers without adding factual mistakes? Control: exact existing finalizer. Candidate: change only its first sentence to “Answer the original service question using the evidence in the transcript below; do not repeat the question.” All remaining instructions, complete source/history, model profiles, temperature, output caps and answer/status contracts remain fixed. This tests one wording lever; do not silently filter history, change reasoning settings, upgrade a model or add retries in the same comparison.

The observed question echo motivates the wording test; it is not proof that wording caused the 18 empty outputs. A negative result is useful and must be preserved. Do not promise a score increase or invoke memory as the default next remedy.

## Prepare and execute in order

1. Build/test the candidate as a new reporter version. Verify exact one-sentence request differences, lossless source/history preservation, no gold passed to either arm, no executable tools and no database writes. Read-only and action histories must both be included.
2. Use **all 144 saved guarded histories** (72 inputs × two fixed models), not a selected set of misses. Generate one fresh control and one candidate answer for each: maximum288 finalization calls, no retries. Randomize/interleave order prospectively and retain identical caps/settings. This is development diagnosis on already observed inputs, not a holdout or fresh end-to-end benchmark.
3. Recompute the per-request worst-case reserve from exact payloads and frozen rates. Proposed retained ceiling INR300, provided the preflight worst-case calculation fits; otherwise revise preparation before execution. Carry INR196.384594 already retained within the original INR6,000 ceiling. Shared90RPM, at most4workers and the existing infrastructure-error stop apply. Do not spend simply to consume budget.
4. Grade with the already frozen actual-question contract and receipt-owned status; no runtime answer repair. Report null outputs, wrong dates, missing clarification, over-abstention, valid JSON, latency/tokens/cost, and paired gains/losses for each model. Publish all pairs and source review. Prospective screening gate: at least one model has net final-answer gains, neither model loses net correct answers, no increase in unsupported date assertions under source review, and no missing/unknown accounting. Counts, not a population significance claim. A passed screen supports fresh validation only.
5. If the screen passes, freeze a new small end-to-end confirmation with new scenario wording/instances and the same models. Correct awkward Hindi wording prospectively and seek native-language review. Check legitimate action completion and unnecessary attempts as well as answers; a reporting-only replay cannot fix the missed approved action. No finalizer adoption or memory claim before this check. If the screen fails, stop that candidate and investigate the empty-output transport/reasoning behavior with a separately bounded diagnostic, rather than repeat the same test.

## Product decision after evidence

Ordinary source availability, authorization, idempotency and honest status already address substantial portions of these tasks. A differentiated memory product needs new evidence of a persistent-information limitation after the ordinary integration works, followed by comparisons against strong ordinary storage/full-context controls. All Sarvam-supported languages remain the long-term scope; this phase covers synthetic EN/HI/TE only. No novelty or research-paper claim is earned yet.
