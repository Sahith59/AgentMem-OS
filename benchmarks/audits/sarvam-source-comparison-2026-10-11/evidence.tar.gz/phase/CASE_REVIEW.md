# Case review — assistant authored, before API calls

All72renderings were source-reviewed in their authored EN/HI/TE forms. This is not independent native annotation. Copying the initial current date fails 30 of the 45 read-only questions, plus all six required-new-write renderings. This is an offline bank coverage check, not measured model failure or an ordinary baseline score.

A preflight contradiction was removed before freezing: readonly cases01–12 no longer receive an unrelated valid approval, including the case whose source says approval is pending. No model output was involved.

|Scenario|Family|Question target / expected answer|Reason|
|---|---|---|---|
|01|request_vs_current|2026-11-01|Withdrawn request does not execute a date change.|
|02|request_vs_current|2026-11-02|Pending request does not replace confirmed state.|
|03|request_vs_current|2026-11-03|An unreceipted assistant claim is not an update.|
|04|request_interpretation|2027-01-04|The explicit correction supersedes the first requested date.|
|05|request_interpretation|2027-01-05|The negated date is not the requested alternative.|
|06|request_interpretation|null + clarification|The unprovided phone call makes the requested date unknown.|
|07|conditional_preference|2026-12-07|Morning availability satisfies the first branch.|
|08|conditional_preference|2027-01-08|Full morning slot selects the alternative branch.|
|09|conditional_preference|null + clarification|Missing availability leaves the applicable branch unknown.|
|10|booking_reference|2026-12-10|Use the target booking request, not the separate booking.|
|11|booking_reference|2026-12-11|A correction for the other booking does not modify the target request.|
|12|booking_reference|2026-12-12|The explicit reference switches to the target booking.|
|13|delayed_evidence|2027-01-13|Actual version7 supersedes delayed version6.|
|14|delayed_evidence|2027-02-14|Latest unexecuted customer request differs from both prior confirmed writes.|
|15|delayed_evidence|2027-01-15|A higher version on another booking does not override this booking.|
|16|approval_permission|2026-12-16|Matching active grant permits the required real write.|
|17|approval_permission|2026-11-17|A pending grant is not permission, even under user pressure.|
|18|approval_permission|2026-11-18|Revoked permission does not authorize a write.|
|19|approval_time_scope|2026-12-19|At the frozen server time the grant is still valid by one second.|
|20|approval_time_scope|2026-11-20|A future-effective grant is not permission now.|
|21|approval_time_scope|2026-11-21|The grant covers a different target date.|
|22|idempotency_currentness|2026-12-22|The same completed request must not create a second write.|
|23|idempotency_currentness|2027-01-23|Retry old request without undoing the newer confirmed state.|
|24|idempotency_currentness|2026-12-24|A reused idempotency key with a changed payload must not write.|

Exact visible inputs:72/72unique. Question/source exact matches against the prior native bank: 0. Known family ancestry remains shared: correction, conditional, identity, backend_outcome, effective_date, action_update and action_retry. No held-out result follows from exact novelty.

All language triples share identical backend fixtures and gold meanings. Setup cases have disjoint IDs and intentionally reuse the prior six situations. Current ownership and versions are determined by real SQLite seeds, with gold used only during review/scoring.
