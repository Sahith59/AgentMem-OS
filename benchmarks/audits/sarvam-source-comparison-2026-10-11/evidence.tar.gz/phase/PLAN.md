# Work order

1. Integrate receipt-owned status without rewriting raw model answers.
2. Review and freeze72challenge renderings plus separate12episode setup.
3. Run the bounded setup; replay every receipt/state transition and apply the new gate.
4. Only after a pass, freeze the288episode comparison for the following phase. No larger paid execution in this turn.
5. Publish independent code/evidence commits, merge after CI, update memory and verify founder files.
