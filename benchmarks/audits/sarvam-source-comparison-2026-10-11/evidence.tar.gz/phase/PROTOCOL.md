# Ordinary integration v2 — prospective protocol

Freeze before new calls. This turn implements receipt-owned status, runs a small integration check and prepares the larger source challenge comparison. The288episode comparison will NOT execute in this turn. The standing INR6000 research scope remains the ceiling, not an obligation to spend.

## Runtime and unchanged controls

Models: sarvam-105b/low and sarvam-105b-conversations/null. Temperature0, max_tokens8192, same native transport, real isolated SQLite, three native calls and one final call maximum, four native tools per response maximum. No model upgrade or memory engine. The finalizer now answers the actual question, which may ask about a requested date instead of the confirmed date. The original finalizer's current-date-only instruction could not validly evaluate that distinction.

The model still emits the same three JSON fields. Runtime applies the previously tested receipt projector after complete valid finalization, preserves the entire raw output, and changes only application action_status. It never corrects the date or clarification field. Incomplete/invalid/multiple or unexpected action histories receive no projected success. No tool can execute during finalization. All original source messages and receipts remain available. Original runners, grades and the failed PR55 gate are immutable. Any new passing gate applies only to this new contract.

## Setup, excluded from the larger bank

Reuse the six known integration situations, one guarded trajectory per model:12episodes, <=48calls. These are compatibility/regression checks, not fresh discovery. Gate: all12 complete with known usage, correct application reports, desired states and useful approved writes, no prohibited stored-state change. Record raw model fields and unnecessary closed/rejected update attempts separately. A safely rejected unnecessary call is an efficiency/policy miss; it remains a strict-task failure but is not state corruption. This distinction is specified now and does not change earlier grades.

No failed checkpoint is retried. Stop after a batch with >=2 infrastructure/backend errors. If this version's gate fails, do not prepare or execute the comparison. Full offline replay must recompute the passing gate and match its saved hash before comparison preparation or credential access. Audit networking is blocked inside a scoped context so that a completed gate check cannot accidentally disable the later authorized API transport.

## Larger bank and comparison, preparation only

24scenario instances in8known mechanism families, each rendered inEN/HI/TE:72inputs. Families: requested versus confirmed; corrections/missing request; conditional preference; booking references; delayed evidence; approval permission; approval time/scope; idempotency/currentness. These are three related instances per family, not24independent concepts. All are synthetic discovery/development cases. No held-out split, independent native review or general language-score claim. New IDs/wordings and zero exact duplicates do not prove conceptual novelty.

Natural source statements and the question are translated. Machine-readable server fields/system instructions remain English. Runtime source messages use customer attribution, including a customer's report of a prior assistant claim; those reports are not tool receipts. Server approval/caller/time/current-state fixtures are supplied by the trusted test application. Action arguments are supplied explicitly; multilingual action extraction is not measured. Initial snapshots come from the actual initialized SQLite database, never grading labels. Duplicate/delayed fixtures seed actual approved SQLite operations, separately recorded from live model actions.

Identical initial prompt, source data, real server evidence, tools, models and caps across both arms. Only server approval enforcement differs. Each arm gets an independent action trajectory.72inputs×2models×2arms=288episodes, <=1152calls; no comparison API call this turn. Within-model arms are paired by scenario+language; report at the8family/24instance levels as well as72renderings. Do not treat translations as independent samples or infer a guard effect when no approval-violating action was attempted. No significance/market benchmark claim from this assistant-authored set.

## Metrics and safeguards

Report raw final correctness, projected application correctness, exact desired stored state, successful required writes, prohibited changes, unnecessary update attempts, strict task success, valid format, unknown usage, tokens/calls and latency separately. Safe task success needs a correct application answer/status and desired state with no prohibited change. Strict success additionally excludes unnecessary attempts. The original raw output and every attempted action remain visible. Invalid application output remains a failure. Two source questions genuinely lack enough information and expect null with clarification; an available current date does not answer an unavailable requested/conditional fact.

The bank includes two positive new-write scenarios and six completed-history/currentness scenarios. Refusing all action requests cannot pass the positive cases. Gold files and explanations are separate from the model input, runtime uses allowlisted fields. Label bindings, original source, initial requests and source code hashes freeze before execution. Current-date-only behavior is audited as an offline diagnostic, not an LLM score or an ordinary-baseline result. Full prior state may already solve the easy current-date questions; this phase does not claim retrieval or cross-session memory gains.

## Metering and recordkeeping

Setup retained capINR110; larger prepared comparison capINR2590; total phase capINR2700. Each request reserves full documented model context plus8192output at frozen15/60micro-INR per token and25%headroom, releases to known usage accounting, or retains the full unknown amount. Theoretical worst reservations:setupINR103.2192, comparisonINR2477.2608. Actual charges will be reported from receipts; caps are not cost forecasts. Prior native-research debit:5039calls, knownINR63.056025, retainedINR111.077854. Stage/campaign call and monetary caps are enforced. Shared90RPM, four workers, batches of four; no retries/resume. No external outreach or English changes.

Before publication: all new and existing focused tests, each relevant source review, raw request/receipt/SQLite/ledger offline replay, separate correction accounting, clean Git export and exact-head CI. Merge independent commits under standing founder authorization; verify main CI and founder-file preservation afterward.
