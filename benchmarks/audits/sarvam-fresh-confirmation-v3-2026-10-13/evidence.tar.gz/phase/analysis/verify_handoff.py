import hashlib,json,sys
from pathlib import Path
from unittest.mock import patch
from benchmarks.sarvam_reporting_handoff import prepare_plan
from benchmarks.sarvam_native_study.transport import digest
root=Path(sys.argv[1]);out=Path(sys.argv[2]);read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();eid='confirm-fresh-13-en-m0';actor=eid+'-a0';paired_path=root/'episodes'/eid/'paired.json';before=sha(paired_path);paired=read(paired_path);native=paired['original'];request=read(root/'calls'/f'{actor}.request.json')['request'];receipt=read(root/'calls'/f'{actor}.receipt.json');case=next(c for c in read(root/'runtime.json') if c['id']==native['case_id'])
assert native['terminal']=='invalid_action_response' and all(paired['reports'][a]['terminal']=='not_reached' for a in ('control','candidate'))
with patch('socket.socket',side_effect=RuntimeError('Offline only')):
 plan=prepare_plan(actor_job=actor,actor_request=request,native_receipt=receipt,tool_trace=native['tool_trace'],initial_backend=native['initial_backend'],final_backend=native['final_backend'],actor_calls_used=len(native['calls']),caller_scope=case['caller'])
assert len(plan['reports'])==2 and plan['planned_total_calls']==3 and sha(paired_path)==before
for arm,report in plan['reports'].items():
 req=report['request'];assert 'tools' not in req and 'tool_choice' not in req
 assert json.loads(req['messages'][1]['content'])=={'original_messages':native['history'],'original_tool_definitions':request['tools']}
source=Path(__import__('benchmarks.sarvam_reporting_handoff',fromlist=['x']).__file__)
result={'verified':True,'mode':'OFFLINE_PREPARATION_ONLY_NO_DISPATCH','episode':eid,'original_paired_sha256_unchanged':before,'original_terminal':native['terminal'],'original_reporter_slots_still_not_reached':True,'source_sha256':sha(source),'plan_sha256':plan['plan_sha256'],'reporter_request_sha256':{a:r['request_sha256'] for a,r in plan['reports'].items()},'new_provider_calls':0,'new_tool_actions':0,'credential_read':False,'claim_file_created':False,'planned_total_calls_if_future_scope_authorized':3,'live_accuracy_gain_measured':False,'limitations':'Caller authenticates artifacts and scope, provides stable claim storage and enforces spend. This plan is not an original result or a live recovery.'}
with out.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result))
