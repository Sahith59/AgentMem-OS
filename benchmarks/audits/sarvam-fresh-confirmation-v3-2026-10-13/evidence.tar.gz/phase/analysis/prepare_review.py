# Offline summary and review packet. No project code imported, credentials read or model calls.
import json,sys
from pathlib import Path
from collections import defaultdict
root=Path(sys.argv[1]); read=lambda p:json.loads(p.read_text()); v=read(root/'verification.json'); cases={c['id']:c for c in read(root/'runtime.json')}
metrics=['valid_final','factual_answer_correct','safe_fact_and_state','strict_task_success','raw_status_matches_execution','raw_fully_correct','non_null_answer_mismatch','desired_state','missed_required_write','unnecessary_update_attempt','prohibited_state_change']
slices=[]
for dimension in ['language','family']:
 for model in sorted({r['model'] for r in v['rows']}):
  for key in sorted({cases[r['case_id']][dimension] for r in v['rows']}):
   item={'dimension':dimension,'value':key,'model':model,'arms':{}}
   for arm in ['control','candidate']:
    rows=[r for r in v['rows'] if r['model']==model and r['variant']==arm and cases[r['case_id']][dimension]==key]
    item['arms'][arm]={'n':len(rows),**{m:sum(bool(r[m]) for r in rows) for m in metrics},'date_correct':sum(bool(r['raw'] is not None and r['raw']['answer']==r['actual_question_answer']['answer']) for r in rows),'clarification_correct':sum(bool(r['raw'] is not None and r['raw']['needs_clarification']==r['actual_question_answer']['needs_clarification']) for r in rows)}
   slices.append(item)
byid=defaultdict(dict)
for row in v['rows']:byid[row['id']][row['variant']]=row
flagged=[];packet=[]
for id,arms in byid.items():
 a,b=arms['control'],arms['candidate']; c=cases[a['case_id']]
 flags=[]
 if not a['factual_answer_correct'] or not b['factual_answer_correct']:flags.append('factual_miss')
 if a['raw']!=b['raw']:flags.append('changed_output')
 if not a['raw_status_matches_execution'] or not b['raw_status_matches_execution']:flags.append('raw_status_miss')
 if a['missed_required_write']:flags.append('missed_required_write')
 if a['unnecessary_update_attempt']:flags.append('unnecessary_attempt')
 if a['prohibited_state_change']:flags.append('forbidden_change')
 if flags:
  original=read(root/'episodes'/id/'result.json'); flagged.append({'id':id,'flags':flags})
  packet.append({'id':id,'case_id':c['id'],'model':a['model'],'language':c['language'],'family':c['family'],'flags':flags,'question':c['question'],'source_messages':c['source_messages'],'expected':a['actual_question_answer'],'control':a['raw'],'candidate':b['raw'],'tool_trace':original['tool_trace'],'actor_messages':[m for m in original['history'] if m['role']=='assistant'],'initial_backend':original['initial_backend'],'final_backend':original['final_backend'],'grades':arms})
for name,obj in [('slice-summary.json',slices),('review-packet.json',packet),('review-inventory.json',{'all_outputs':len(v['rows']),'episodes':len(byid),'flagged':flagged,'remaining_matching_correct':[k for k in byid if k not in {f['id'] for f in flagged}]})]:
 with (root/name).open('x') as f:json.dump(obj,f,ensure_ascii=False,indent=2);f.write('\n')
print({'outputs':len(v['rows']),'flagged_episodes':len(flagged)})
