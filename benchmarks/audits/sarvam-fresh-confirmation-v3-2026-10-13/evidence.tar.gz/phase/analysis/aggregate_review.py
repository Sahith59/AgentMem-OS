"""Combine explicit assistant judgments; validate against raw output, never create judgments."""
import hashlib,json,sys
from pathlib import Path
from datetime import datetime,timezone
root=Path(sys.argv[1]);read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
audit=read(root/'verification.json');assert audit['verified'] and audit['native_episodes']==240
manifest=read(root/'manifest.json');expected={j['id'] for j in manifest['jobs']};assert len(expected)==240
scored={(r['id'],r['variant']):r for r in audit['rows']}
review_files={};episodes=[];covered=set();pending=[]
for lang in ('en','hi','te'):
 paths=[p for p in sorted(root.glob(f'semantic-review-{lang}-*.json')) if not p.name.endswith('-complete.json')]
 rows=[];reviewers=[]
 for p in paths:
  obj=read(p);parts=obj.get('rows',obj.get('cases'))
  assert isinstance(parts,list),(p,'missing rows')
  for row in parts:
   eid=row.get('episode_id',row.get('id'));assert eid in expected and f'-{lang}-' in eid and eid not in covered,(p,eid,'duplicate or unexpected')
   covered.add(eid); paired_path=root/'episodes'/eid/'paired.json';paired=read(paired_path)
   existing_hash=row.get('paired_sha256',row.get('raw_hashes',{}).get('paired_file_sha256'))
   if existing_hash:assert existing_hash==sha(paired_path)
   assert not row.get('source_gold_disagreement',False),(eid,'source label disagreement requires adjudication')
   assert not row.get('source_gold_ambiguous',False),(eid,'source ambiguity requires adjudication')
   assert not row.get('question_ambiguity_detected',False),(eid,'ambiguity requires adjudication')
   judgments=row.get('reports',row)
   for variant in ('control','candidate'):
    judgment=judgments[variant]; raw=judgment.get('raw',judgment.get('raw_output'));actual=paired['reports'][variant].get('parsed')
    assert raw==actual,(eid,variant,'review differs from raw parsed output')
    score=scored[eid,variant]
    if 'primary_factual_correct' in judgment: factual=judgment['primary_factual_correct'];status=judgment['raw_status_correct']
    elif 'factual_match' in judgment:factual=judgment['factual_match'];status=judgment['raw_status_match']
    else:
     assert judgment['factual_verdict'] in ('correct','incorrect','no_usable_final')
     assert judgment['raw_status_verdict'] in ('correct','incorrect','no_usable_final')
     factual=judgment['factual_verdict']=='correct';status=judgment['raw_status_verdict']=='correct'
    assert factual==score['factual_answer_correct'],(eid,variant,'semantic/scorer factual disagreement')
    assert status==score['raw_status_matches_execution'],(eid,variant,'semantic/scorer raw-status disagreement')
    reviewers.append({'episode_id':eid,'variant':variant,'factual_verdict':'correct' if factual else 'incorrect','status_verdict':'correct' if status else 'incorrect','source_review_file':p.name,'paired_file_sha256':sha(paired_path),'raw_content_sha256':hashlib.sha256((paired['reports'][variant].get('content') or '').encode()).hexdigest(),'review':judgment})
   rows.append({'episode_id':eid,'source_review_file':p.name,'source_review':row});episodes.append({'id':eid,'reporters':['control','candidate'],'source_gold_ambiguous':False})
 wanted={eid for eid in expected if f'-{lang}-' in eid};assert {r['episode_id'] for r in rows}==wanted and len(rows)==80
 output={'status':'ASSISTANT_LANGUAGE_REVIEW_COMPLETE','language':lang,'created_at_utc':datetime.now(timezone.utc).isoformat(),'independent_native_human_review':False,'reviewed_episode_ids':[j['id'] for j in manifest['jobs'] if j['id'] in wanted],'reporter_reviews':sorted(reviewers,key=lambda x:(x['episode_id'],x['variant'])),'source_review_files':{p.name:sha(p) for p in paths},'rows':rows,'raw_and_scoring_consistency_verified':True,'limitations':['Assistant judgments are not independent native-speaker review.','A clarification-contract miss is recorded separately from a wrong non-null date.','Cases are synthetic related scenarios and development-exposed.']}
 destination=root/f'semantic-review-{lang}-complete.json'
 data=(json.dumps(output,ensure_ascii=False,indent=2)+'\n').encode();pending.append((destination,data))
 review_files[lang]={'file':destination.name,'sha256':hashlib.sha256(data).hexdigest()}
assert covered==expected
aggregate={'status':'ASSISTANT_LANGUAGE_REVIEW_COMPLETE','parent_verification_sha256':sha(root/'verification.json'),'episodes':[next(e for e in episodes if e['id']==j['id']) for j in manifest['jobs']],'review_files':review_files,'episode_count':240,'reporter_slot_count':480,'actual_reporter_calls':sum(1 for p in (root/'calls').glob('*-final-*.receipt.json')),'unreached_reporter_slots':sum(r['terminal']=='not_reached' for r in audit['rows']),'independent_native_human_review':False,'all_reviewed_outputs_match_saved_outputs_and_frozen_grading':True,'review_is_not_evidence_of_product_novelty':True,'complete_live_comparison':audit['complete'],'missing_outputs_are_reviewed_as_missing_not_fabricated':True}
pending.append((root/'semantic-review.json',(json.dumps(aggregate,ensure_ascii=False,indent=2)+'\n').encode()))
assert not any(p.exists() for p,_ in pending)
for p,data in pending:
 with p.open('xb') as f:f.write(data)
print({'episodes':240,'reporter_slot_reviews':480,'actual_reporter_calls':aggregate['actual_reporter_calls'],'unreached_reporter_slots':aggregate['unreached_reporter_slots'],'verified_review_files':review_files})
