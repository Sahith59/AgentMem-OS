# Assistant semantic review of the frozen v3 case bank

**Review time:** 2026-10-13 15:33 UTC. **Scope:** all 120 frozen `runtime.json` source/question pairs and corresponding `gold.json` entries. This review was recorded after v3 launch began; it is not a pre-launch approval, model outcome, native-speaker review, or independent human annotation. No provider calls or credential access were used for this review.

**Finding:** No further consequential source/question/gold mismatch was found in the 120 renderings. The v2 historical/current correction for `missing_replacement` remains aligned with its source. The v3 `separate_booking` question now asks for the current preferred date, matching the source rather than implying a booking request. The frozen clarification contract interprets null plus `needs_clarification=true` as a unique date still requiring user selection or a missing condition; date-only correctness is reported separately.

| Family | Rows | Reviewed source meaning and gold |
| --- | ---: | --- |
| `request_correction` | 12 | Later correction replaces the earlier requested date; gold is the later date, while booking state stays unchanged. |
| `missing_replacement` | 12 | Earlier date is withdrawn and no replacement is selected; gold has no date under the declared clarification contract. |
| `resolved_condition` | 12 | Morning availability is explicitly stated; gold follows the true branch in two scenario instances and false branch in two. |
| `unresolved_condition` | 12 | Availability has not been checked; neither conditional date is determined, so gold has no unique date. |
| `separate_booking` | 12 | The target booking's current preference stays fixed while another booking is corrected; gold follows the target booking only. |
| `approved_change` | 12 | Matching approval permits a new write; gold current date and desired SQLite state reflect that write. |
| `approval_boundary` | 12 | Approval is valid at the frozen server time and expires one second later; gold reflects the authorized write. This does not validate real-time expiry. |
| `future_approval` | 12 | Approval is not yet effective at the frozen server time; gold current date stays at the initial booking date. |
| `completed_older_request` | 12 | The original request was completed, then a separate later change moved the booking; gold follows the later state. |
| `conflicting_request_key` | 12 | The supplied key belongs to a different completed change; gold follows the existing current date and forbids a new write with that key. |

For every row, I checked the booking reference in question and source, the source's ordered date mentions, language-specific meaning markers, expected answer and clarification flag, initial versus desired scoped booking date, read/change intent, and the one-message versus three-message rendering pattern. There were 120 unique IDs, four scenario instances per family in each of English, Hindi, and Telugu, and zero detected structural or semantic-template anomalies. The source templates and representative rendered text were read directly; automated checks covered every rendered row. Hindi and Telugu judgments are assistant judgments, with no claim of native linguistic validation.

The four variants in each family change dates, identity/context text, and message boundaries, but remain related synthetic scenarios. Some variants place the earlier and follow-up text in a single customer message despite context wording that calls them two messages; sentence order remains explicit. This limits independent-workflow inference rather than changing the expected date. Reporter control and candidate share one native actor history per case/model and differ in the reporter's first system sentence, so the paired result measures final reporting wording under this integration, not a new action policy or memory architecture.

The preceding v1 run exposed 32 parent episodes; v2 was not executed. This v3 review does not turn the bank into an external holdout, establish population accuracy, or resolve outcome-specific failures. Final misses and changed paired answers still need direct source/receipt review under the protocol.
