# Sarvam track — start here

Read [CURRENT_STATE.md](CURRENT_STATE.md), [RUNBOOK.md](RUNBOOK.md), [DECISIONS.md](DECISIONS.md) and the latest [daily record](daily/2026-10-12.md). This fork owns Sarvam investigation; preserve the separate English worktree/current state. Shared workspace agreements remain authoritative.

Current phase: fresh confirmation stopped after32/240episodes because of our question ambiguity;111calls fully accounted/replayed. No promotion, no active inference. V2 corrects12questions without selecting cases and is frozen/unexecuted. See [report](experiments/2026-10-11-fresh-workflow-confirmation/REPORT.md), [failure review](experiments/2026-10-11-fresh-workflow-confirmation/FAILURE_REVIEW.md), [v2nextstep](experiments/2026-10-11-fresh-workflow-confirmation-v2/NEXT_STEP.md).

We are still investigating the product problem. Conditional evidence handling has concrete failures in the observed ordinary integration; neither cause nor a unique multilingual memory advantage is proven. No new memory system is selected. Intended eventual language scope follows relevant Sarvam services; EN/HI/TE diagnostics do not establish all-language support. A reviewed public benchmark remains required; these related development cases are not it.

- [Complete prior research history](experiments/2026-10-11-reporter-wording/SARVAM_HISTORY.md)
- [Last completed saved-history reporting result](experiments/2026-10-11-reporter-wording/REPORT.md)
- [Findings](FINDINGS.md), [running notes](RUNNING_NOTES.md), [source notes](SOURCE_NOTES.md)
- [Dated research and benchmark proposal](research/2026-10-08/RESEARCH_REPORT.md)

Standing total native-research ceiling INR6000; carry6191calls/known179.979855/retained257.233050. Older pilot accounting is separate. Never repeat a started/failed manifest. API keys remain outside the workspace; offline checks use none. Assistant language review is authorized; independent review remains missing. Frozen expected answers are audit-only.

Use `.worktrees/sarvam-foundation`, independent commits and reference PRs merged after verification. PR59 publication is complete: four commits merged, exact PR/main CI pass, 170 focused tests and 543 artifact hashes verify, both audits and v2 regeneration reproduce. Public README/roadmap/index and description are updated. See the current completion receipt. The old foundation plan and stacked runbook notices are preserved under history with supersession pointers. Do not treat historical prices/plans/active labels as current, or claim exhaustive file coverage from this scoped update.
