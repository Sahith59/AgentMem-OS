# Sarvam research runbook

Current execution status is always [CURRENT_STATE.md](CURRENT_STATE.md). This runbook is operational guidance; historical results and authorization are preserved in the decision log. The [previous runbook](history/2026-10-11-before-fresh-confirmation-runbook/RUNBOOK.md) contains superseded active/unstarted notices and historical commands.

## Closed phase: fresh workflow confirmation v1

Root: `experiments/2026-10-11-fresh-workflow-confirmation`. Code commit `370dd51`. Read its `PROTOCOL.md`, `manifest.json`, `review.json`, `budget.json` and `preflight.json`. The manifest is closed after32episodes for question ambiguity: **never restart it or resend any attempted call.** Four workers, shared 90 RPM, no automatic retries. The existing INR 6,000 total authority includes prior retained amounts; it is not renewed per turn. The phase is bounded to 1,200 calls and INR 2,600 retained. There is no authorization for unrelated experiments.

Once the process exits and `execution.json` exists, run the offline audit to a new output path:

```sh
python -m benchmarks.sarvam_fresh_confirmation.audit ROOT --output ROOT/verification.json
python ROOT/analysis/independent_check.py ROOT ROOT/independent-aggregation.json
```

The primary audit blocks networking and reads no credential. The second independently parses raw response JSON, inspects actual SQLite state and checks token arithmetic; it is a second implementation by the same assistant, not independent human review. Match complete inventories, hashes, source code, requests, receipts, model IDs, paired histories, actual backend state and the durable meter. No grade or expected state may enter a generation request.

Review every miss and changed pair against the frozen original source, including raw status-only differences. Keep action completion separate from factual reporting. A correct old date after a missed approved action is not task success. Preserve null/empty outputs, provider failures, unnecessary attempts and unauthorized changes. Application status can come from receipts; the projector cannot repair dates or clarification. A mechanical pass requires a separately documented semantic review. Any candidate stays unpromoted until the stated gate is actually satisfied; a pass supports only an ordinary integration improvement.

## Publication and memory

Use isolated `.worktrees/sarvam-foundation`; preserve the founder's dirty/untracked files and the English track. Commit code, documentation and evidence independently. Publish reviewable artifacts through the reference PR; merge after required checks. Validate a clean Git export, exact PR-head and merged-main CI, all artifact hashes, offline replay and founder/English preservation. Record completion separately from research outcome. Never expose API credentials or private founder inventories in an archive.

Update Sarvam CURRENT_STATE, README, running notes, decisions, findings when warranted, daily record and run-specific reports each turn. Public README/research index/description must state only completed evidence and actual limitations. Historical documents remain dated evidence, not current capabilities. Do not rewrite old failed gates into passes. Do not claim that all documents or every file was re-audited without corresponding coverage evidence.

## Completed phases

- PR58 reporter wording: 288 calls on saved histories; base59/72→72/72, Conversations70/72→71/72. No new actions. Replay instructions in the public `sarvam-reporter-wording-2026-10-11/README.md`; never restart.
- PR57 ordinary source comparison: 288 episodes/723 calls. Unsafe unguarded writes, missed approved action, empty reporting and status corrections are preserved in `sarvam-source-comparison-2026-10-11/`.
- Earlier study controls and small memory pilots: [complete research history](experiments/2026-10-11-reporter-wording/SARVAM_HISTORY.md). Historic approval and usage limitations remain in their original ledgers.

Before this active phase, native accounting is 6,080 calls, INR 169.754685 known estimate / INR 244.451544 retained. Earlier separately authorized pilots add 247 calls / INR 4.400490 known; older unknown usage remains unpriced. Actual updated accounting comes from the completed phase audit, not this dated carry. These estimates are not invoices or account balances.


## S-067 closure supersedes the active-run paragraph above

V1 is CLOSED after an operator stop for question ambiguity,32episodes/111known calls. Never resume. `interruption-reconciliation.json` records how execution.json was reconstructed from complete worker results after exit130. Both audits agree. Currentcarry257.233050retained; no inference active. V2at `experiments/2026-10-11-fresh-workflow-confirmation-v2` is FROZEN_UNEXECUTED; only12questions/runtimebindings change, allcasesretained. Correctedbuilder is `benchmarks.sarvam_fresh_cases_v2`; original cases.py remains historicalv1. Follow v2PROTOCOL/readiness/NEXT_STEP before any future paid launch. No secondpaidphase thisturn.


## S-068 — publication complete; stopped screen stays stopped

October 12, 2026. PR59 merged four independent commits at `7f9111b305282c842d77c71e75cb20966ba2b793`. Exact PRCI38202171232 and merged-mainCI38202488631 pass. Clean export checks all543artifactfiles, reproduces both audits and the corrected v2bank, and passes170focusedtests. Both worktrees equal origin/main and the tested tree. All6,992protectedfounderfiles/status and rootEnglishCURRENT_STATE remain unchanged. Public description is read back again and matches the corrected text. Current README, Indic roadmap, English same-answer judge-bridge pointer and Sarvam research index are merged. Shared memory now routes Sarvam to its dedicated current state; dated historical plans are qualified rather than rewritten as current.

Research outcome is unchanged: v1stopped after32/240episodes and111calls for our historical/current question ambiguity; no candidate promotion. All started workers finish, all calls replay with known usage, no retries or secondpaidphase. V2retains all120cases, changes12questions/hashbindings only, and remains frozen/unexecuted. Observed known/unknown-condition mistakes are concrete leads, not proof of their cause, a memory gap or novel product value. Assistant language review only; independent review absent. Nativecarry6191calls/knownINR179.979855/retainedINR257.233050 within originalINR6000total. `completion.json` is authoritative for final publication status; no inference remains active.
