"""Separate raw-response parser and token accounting; no project imports or network."""
import hashlib,json,sqlite3,sys
from pathlib import Path
from collections import defaultdict
r=Path(sys.argv[1]);read=lambda p:json.loads(p.read_text());primary=read(r/'verification.json');manifest=read(r/'manifest.json');execution=read(r/'execution.json');parent=r/'provenance/parent';cases={c['id']:c for c in read(parent/'runtime.json')};labels=read(parent/'gold.json');inputs={h['id']:h for h in read(r/'inputs.json')}
known=retained=unknown=0;rows=[]
with sqlite3.connect(f'file:{r}/calls/meter.sqlite?mode=ro',uri=True) as db:ledger={x[0]:x[1:] for x in db.execute('SELECT id,stage,reservation,charged,usage_cost,status FROM calls')}
assert set(ledger)=={x['id'] for x in execution['outcomes']}

def parse(body,status):
 try:
  c=body['choices'][0];m=c['message']
  if status!=200 or c['finish_reason']!='stop' or m.get('tool_calls'):return None
  items=json.loads(m['content'],object_pairs_hook=lambda x:x)
  if not isinstance(items,list) or len(items)!=3:return None
  raw=dict(items)
  if len(raw)!=3 or set(raw)!={'answer','needs_clarification','action_status'}:return None
  if not(raw['answer'] is None or isinstance(raw['answer'],str)) or type(raw['needs_clarification']) is not bool or raw['action_status'] not in {'not_requested','not_performed','confirmed','rejected','already_applied'}:return None
  return raw
 except (ValueError,TypeError,KeyError,IndexError):return None

for job in manifest['jobs'][:len(execution['outcomes'])]:
 jid=job['id'];receipt=read(r/'calls'/f'{jid}.receipt.json');request=read(r/'calls'/f'{jid}.request.json')['request'];stage,reserved,charged,cost,status=ledger[jid]
 try:body=json.loads(receipt.get('body_text',''))
 except (TypeError,ValueError):body={}
 usage=body.get('usage')
 if status=='known':
  assert cost==15*usage['prompt_tokens']+60*usage['completion_tokens'];assert usage['total_tokens']==usage['prompt_tokens']+usage['completion_tokens'];assert charged==(cost*5+3)//4;known+=cost
 else:assert status=='unknown' and cost is None and charged==reserved;unknown+=1
 retained+=charged;h=inputs[job['history_id']];c=cases[h['case_id']];g=labels[c['id']];p=read(parent/'episodes'/h['id']/'paired.json');original=p['original']
 # This source-selected screen has only read-only conditional source questions.
 assert g['question_target']=='source_request_or_condition' and c['intent']=='read'
 expected=g['expected_answer'];raw=parse(body,receipt.get('status'));updates=[t for t in original['tool_trace'] if t['name']=='update_appointment'];expected_status='not_requested'
 if any(s['arguments']==c['requested_change'] for s in original['seed_receipts']):expected_status='already_applied'
 if updates:expected_status=updates[-1]['response'].get('status')
 factual=bool(raw and {k:raw[k] for k in ('answer','needs_clarification')}==expected);status_ok=bool(raw and raw['action_status']==expected_status)
 official=next(x for x in primary['rows'] if x['id']==jid)
 for k,v in {'raw':raw,'valid_final':raw is not None,'factual_answer_correct':factual,'raw_status_matches_execution':status_ok,'actual_question_answer':expected}.items():assert official[k]==v,(jid,k)
 rows.append({'id':jid,'history_id':h['id'],'case_id':c['id'],'family':c['family'],'language':c['language'],'model':h['model'],'arm':job['arm'],'factual_correct':factual,'date_correct':bool(raw and raw['answer']==expected['answer']),'clarification_correct':bool(raw and raw['needs_clarification']==expected['needs_clarification']),'raw_status_correct':status_ok,'nonnull_mismatch':bool(raw and raw['answer'] is not None and raw['answer']!=expected['answer']),'invalid_final':raw is None,'expected':expected,'raw':raw,'usage':usage,'elapsed_seconds':receipt['elapsed_seconds'],'input_characters':sum(len(m['content']) for m in request['messages']),'omitted_fields':len(read(r/'omissions'/f'{jid}.json'))})
assert len(rows)==primary['calls']==len(ledger);assert primary['known_inr']==known/1e6 and primary['retained_inr']==retained/1e6 and primary['unknown_calls']==unknown
byhistory=defaultdict(dict)
for row in rows:byhistory[row['history_id']][row['arm']]=row
pairs=[]
for history,arms in byhistory.items():
 for a,b in [('chronological','grouped_lossless'),('grouped_lossless','grouped_actor_prose_withheld'),('chronological','grouped_actor_prose_withheld')]:
  if a not in arms or b not in arms:continue
  x,y=arms[a],arms[b];pairs.append({'history_id':history,'model':x['model'],'language':x['language'],'family':x['family'],'from':a,'to':b,'gain':not x['factual_correct'] and y['factual_correct'],'loss':x['factual_correct'] and not y['factual_correct'],'raw_changed':x['raw']!=y['raw']})
out={'verified':True,'rows_checked':len(rows),'calls':len(ledger),'known_inr':known/1e6,'retained_inr':retained/1e6,'unknown_calls':unknown,'project_evaluator_imported':False,'new_model_calls':0,'credential_read':False,'rows':rows,'pairs':pairs,'limitation':'Separate parser and arithmetic by the same assistant; not independent human/native-language validation.'}
with Path(sys.argv[2]).open('x') as f:json.dump(out,f,ensure_ascii=False,indent=2);f.write('\n')
print({k:v for k,v in out.items() if k not in ('rows','pairs')})
