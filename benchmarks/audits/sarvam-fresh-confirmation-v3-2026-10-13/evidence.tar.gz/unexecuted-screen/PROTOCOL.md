# Evidence organization and actor-prose screen

Prepared October 13, 2026. Status: PROSPECTIVE, UNEXECUTED. Execution may start only after the corrected v3 comparison completes, its full offline audit reproduces, and all 240 episodes / 480 reporter outputs have recorded assistant semantic review. The founder authorized continuing the research within the existing total ₹6,000 cap. This document does not renew that cap. Announce the concrete run before execution. Stop after this bounded comparison and report every outcome; no repeat-until-positive loop.

## Question

Does arranging the same available evidence by source authority help the reporter answer conditional preferences? Does withholding the earlier actor's prose help beyond grouping? These are integration hypotheses. The source is already present, so this is not a test of missing-memory retrieval. No novelty, multilingual memory advantage, or industry benchmark score follows.

Selection was saved at 15:55:26 UTC before any screen outputs: six scenario instances, two each with a known-true, known-false, or unresolved condition; every English/Hindi/Telugu rendering and both fixed model profiles. Eighteen renderings produce 36 saved native histories and 108 new reporter calls. Selection uses the recorded source-only hash rule. These cases are related, development-exposed and assistant-reviewed, not a holdout. Do not substitute cases after seeing results. Preserve the source-selection record and its timestamp.

## Three arms

A: chronological original evidence, including source messages, actor prose, tool definitions, proposals and actual receipts.

B: the same evidence grouped into source, execution, actor claims and protocol context. Exact message order and original values remain reconstructable. No semantic summary, new fact, inferred condition state, selected answer or extra evidence enters this arm.

C: B with nonempty string values in earlier assistant `content`, `reasoning_content` and `refusal` fields removed. Preserve empty/null fields, actor tool-call proposals, all customer/source text and all receipts. Reject unknown actor fields or unexpected nontext prose types. A local omission ledger records the message index, field and original value hash. No `withheld` token replaces the removed field; hashes already in the view remain provenance pointers, not a claim that C is lossless. No omission ledger or duplicate original-history sidecar is included in the model request. Reviewers know parent source labels; this is explicitly not blind review. The renderer and paid path hash archived gold bytes without parsing labels, and no grading field enters a request.

A→B isolates grouping/provenance presentation. B→C isolates removal of actor prose. A→C is supplementary. All arms use one common first sentence, “Answer the original service question using the evidence in the supplied source record; do not repeat the question.” The remainder of FINAL_INSTRUCTION, JSON schema, endpoint, temperature 0, model, reasoning setting and 8,192 output-token cap are identical. Use sarvam-105b/low and sarvam-105b-conversations/null. Historical v3 reporter outputs are context, not this comparison's control.

No fresh actor execution, backend update, retrieval call, extra verifier, stronger model, output repair or retry is allowed. Ordinary receipt projection may change execution status only; it cannot repair the date or clarification flag. The three arms have equal call count and maximum output allowance, not necessarily equal input tokens or actual compute. Report actual usage, input sizes and latency separately.

## Execution and accounting

Exactly one new call for each of 108 frozen requests. Shuffle histories with fixed seed 202610133; rotate A/B/C order separately within each model so each arm has each position six times per model. Four workers, batches of four, shared 90 RPM pacing under the founder's 120 RPM limit. No automatic retry or restart. Stop after a batch containing at least two infrastructure-error calls. Empty/invalid/capped answers remain completed failures; infrastructure errors make the screen incomplete.

Conservative reservation: ₹232.243200 for all 108 full-context calls, with ₹240 phase cap. Carry forward calls, known usage estimate and retained reservation exactly from the completed v3 audit. The combined retained amount plus new worst-case reservation must stay within the original ₹6,000 cap. Use published input/output rates ₹15/₹60 per million tokens, ignore cache discounts and retain 25% headroom; these are usage estimates, not an invoice or account balance. Unknown usage retains full reservation. Freeze source, requests, selection, parent evidence, review, protocol and budget hashes before execution.

## Outcomes and decision

Primary outcomes: exact source-supported date plus clarification contract, paired A→B and B→C gains/losses separately for each model. Supplementary: date-only correctness, unknown-condition definite answers, unnecessary abstention for known conditions, current/requested-date confusion, empty or capped outputs, raw status accuracy, projected status accuracy, safe task completion, token use and latency. Report every language and condition slice, with actual denominators. Related translations are not independent trials; do not present a naive binomial confidence interval or a small-screen score as a broad accuracy estimate.

Preserve all attempts and raw outputs. Replay classification, request bytes, receipt linkage, usage and omission checks offline with network disabled. Verify every original message reconstructs in B and that C changes exactly its declared fields. Review all 108 outputs against the original source, including correct and failed outputs, and disclose source/label uncertainty rather than silently altering gold.

A useful lead requires paired recoveries that are genuine source-supported answers, not just parser changes or overwritten dates; enumerate regressions and unsupported definite answers alongside gains. A net gain in one model does not offset regression in the other. A positive screen can justify a separately frozen fresh robustness test; it cannot promote this prototype to a production default. A negative screen rejects this layout/omission hypothesis under these conditions and should redirect work to the demonstrated failure mechanism. No additional wording sweep or paid follow-up is part of this phase.
