# Revised question review — v2

Assistant review only.12questions change; all source messages, labels and backend fixtures remain unchanged. This is not a new holdout.

## fresh-05-en
Before: Which date did I most recently request for VISIT-2105? Read only.
After: Which replacement date do I currently want for VISIT-2105? Read only; do not change the booking.
Expected: no currently selected replacement; null with clarification. A historical withdrawn date is not the currently wanted replacement.

## fresh-05-hi
Before: VISIT-2105 के लिए मैंने सबसे हाल में कौन सी तारीख मांगी? केवल बताएं।
After: VISIT-2105 के लिए अभी मुझे कौन सी नई तारीख चाहिए? केवल बताएं; बुकिंग न बदलें।
Expected: no currently selected replacement; null with clarification. A historical withdrawn date is not the currently wanted replacement.

## fresh-05-te
Before: VISIT-2105 కోసం నేను చివరిగా కోరిన తేదీ ఏమిటి? చెప్పండి మాత్రమే.
After: VISIT-2105 కోసం ఇప్పుడు నేను కోరుకుంటున్న కొత్త తేదీ ఏది? చెప్పండి మాత్రమే; బుకింగ్ మార్చవద్దు.
Expected: no currently selected replacement; null with clarification. A historical withdrawn date is not the currently wanted replacement.

## fresh-06-en
Before: Which date did I most recently request for VISIT-2106? Read only.
After: Which replacement date do I currently want for VISIT-2106? Read only; do not change the booking.
Expected: no currently selected replacement; null with clarification. A historical withdrawn date is not the currently wanted replacement.

## fresh-06-hi
Before: VISIT-2106 के लिए मैंने सबसे हाल में कौन सी तारीख मांगी? केवल बताएं।
After: VISIT-2106 के लिए अभी मुझे कौन सी नई तारीख चाहिए? केवल बताएं; बुकिंग न बदलें।
Expected: no currently selected replacement; null with clarification. A historical withdrawn date is not the currently wanted replacement.

## fresh-06-te
Before: VISIT-2106 కోసం నేను చివరిగా కోరిన తేదీ ఏమిటి? చెప్పండి మాత్రమే.
After: VISIT-2106 కోసం ఇప్పుడు నేను కోరుకుంటున్న కొత్త తేదీ ఏది? చెప్పండి మాత్రమే; బుకింగ్ మార్చవద్దు.
Expected: no currently selected replacement; null with clarification. A historical withdrawn date is not the currently wanted replacement.

## fresh-07-en
Before: Which date did I most recently request for VISIT-2107? Read only.
After: Which replacement date do I currently want for VISIT-2107? Read only; do not change the booking.
Expected: no currently selected replacement; null with clarification. A historical withdrawn date is not the currently wanted replacement.

## fresh-07-hi
Before: VISIT-2107 के लिए मैंने सबसे हाल में कौन सी तारीख मांगी? केवल बताएं।
After: VISIT-2107 के लिए अभी मुझे कौन सी नई तारीख चाहिए? केवल बताएं; बुकिंग न बदलें।
Expected: no currently selected replacement; null with clarification. A historical withdrawn date is not the currently wanted replacement.

## fresh-07-te
Before: VISIT-2107 కోసం నేను చివరిగా కోరిన తేదీ ఏమిటి? చెప్పండి మాత్రమే.
After: VISIT-2107 కోసం ఇప్పుడు నేను కోరుకుంటున్న కొత్త తేదీ ఏది? చెప్పండి మాత్రమే; బుకింగ్ మార్చవద్దు.
Expected: no currently selected replacement; null with clarification. A historical withdrawn date is not the currently wanted replacement.

## fresh-08-en
Before: Which date did I most recently request for VISIT-2108? Read only.
After: Which replacement date do I currently want for VISIT-2108? Read only; do not change the booking.
Expected: no currently selected replacement; null with clarification. A historical withdrawn date is not the currently wanted replacement.

## fresh-08-hi
Before: VISIT-2108 के लिए मैंने सबसे हाल में कौन सी तारीख मांगी? केवल बताएं।
After: VISIT-2108 के लिए अभी मुझे कौन सी नई तारीख चाहिए? केवल बताएं; बुकिंग न बदलें।
Expected: no currently selected replacement; null with clarification. A historical withdrawn date is not the currently wanted replacement.

## fresh-08-te
Before: VISIT-2108 కోసం నేను చివరిగా కోరిన తేదీ ఏమిటి? చెప్పండి మాత్రమే.
After: VISIT-2108 కోసం ఇప్పుడు నేను కోరుకుంటున్న కొత్త తేదీ ఏది? చెప్పండి మాత్రమే; బుకింగ్ మార్చవద్దు.
Expected: no currently selected replacement; null with clarification. A historical withdrawn date is not the currently wanted replacement.

