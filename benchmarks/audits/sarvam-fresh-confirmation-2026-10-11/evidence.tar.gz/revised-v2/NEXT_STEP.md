# Next step

This revised120-rendering package is frozen and unexecuted. It corrects the historical/current question distinction in12cases while preserving the full population and all models, prompts, backend rules and gold values. No new result exists. Prior32episodes are development-exposed.

A future launch may use the existing remaining research budget after rechecking source/manifest and notifying the founder. Do not resume v1 or call this a holdout. First complete the predefined confirmation and review every miss. Keep unknown-condition selection, known-condition abstention, raw status mistakes and authorization distinct. If those condition failures persist, the next causal experiment should isolate action-permission language and propagation of assistant claims at a fixed model/evidence budget. That experiment is not yet frozen, approved by this file or implemented. No memory architecture follows automatically.

Run only from the verified source and only once:

```sh
python -m benchmarks.sarvam_fresh_confirmation.study check ROOT
python -m benchmarks.sarvam_fresh_confirmation.study run ROOT
python -m benchmarks.sarvam_fresh_confirmation.audit ROOT --output ROOT/verification.json
```

The check and audit need no credential or model call. The run is paid and creates a once-only started marker. A started/failed manifest must never be repeated.
