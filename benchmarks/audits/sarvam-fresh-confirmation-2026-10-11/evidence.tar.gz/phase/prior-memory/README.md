# Sarvam track — start here

This fork owns Sarvam research. The English baseline remains a separate track; do not overwrite its current state or worktree. Start with [CURRENT_STATE.md](CURRENT_STATE.md), the latest [daily record](daily/2026-10-11.md), [DECISIONS.md](DECISIONS.md) and [RUNBOOK.md](RUNBOOK.md). Shared workspace instructions remain at ../../README.md.

The latest completed research is the fixed-model reporting-wording comparison (S-064 / SF-031): base factual answers 59/72 → 72/72, Conversations 70/72 → 71/72 on saved histories. The predefined development screen passes. The candidate is not promoted; fresh end-to-end confirmation is required. Raw execution-status errors, one candidate regression and an earlier missed approved action remain disclosed. No inference is active and no second paid phase ran this turn.

PR58 has merged both independent commits. Publication is merged and verified through PR58; exact PR/main CI and clean-export checks pass. CURRENT_STATE.md and the experiment completion receipts are authoritative for final CI/preservation status.

- [Complete plain-language Sarvam history](experiments/2026-10-11-reporter-wording/SARVAM_HISTORY.md)
- [Current result](experiments/2026-10-11-reporter-wording/REPORT.md)
- [Every miss and changed pair](experiments/2026-10-11-reporter-wording/FAILURE_REVIEW.md)
- [Next proposed phase](experiments/2026-10-11-reporter-wording/NEXT_PHASE.md) — not prepared or executed
- [Findings](FINDINGS.md), [running notes](RUNNING_NOTES.md), [source notes](SOURCE_NOTES.md)
- [October 8 research](research/2026-10-08/RESEARCH_REPORT.md) and [public benchmark blueprint](research/2026-10-08/PUBLIC_BENCHMARK_BLUEPRINT.md) — dated research/proposals, not completed capabilities

Direction: investigate native Sarvam with strong ordinary storage and tool controls before selecting new memory architecture. Intended eventual scope is all languages supported by the relevant Sarvam services; current Hindi/Telugu and English tests do not establish all-language reliability. A public reproducible benchmark is required. Existing development artifacts are public, but independent data/review and novel product claims remain unfinished.

Standing authority is the existing total INR 6,000 native-research ceiling, not a fresh allowance each turn. Current native carry: 6,080 calls, INR 169.754685 known estimate / INR 244.451544 retained. Older pilot accounting is separate. Credits are not permission for unrelated work; never read a credential to perform an offline replay. Do not repeat a completed manifest or hide failed requests with retries. See the run-specific protocol and completion receipt before any execution.

Use `/Volumes/Sahith_SSD/AgentMem-OS/.worktrees/sarvam-foundation`, branch `codex/sarvam-foundation`, isolated test stores, individual commits and reference PRs. Worktrees share refs; preserve founder files and English work. No new model gain follows merely from green software tests. Expected answers must never enter generation, retrieval or action execution.

The former stacked “latest/active/unstarted” notices are preserved in [the README snapshot](history/2026-10-11-before-reporter-readme-cleanup/README.md). They describe superseded states. Historical evidence, original failures and decisions remain in their dated experiment directories; do not treat a proposal, archived authorization state or old capability registry as current.
