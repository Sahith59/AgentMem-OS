# Sarvam current state — October 11, 2026

The one-sentence reporting experiment is complete and its prospective development screen passes. All 288 calls finished with no API errors, retries or unknown usage. Independent parsing/accounting and full source/request/receipt replay agree.

| Fixed model profile | Fresh control factual answers | Candidate factual answers | Paired gains / losses |
|---|---:|---:|---:|
|105B, low reasoning|59/72|72/72|13 / 0|
|Conversations, null reasoning|70/72|71/72|2 / 1|

Only the first reporting sentence changed. Models, evidence, schema and 8,192-token caps are fixed. Base empty answers fall from ten to zero; base completion tokens fall about 42%. This is a positive saved-history reporting result, not a new memory architecture, English benchmark gain, independent benchmark or fresh end-to-end success.

One candidate Conversations answer wrongly abstains despite a known date. Raw status fields remain unreliable: only 58/72 base and 54/72 Conversations candidate statuses are correct. The existing receipt-owned application layer must remain. It changes no dates. An earlier base/Hindi approved action remains unperformed; no new actions were executed. All 72 source renderings, 16 misses and 55 raw-changed pairs are assistant reviewed; independent native review is absent.

Next: prepare and freeze fresh end-to-end confirmation with the unchanged candidate, new reviewed renderings and shared fresh native actions before paired final reports. The proposed 120-rendering design and acceptance conditions are in NEXT_PHASE.md; it is not yet built or executed. No second paid phase ran this turn and no inference is active. No candidate is promoted.

New known estimate INR 38.453490; retained INR 48.066950. Native cumulative: 6,080 calls, INR 169.754685 known / INR 244.451544 retained under the existing total INR 6,000. Across the separately authorized older pilots too: 6,327 calls and INR 174.155175 known estimates; older unknown usage remains unpriced. Token estimates are not invoices or account balances.

PR58 is merged at `a885b2686ad345712adbcb145c4cf01c590634ef`. Both independent commits are preserved. Clean export verifies 1,243 artifact files, exactly reproduces both analyses and passes 154 tests. Exact-head PR/main CI pass. Both worktrees match origin/main; all 6,992 founder files/status and English current state are unchanged. Publication is complete.

Read [current report](experiments/2026-10-11-reporter-wording/REPORT.md), [complete Sarvam history](experiments/2026-10-11-reporter-wording/SARVAM_HISTORY.md), [failure review](experiments/2026-10-11-reporter-wording/FAILURE_REVIEW.md), and [next proposal](experiments/2026-10-11-reporter-wording/NEXT_PHASE.md). Decisions S-063/S-064 and finding SF-031 preserve the reasoning. Older states and failed gates remain in the historical records.
