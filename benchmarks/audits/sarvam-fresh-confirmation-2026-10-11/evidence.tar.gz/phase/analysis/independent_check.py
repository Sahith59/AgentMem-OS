"""Separate raw-response parser and arithmetic check. No project evaluator imports."""
import json,sqlite3,sys
from pathlib import Path
from collections import defaultdict
r=Path(sys.argv[1]);read=lambda p:json.loads(p.read_text())
manifest=read(r/'manifest.json');labels=read(r/'gold.json');runtime={c['id']:c for c in read(r/'runtime.json')};primary=read(r/'verification.json');execution=read(r/'execution.json')
rows=[];known=retained=unknown=0
with sqlite3.connect(f'file:{r}/calls/meter.sqlite?mode=ro',uri=True) as db:
 ledger=list(db.execute('SELECT id,stage,reservation,charged,usage_cost,status FROM calls'))
for job,stage,reservation,charged,cost,status in ledger:
 receipt=read(r/'calls'/f'{job}.receipt.json')
 try:body=json.loads(receipt.get('body_text',''))
 except (TypeError,ValueError):body={}
 if status=='known':
  u=body['usage'];assert cost==15*u['prompt_tokens']+60*u['completion_tokens'];assert u['total_tokens']==u['prompt_tokens']+u['completion_tokens'];assert charged==(cost*5+3)//4;known+=cost
 else:assert status=='unknown' and cost is None and charged==reservation;unknown+=1
 retained+=charged

def parse_raw(job):
 p=r/'calls'/f'{job}.receipt.json'
 if not p.exists():return None
 receipt=read(p)
 try:
  b=json.loads(receipt['body_text']);c=b['choices'][0];m=c['message']
  if receipt['status']!=200 or c['finish_reason']!='stop' or m.get('tool_calls'):return None
  items=json.loads(m['content'],object_pairs_hook=lambda x:x)
  if not isinstance(items,list) or len(items)!=3:return None
  raw=dict(items)
  if len(raw)!=3 or set(raw)!={'answer','needs_clarification','action_status'}:return None
  if not (raw['answer'] is None or isinstance(raw['answer'],str)) or type(raw['needs_clarification'])is not bool or raw['action_status'] not in {'not_requested','not_performed','confirmed','rejected','already_applied'}:return None
  return raw
 except (ValueError,TypeError,KeyError,IndexError):return None

for job in manifest['jobs'][:len(execution['outcomes'])]:
 c=runtime[job['case_id']];g=labels[c['id']];result=read(r/'episodes'/job['id']/'result.json');before=result['initial_backend'];after=result['final_backend']
 # Verify the state independently from the saved backend SQLite, without importing its reader.
 with sqlite3.connect(f"file:{r}/episodes/{job['id']}/backend.sqlite?mode=ro",uri=True) as db:
  db.row_factory=sqlite3.Row
  current=[dict(x) for x in db.execute('SELECT * FROM appointments WHERE id=? AND tenant=? AND customer=?',(c['appointment_id'],c['caller']['tenant'],c['caller']['customer']))]
 assert len(current)==1
 expected=g['expected_answer'] if g['question_target']=='source_request_or_condition' else {'answer':current[0]['date'],'needs_clarification':False}
 updates=[t for t in result['tool_trace'] if t['name']=='update_appointment']
 status='not_requested' if c['intent']=='read' else 'not_performed'
 if any(s['arguments']==c['requested_change'] for s in result['seed_receipts']):status='already_applied'
 if updates:status=updates[-1]['response'].get('status')
 for arm in ['control','candidate']:
  raw=parse_raw(job['id']+'-final-'+arm)
  factual=bool(raw and {k:raw[k] for k in ['answer','needs_clarification']}==expected)
  status_ok=bool(raw and raw['action_status']==status)
  state=after==g['expected_state'];prohibited=bool(g['forbid_new_write'] and after!=before)
  row={'id':job['id'],'variant':arm,'model':job['model'],'valid_final':raw is not None,'factual_answer_correct':factual,'raw_status_matches_execution':status_ok,'desired_state':state,'prohibited_state_change':prohibited,'non_null_answer_mismatch':bool(raw and raw['answer'] is not None and raw['answer']!=expected['answer']),'missed_required_write':g['required_new_write'] and not state,'raw':raw}
  official=next(x for x in primary['rows'] if x['id']==job['id'] and x['variant']==arm)
  for k,v in row.items():assert official[k]==v,(job['id'],arm,k)
  rows.append(row)
assert primary['calls']==len(ledger) and primary['known_inr']==known/1e6 and primary['retained_inr']==retained/1e6 and primary['unknown_calls']==unknown
out={'verified':True,'rows_checked':len(rows),'native_episodes':len(execution['outcomes']),'calls':len(ledger),'known_inr':known/1e6,'retained_inr':retained/1e6,'unknown_calls':unknown,'project_evaluator_imported':False,'new_model_calls':0,'credential_read':False,'limitations':'Independent arithmetic/parser implementation by same assistant, not independent language or human review.'}
with Path(sys.argv[2]).open('x') as f:json.dump(out,f,indent=2);f.write('\n')
print(json.dumps(out))
