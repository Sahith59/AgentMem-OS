# Sarvam current state — October 11, 2026

**The frozen 288-episode source comparison is complete and fully replayed. Publication is merged and verified through PR57. No inference is active.** English remains untouched and owned by the original chat.

Conversations safe tasks:67/72 approval-off,69/72 approval-on; strict67/72 both. Base105B safe/strict66/72 off,57/72 on. These are correlated synthetic cases, not general multilingual accuracy or an English score change. Action-only desired states:base27/27off,26/27on;Conversations23/27off,27/27on. Four unauthorized Conversations writes occur off; zero guarded unsafe writes. Guard blocks three live attempts. All23attempted legitimate new writes succeed; one baseHindi approved action is omitted.

Main diagnosis:18empty final outputs, allbase (16at8192-token cap,2stop/nullbelowcap). Fifteen already have correct native prose; three already have approved write receipts. Six valid answer/clarification mismatches include a question echo, one wrong-date substitution, missing clarification, unnecessary abstention and omission. Receipt projection corrects59statusfields with no date/clarification changes. Complete desired reports201raw→259app; this is ordinary contract engineering, not model reasoning or memory gain. Every89flaggedepisode/51renderedcase is assistant-reviewed; independent native review remains absent.

723newcalls,estimatedINR65.255115/retained81.569158;native cumulative5792calls,known131.301195/retained196.384594 within totalINR6000. Zero new API/backend errors, unknown usage or retries. Approximately40minutes API execution.143tests,Ruff/diff,frozen-source checks,allcall/state/meter replay,attribution,independentaggregation and offlinebackendflip pass. Separatepairedtrajectories are variable:10base and3Conversations read-only pairs differ in factual correctness despite identical initial inputs. Do not credit that to approval enforcement.

[Report](experiments/2026-10-11-source-comparison-results/REPORT.md), [review](experiments/2026-10-11-source-comparison-results/FAILURE_REVIEW.md), [next phase](experiments/2026-10-11-source-comparison-results/NEXT_PHASE.md). Historical setup gate remains valid; comparison gate_pass=false is a setup-only field, not a new failed comparison gate. Original grades stay frozen.

Next: isolate one finalizer instruction change using every saved guarded history with fixed models and matched caps. This is a proposal, not an executed gain. No new multilingual memory implementation until ordinary integration and a real remaining memory need are demonstrated. No outreach. Nothing additional is required from the founder for this authorized research scope.


## Publication verified — PR57

Five independent commits cf034a8, 1d5a5ae, 57483c7, ed287d3 and 2e1915c are merged at `1829cab4c1c19698e3b9649da56abe80e52c8568`. Exact-head PR CI 38188399170 and exact-merge main CI 38188675356 passed. A clean committed export passed all 143 focused tests, verified all 3,083 archived files and exactly reproduced primary, attribution, summary and backend replay. Both local worktrees equal origin/main and the tested tree. All 6,992 founder files/status and the root English CURRENT_STATE are preserved. See completion.json, clean-export-verification.json, preservation-after-merge.json and post-merge-ci.json. No additional paid probe ran and no inference is active.

This completion supersedes publication-pending notes only. The research remains a mixed result: four unsafe writes without enforcement, 18 empty base-model final outputs, six valid answer mismatches and one missed useful action. Ordinary controls help; no new memory need, general-language score or novelty has been established. Native cumulative 5,792 calls, known estimate INR131.301195, retained INR196.384594 within the existing INR6,000 authority.
