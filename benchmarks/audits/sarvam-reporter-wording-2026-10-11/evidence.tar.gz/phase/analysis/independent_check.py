"""Offline raw-receipt aggregation independent of the runner/classifier.

Usage: python independent_check.py ROOT NEW_OUTPUT
No credentials, networking, result edits or score/answer correction.
"""
import collections
import hashlib
import json
from pathlib import Path
import socket
import sqlite3
import statistics
import sys


def read(path):
    return json.loads(path.read_text())


def denied(*args, **kwargs):
    raise RuntimeError('Offline analysis')


socket.socket = denied
socket.create_connection = denied
root, destination = map(Path, sys.argv[1:])
audit = read(root / 'verification.json')
inputs = {h['id']: h for h in read(root / 'inputs.json')}
expected = read(root / 'expected.json')
jobs = read(root / 'manifest.json')['jobs']
assert len(audit['rows']) == len(jobs) == 288
assert len(inputs) == len(expected) == 144
rows = []
known = retained = 0
with sqlite3.connect(f'file:{root}/calls/meter.sqlite?mode=ro', uri=True) as db:
    ledger = {r[0]: r[1:] for r in db.execute('SELECT * FROM calls')}
response_ids = set()
for job in jobs:
    receipt = read(root / 'calls' / (job['id'] + '.receipt.json'))
    assert receipt['status'] == 200
    body = json.loads(receipt['body_text'])
    assert body['id'] not in response_ids
    response_ids.add(body['id'])
    choice = body['choices'][0]
    message = choice['message']
    parsed = None
    if choice['finish_reason'] == 'stop' and not message.get('tool_calls'):
        try:
            value = json.loads(message['content'])
            assert isinstance(value, dict)
            assert set(value) == {'answer', 'needs_clarification', 'action_status'}
            assert value['answer'] is None or isinstance(value['answer'], str)
            assert type(value['needs_clarification']) is bool
            assert value['action_status'] in {'not_requested','not_performed','confirmed','rejected','already_applied'}
            parsed = value
        except (TypeError, ValueError, AssertionError):
            pass
    target = expected[job['history_id']]
    facts = {k: parsed[k] for k in ('answer','needs_clarification')} if parsed else None
    good = facts == target['answer']
    official = next(r for r in audit['rows'] if r['id'] == job['id'])
    assert parsed == official['parsed']
    assert good == official['factual_answer_correct']
    usage = body['usage']
    charge = usage['prompt_tokens'] * 15 + usage['completion_tokens'] * 60
    headroom = (charge * 5 + 3) // 4
    stage, reservation, ledger_retained, ledger_cost, status = ledger[job['id']]
    assert status == 'known' and charge == ledger_cost and headroom == ledger_retained
    known += charge
    retained += headroom
    rows.append({
        'id':job['id'], 'history_id':job['history_id'], 'variant':job['variant'],
        'model':body['model'], 'case_id':inputs[job['history_id']]['case_id'],
        'language':target['case']['language'], 'family':target['case']['family'],
        'factual_correct':good, 'valid_final':parsed is not None, 'parsed':parsed,
        'empty_content':message.get('content') in (None,''),
        'finish_reason':choice['finish_reason'], 'tokens':usage,
        'latency_seconds':receipt['elapsed_seconds'], 'known_microinr':charge,
        'system_fingerprint':body.get('system_fingerprint'),
        'source_sha256':hashlib.sha256(json.dumps(target['case'],ensure_ascii=False,sort_keys=True).encode()).hexdigest(),
    })
assert known / 1e6 == audit['known_inr'] and retained / 1e6 == audit['retained_inr']
assert read(root/'execution.json')['meter']['wording'] == {
    'calls':288, 'charged_with_headroom_inr':retained/1e6,
    'known_usage_estimate_inr':known/1e6, 'unknown_or_pending':0,
}
groups=[]
models=sorted({r['model'] for r in rows})
for model in models:
    for variant in ('control','candidate'):
        subset=[r for r in rows if (r['model'],r['variant'])==(model,variant)]
        groups.append({
            'model':model,'variant':variant,'calls':len(subset),
            'correct':sum(r['factual_correct'] for r in subset),
            'valid':sum(r['valid_final'] for r in subset),
            'empty':sum(r['empty_content'] for r in subset),
            'cap_exhausted':sum(r['tokens']['completion_tokens']==8192 for r in subset),
            'stop_empty':sum(r['empty_content'] and r['finish_reason']=='stop' for r in subset),
            'valid_but_wrong':sum(r['valid_final'] and not r['factual_correct'] for r in subset),
            'prompt_tokens':sum(r['tokens']['prompt_tokens'] for r in subset),
            'completion_tokens':sum(r['tokens']['completion_tokens'] for r in subset),
            'known_inr':sum(r['known_microinr'] for r in subset)/1e6,
            'median_latency_seconds':statistics.median(r['latency_seconds'] for r in subset),
            'max_latency_seconds':max(r['latency_seconds'] for r in subset),
            'observed_system_fingerprints':sorted({r['system_fingerprint'] for r in subset if r['system_fingerprint']}),
        })
pairs=[]
for hid in inputs:
    pair={r['variant']:r for r in rows if r['history_id']==hid}
    a,b=pair['control'],pair['candidate']
    pairs.append({
        'history_id':hid,'model':a['model'],
        'control_id':a['id'],'candidate_id':b['id'],
        'control_correct':a['factual_correct'],'candidate_correct':b['factual_correct'],
        'parsed_changed':a['parsed']!=b['parsed'],
        'factual_fields_changed':(
            {k:a['parsed'][k] for k in ('answer','needs_clarification')} if a['parsed'] else None
        ) != ({k:b['parsed'][k] for k in ('answer','needs_clarification')} if b['parsed'] else None),
        'contains_miss':not(a['factual_correct'] and b['factual_correct']),
    })
paired=[]
for model in models:
    subset=[p for p in pairs if p['model']==model]
    paired.append({
        'model':model,'histories':len(subset),
        'gains':sum(not p['control_correct'] and p['candidate_correct'] for p in subset),
        'losses':sum(p['control_correct'] and not p['candidate_correct'] for p in subset),
        'both_correct':sum(p['control_correct'] and p['candidate_correct'] for p in subset),
        'both_wrong':sum(not p['control_correct'] and not p['candidate_correct'] for p in subset),
    })
# This is descriptive, not an inferential test: translations share scenario ancestry.
result={
    'verified':True,'independent_parser_and_raw_accounting_match':True,'new_calls':0,
    'calls':len(rows),'response_ids_unique':True,'execution_meter_matches':True,
    'groups':groups,'paired':paired,'pairs':pairs,'rows':rows,
    'known_inr':known/1e6,'retained_inr':retained/1e6,
    'noncorrect_outputs':sum(not r['factual_correct'] for r in rows),
    'changed_parsed_pairs':sum(p['parsed_changed'] for p in pairs),
    'changed_factual_pairs':sum(p['factual_fields_changed'] for p in pairs),
    'semantic_review_history_ids':[p['history_id'] for p in pairs if p['contains_miss'] or p['parsed_changed']],
    'notes':'Independent raw parsing/accounting; semantic review is separate. No independent-sample or significance claim.',
}
with destination.open('x') as f:
    json.dump(result,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('rows','pairs','semantic_review_history_ids')}))
