# Sarvam opportunity review — October 8, 2026

**Decision status: research complete for this discovery pass; product choice remains open.** This report replaces the October 7 brief's immediate implementation recommendation. The founder requires all Sarvam-supported languages in the intended scope and a public, reproducible benchmark as a core deliverable. Hindi and Telugu can be early reviewed slices, not the product boundary.

## What changed our assessment

The evidence does not support selling “memory for Sarvam” as a new capability. Sarvam already has customer-context and business-system integration surfaces. Established memory systems already implement persistent facts, temporal updates, source links and deletion operations. Multilingual memory evaluation also has prior art. Our opportunity must therefore be established through specific failures under strong controls, rather than inferred from missing documentation or English results.

The best next research question is: **when conversations switch languages and facts change, can a small component keep the correct person's current facts and confirmed actions more reliably than Sarvam with a properly configured persistent database?** We have not demonstrated that advantage. A public benchmark can be useful even if the answer is no, provided its labels, language review, controls and failure reporting are credible.

Three GPT-6 Sol agents researched capabilities, product gaps and benchmark/competitor work. The lead agent cross-checked critical official pages, broader Indian-platform positioning and current repository claims. These are separate agent reviews, not independent human validation. This was targeted public-source research, not a complete search of the internet or private Sarvam materials. Exa/Firecrawl tools were unavailable; public web search/open and primary papers/repositories were used instead. No providers were called for inference, no account credentials were inspected, and no outreach was sent.

## What Sarvam currently provides

| Surface | Documented capability | Consequence for our work |
| --- | --- | --- |
| Sarvam-105B chat | Main model has 128K context; conversation variant has 32K. The model page lists ten Indian languages plus English, including native, Romanized and mixed-language input. | “105B can already answer this” is a mandatory control, not an objection we can dismiss. [Model page](https://docs.sarvam.ai/api/getting-started/models/sarvam-105b). |
| Speech recognition | Saaras v4 is the current recommended model; its language set includes 22 Indian languages plus English. Output modes separate transcription, English translation and script/mixing choices. | Preserve native source text; treat ASR and translation errors separately from memory errors. [Saaras](https://docs.sarvam.ai/api/getting-started/models/saaras). |
| Translation and documents | Sarvam Translate and Vision document the 23-language set; Mayura has a narrower language set and different controls. | A translated path is a distinct configuration, not evidence of direct 105B support. [Translate](https://docs.sarvam.ai/api/getting-started/models/sarvam-translate), [Vision](https://docs.sarvam.ai/api/getting-started/models/sarvam-vision), [Mayura](https://docs.sarvam.ai/api/getting-started/models/mayura). |
| Speech output | General Bulbul v3 documentation lists 11 languages; voice cloning/dubbing list a different 12-language set. | Do not promise identical voice coverage across the text-language scope. [Bulbul](https://docs.sarvam.ai/api/getting-started/models/bulbul), [cloning languages](https://docs.sarvam.ai/api/api-guides-tutorials/voice-cloning/supported-languages). |
| Voice Agents | Start hooks can load CRM state; tools read/write call variables; end hooks export extracted results. | Persistent customer context can already be built through native integration. Test that configuration fairly. [Variables and personalization](https://docs.sarvam.ai/conversations/build/variables-personalization). |
| Cowork and platform | Cowork provides agents, connectors and knowledge features; Voice Agents includes workflows, knowledge bases, tests and analytics. | A generic personal/business assistant is crowded positioning. [Cowork](https://docs.sarvam.ai/cowork/overview), [Voice Agents](https://docs.sarvam.ai/conversations/overview). |

The language inventory must be **endpoint-specific and versioned**. The current explicit Indian-language core comprises Assamese, Bengali, Bodo, Dogri, English, Gujarati, Hindi, Kannada, Kashmiri, Konkani, Maithili, Malayalam, Manipuri, Marathi, Nepali, Odia, Punjabi, Sanskrit, Santali, Sindhi, Tamil, Telugu and Urdu. This is the listed 23-language core, not a claim that all Sarvam-hosted third-party models stop at 23 languages. The catalog also offers beta third-party models with separate coverage and access conditions. [Model catalog](https://docs.sarvam.ai/api/getting-started/models).

The [capability memo](capabilities/MEMO.md) records endpoint limits, code discrepancies and announcement-versus-API distinctions. For example, some endpoints use `od-IN` and others `or-IN`; a universal code substitution is unsafe. A model announcement, a tokenizer's language list, a custom customer deployment and a generally callable API are different evidence. All proposed language routes remain untested in this track.

## Existing context is real; its difficult cases are unmeasured

Sarvam's Voice Agents product advertises customer context and private memory. Its Circle ecosystem describes MoEngage supplying longer-term customer context. Those statements directly contradict an assumption that every Sarvam call begins without usable prior knowledge. They do not disclose the full identity, correction or forgetting implementation. [Voice Agents product](https://www.sarvam.ai/products/voice-agents), [Sarvam Circle](https://www.sarvam.ai/blogs/introducing-sarvam-circle).

Sarvam's Epoch material also discusses evaluation of code mixing, ambiguous messages, noisy speech and complicated workflows, alongside model and platform expansion. We would be duplicating its stated priorities if we claimed simply to have discovered those difficulties. Publicly reproducible evidence and a useful fix would be the contribution. Announced capability and vendor evaluation results remain publisher claims. [Epoch summary](https://www.sarvam.ai/epoch/summary).

The strongest public failure lead found is New Measure's multilingual ecommerce evaluation. It reports failures involving tool use and actual backend state, including an instruction being overwritten during later conversation. However, it does not isolate persistent memory as the cause, and this review found no linked public harness/data or pinned model revision. Its score cannot stand in for current Sarvam quality or our expected gain. It supplies hypotheses for controlled tests. [Original evaluation](https://www.newmeasure.ai/research/multi-turn-customer-support-eval-india).

An SDK issue requesting portable memory is one developer's proposal, with their own project attached. It is neither Sarvam admitting a defect nor validated buyer demand. [Issue 14](https://github.com/sarvamai/sarvam-ai-sdk/issues/14). Missing public specifications for cross-call correction or forgetting should be recorded as **unknown**, then tested or clarified, not advertised as absent.

## Market and prior art that constrain our claims

| Evidence | What it rules out | What remains worth testing |
| --- | --- | --- |
| Haptik describes shared customer state across voice and messaging; Yellow.ai describes persistent context across channels and business tools. | Cross-channel customer memory alone is not distinctive. These are vendor descriptions, not a comparative reliability audit. [Haptik](https://www.haptik.ai/blog/omnichannel-voice-ai), [Yellow.ai](https://yellow.ai/blog/why-context-is-a-deciding-factor-for-enterprise-ai-agents/). | Which systems preserve the right identity and current state after realistic multilingual corrections? |
| Gnani describes context-aware language switching. | Language switching alone is not a new product category. [Gnani](https://www.gnani.ai/resources/blogs/voice-ai-language-support-with-gnani-s-context-aware-switching). | What is retained across separate sessions and language changes, at what cost? |
| Zep/Graphiti, Mem0, Letta and Supermemory document overlapping memory mechanisms. | Provenance, temporal facts, editable memory, scoped retrieval and forgetting cannot be claimed as inventions individually. [Zep](https://arxiv.org/abs/2501.13956), [Mem0](https://arxiv.org/abs/2504.19413), [Letta](https://docs.letta.com/v1-sdk/memory/memory-blocks), [Supermemory](https://supermemory.ai/docs/concepts/graph-memory). | Does a particular implementation improve a defined failure class over maintained baselines? |
| MAMMR releases Turkish–English memory retrieval evaluation, with limitations disclosed. LongMemEval and its successor already test temporal or changing state. | “First multilingual memory benchmark” and “nobody tests changing state” are untenable. [MAMMR](https://github.com/dorukardahan/mammr-benchmark), [LongMemEval](https://arxiv.org/abs/2410.10813), [LongMemEval-V2](https://arxiv.org/abs/2605.12493). | A reviewed Indian-language benchmark joining persistent state, source evidence and action verification may fill a useful evaluation need; priority is not established. |

Sarvam's Dezerv customer story indicates practical value in searchable, traceable multilingual conversation records, but is a publisher/customer account and already describes an implemented solution. It supports relevance, not demand for AgentMem specifically. [Dezerv story](https://www.sarvam.ai/stories/dezerv).

The detailed [competitor memo](benchmarks-competition/MEMO.md) and [source ledger](benchmarks-competition/SOURCE_CLAIM_LEDGER.md) cover methodological limits, transliteration/code-mix resources and framework comparisons. We did not install or benchmark these competitors. No market-size estimate, willingness-to-pay conclusion or superiority claim follows from this review.

## Concrete problem candidates, not selected products

**Return-call service continuity.** A verified customer changes a delivery request in Hindi and later asks in Telugu whether it happened. The earlier requested date, latest desired date, backend-accepted date and failed attempt must remain distinct. A delayed event must not overwrite a newer accepted state; a retry must not create a second action. Success is the correct persisted state and truthful answer, checked separately. A CRM plus well-designed tool can solve this; that is the baseline to beat.

**Personal commitments with corrections and conditions.** A person gives a date-dependent preference, corrects it in another script, then withdraws it. The assistant must respect the effective date, distinguish suggestion from commitment, preserve the correction source and avoid restoring withdrawn information during re-indexing. A shared phone or similar name cannot establish identity. This is a second scenario family using the same tests, not a commitment to build a second app.

**Cross-product handoff.** A Cowork interaction followed by a Voice Agents interaction could test state transfer, but access and native interoperability are unverified. Defer implementation until the first two cases reveal a need; mark unavailable controls explicitly.

See [OPPORTUNITY_AND_VALIDATION.md](OPPORTUNITY_AND_VALIDATION.md) for state contracts and tests. None is a confirmed Sarvam defect. They are chosen because errors can be observed and attributed, not because a demo sounds attractive.

## Benchmark and product decision

The public benchmark is now a required workstream from the outset. Its first artifact is a public-ready protocol, followed by reviewed data, runnable baselines and complete results. The deliverable is not merely a leaderboard screenshot. This turn produced a [draft benchmark blueprint](PUBLIC_BENCHMARK_BLUEPRINT.md); it has not been published or executed.

Minimum comparisons are fixed-model full history, an ordinary persistent SQL/event-log implementation with retrieval, and a well-configured native Sarvam path where access permits. Established memory frameworks follow with their dependencies and costs disclosed. Context-matched architecture tests and unrestricted full-history tests answer different questions and must be separate. A weak stateless control alone would inflate our value.

The language scope stays visible in every release. The 11 documented 105B chat languages support a direct-reader evaluation plan. The other 12 core languages need a separately labeled supported route and competent review, not extrapolated scores. Hosted-model extensions must have their own registry entries. All-language product claims remain blocked until every promised path is validated. Founder review can help Hindi/Telugu, but is not independent validation for 23 languages.

**Build a new component only if** a reviewed, reproducible failure persists under the strong controls and the proposed mechanism fixes it with matched models and disclosed costs. If conventional state storage solves the problem, ship the smaller integration and publish that result. If errors are due to translation, speech recognition or tool execution, fix that layer instead of calling everything memory. If the candidate offers no material gain, preserve the negative finding and change direction.

## Local findings and immediate sequence

Our own earlier source audit found Latin-only token matching in `forget_about`; this remains an unfixed static finding, not an end-to-end deletion result. Historical alias-judge results use draft labels and do not establish multilingual memory answer accuracy. The English 84.6% development result provides no Sarvam score.

Current repository copy also needs qualification: README line 17 says “the benchmark nobody has built,” and `docs/INDIC_ROADMAP.md` lines 14–15 generalize about all production memory systems. Checked at commit `9572a28a6a64751a326319313cdc71d06c7deb3b`. This research turn logs the correction backlog without editing product files. Other broad “first” claims require their own review before reuse.

Next, freeze a small discriminating scenario pack and scoring rules; review the language renderings and measure review effort; specify exact native/database/framework configurations; then prepare a separately bounded live capability comparison. Model runs and customer discovery have not happened. Select product requirements from those observations. Broader publication/release and all-language review need real work; this report does not promise a completion date or a research-paper acceptance.

Supporting evidence: [capabilities](capabilities/MEMO.md), [native product and gaps](product-gaps/MEMO.md), [benchmarks and competitors](benchmarks-competition/MEMO.md), [coverage registry](language-coverage.json), [source index](source-index.json), [verification](verification.json).
