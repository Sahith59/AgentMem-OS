# Sarvam foundation brief

Prepared October 7, 2026 (America/New_York). This is a proposed delivery plan informed by current sources and a scoped code review. It is not an executed integration, a promised score or a confirmed Sarvam requirement.

## 1. The outcome we want

AgentMem OS should let a Sarvam-powered assistant keep correct user information across sessions, language changes and corrections. Hindi and Telugu are the founder-selected starting languages, with English as a matched comparison. The founder wants both a personal assistant and a small-business assistant. We will build one memory engine and demonstrate it in these two settings.

Personal example: a user supplies an appointment in Telugu, corrects the date in Hindi, then asks in English after a restart. The assistant should return the current date, identify the supporting messages, and distinguish it from the previous date when asked about history. This is an illustrative target, not a completed result.

Business example: a customer states a contact preference and callback time; later they change the time. The assistant should retain the right customer's latest instructions without mixing another customer's record into the answer. It should report a requested callback, not invent proof that a call happened. We are initially recording and recalling plans, not placing calls or booking appointments.

Success means useful behavior a developer can reproduce, including failure behavior. Acceptance into the Startup Program is user-provided evidence of access and support; it does not guarantee a partnership, endorsement or need for our chosen feature.

## 2. What the old plan actually proposed

The August plan emphasized cross-script entity matching, a Sarvam extraction/identity adapter, and eventually an Indic memory benchmark. It grew into a large multi-language, multi-framework research program. September's reviewed plan narrowed that to native ingestion, persistence, updates, forgetting and user isolation with matched English examples. The October 7 parallel plan reduced the first step further: five development histories and one working text-memory path.

Keep that narrow sequence, now with both Hindi and Telugu and the two requested use cases. Do not restart the old 200-family, six-framework program before the first end-to-end path works. Historical calendars and paper deadlines are not current commitments. GPT-4o stays retired. The English chat's 90% research target remains separate.

Some old assertions must stay retired: “first cross-lingual memory benchmark,” “Sarvam has no memory,” “embeddings prove identity,” and “a stronger judge solves the architecture.” Existing memory systems and multilingual retrieval studies overlap with these ideas. A new contribution needs a narrower mechanism and controlled evidence.

## 3. What exists, and what is missing

We have conversation storage, facts and graph components, multilingual retrieval/alias code, evaluation adapters, extensive English failure records, five new unexecuted control histories, and an old Sarvam-105B identity experiment. The saved identity result recomputes to 109 true merges, 17 false merges and 16 misses over 344 pairs (86.51% precision, 87.20% recall). Labels are still drafts. This falls below the old 95% automatic-merge target and cannot certify safe identity resolution. The old cosine and model-judge tables used different pair universes, so their F1 values are not a clean common-test comparison.

There is a Sarvam API path in the historical identity benchmark. That is not a verified reusable ingestion-to-answer integration. The general adapter uses LiteLLM; the benchmark adapter can fall back to TF-IDF and catches ingestion errors. The first Sarvam path must expose its actual backend and failures instead of treating a returned string as success.

A concrete blocker is the current forget matcher: `[a-z]{4,}` cannot recognize Hindi/Telugu-only words. The public endpoint describes soft deletion of matching user turns. We must test all derived stores before asserting that forgotten material cannot be recalled. This was a static code inspection plus a pure regex probe, not a live database test.

The original data, native source support, cross-session user scope, correction semantics, reliable deletion and real API usage accounting still need end-to-end proof.

## 4. The proposed system, in plain language

1. Preserve what the person actually said: original text, speaker, user/customer boundary, language, message ID and observation time. Translation and transliteration, if introduced, remain derived helpers linked to that source.
2. Ask the chosen Sarvam model to propose facts and changes. Validate names, numbers, dates, evidence pointers and schema before accepting them. An assistant suggestion is not automatically a user preference. Model confidence is not proof.
3. Store a dated history of accepted changes and an explicit current state. Keep the time a message was received separate from the time an event is meant to occur. “Tomorrow” needs a known date/timezone; otherwise clarify or abstain.
4. Retrieve only permitted evidence for the relevant person and question. Similar spellings can suggest an identity link; they cannot by themselves authorize merging two people. Preserve ambiguity when needed.
5. Give Sarvam a bounded evidence packet and ask for an answer grounded in it. Keep the original evidence trace so an incorrect result can be traced to extraction, state update, retrieval or answering.
6. Apply forgetting across every serving representation and prevent later re-extraction from resurrecting the item. Separate correction history from explicit forgetting. A deletion marker can retain necessary control metadata without retaining the forgotten content. Application behavior is distinct from provider logs/backups and their retention settings.

This is a design target. Reuse verified components; change only the parts shown to fail the first fixtures. Do not build a new graph platform or assume the English benchmark improvements are already production features. Local multilingual embeddings can remain a separately disclosed dependency; no all-Sarvam-stack claim until every component is accounted for.

## 5. Why this could matter to Sarvam

Sarvam documents chat models and a Voice Agents platform for multilingual customer conversations. Our proposed contribution is a tested, reusable memory integration for those kinds of applications: fewer repeated questions, fewer stale instructions, and better separation between customers. That benefit is a hypothesis to measure, not an assertion about Sarvam's current product limitations. [Sarvam Voice Agents overview](https://docs.sarvam.ai/conversations/overview).

Useful deliverables are a runnable example, a reviewed Hindi/Telugu test set with English comparisons, cost/latency results, and precise failure reproductions. A report that identifies whether a number changed during translation, a correction failed in our storage code, or the model ignored delivered evidence gives engineers something actionable. Calling our own pipeline bug a Sarvam model bug would make that report less useful.

## 6. Where a research contribution could emerge

Hypothesis: preserving original-language evidence, scoped identity and dated corrections reduces incorrect answers when the same history changes language or script, at a controlled model and context budget. The narrower question is whether our implementation improves this reliably over simpler alternatives.

Candidate mechanisms to test only if the failures justify them: (a) preserving evidence through language transformations; (b) reversible, context-supported identity links instead of destructive similarity merging; (c) resolving changes with explicit dates and source references. None is claimed novel on its own. Temporal memory, provenance and retrieval are well-established areas; [Zep](https://arxiv.org/abs/2501.13956) and [Mem0](https://arxiv.org/abs/2504.19413) overlap with the broad design. The [MAMMR author's announcement](https://www.linkedin.com/posts/dorukardahan_i-built-mammr-a-production-informed-benchmark-activity-7458199495189811200-uYJf) already describes Turkish–English agent-memory retrieval.

A potential paper needs a reviewed dataset, a specific new mechanism, fair simple baselines, experiments removing each claimed component, and reproducible benefits on families not used for tuning. A working integration is useful even if it does not yield a novel paper. This scoped review does not establish the absence of competing Indic work.

## 7. Evaluation that can tell us whether we helped

Begin with seven excluded development histories: the existing five plus two small-business drafts. Review English, Hindi and Telugu renderings for preserved meaning. This makes at least 21 renderings, not 21 independent histories. Add Romanized and code-mixed variants after the initial path and review process work; these are central later test slices, not a reason to delay the first proof.

Then target 8–12 new reviewed scenario families for a small diagnostic pilot. Expand toward 20–40 families over the 20–30-day effort only if measured review time and cost permit. All variants of one family stay in the same split. The seven starter fixtures never enter the scored set. Draft and review the family splits and stop rules before comparisons; keep expected states separate from runtime inputs. Founder review is creator review, not independent annotation. Report review scope per language, including uncertain examples.

Compare the same fixed Sarvam answer model and answer prompt with: (1) recent history only, (2) ordinary keyword-plus-multilingual-vector retrieval, (3) AgentMem memory. Add full available history as an explicitly larger-context control where it fits. Retrieval arms share a configured token budget, with actual token use reported. Full history is not a matched-compute arm; language tokenization costs are measured rather than assumed equal. Fix extraction settings in architecture ablations and include all ingestion/model calls in costs. Compare external memory frameworks only once the main experiment works.

Measure correct answers/current state, stale-state errors, unsupported facts, mistaken identity links, justified clarification, user leakage and forgotten-data resurrection. Report English-minus-Hindi and English-minus-Telugu accuracy gaps on paired histories, with uncertainty grouped by family. Also report restart persistence, latency, actual token/character usage, API/parse failures and total ingestion-plus-query cost. A tiny pilot cannot establish industry superiority or a precise 90% reliability claim. Use deterministic checks for explicit dates/IDs/sets and reviewed judgments for ambiguous meaning; do not let a generator be the only validator of its own data.

No cross-user disclosure or forgotten-item resurrection is acceptable in the starter release checks; zero observed failures is not proof of zero production risk. Freeze an improvement only if the intended gain is measured without violating these checks. If simple retrieval is as good or better, ship the simpler design or report the limitation; do not make harder test cases after seeing held-out outcomes just to manufacture a win.

## 8. Sequence and working estimates

| Stage | Deliverable | Gate |
| --- | --- | --- |
| Preparation, now | Brief, isolated worktree, decisions, current sources, seven draft English histories | Hindi/Telugu and both use cases recorded; native review still pending |
| Next two focused sessions | Hindi/Telugu review pack; offline metered adapter contract; isolated real-store test path and failure reproductions | Correct native source attribution, scoped state, and an explicit plan for restart/update/forget checks |
| Following integration sessions | One approved small live batch through the real path | Actual ingestion, restart, recall, correction, ambiguity, isolation and forget receipts; no manual oracle facts |
| Following 1–2 weeks | Reviewed 8–12-family pilot, simple baselines, one justified intervention | Configuration frozen before outcomes; paired results and cost accounting |
| By roughly 20–30 days of active work | Runnable demo for both settings, reviewed pilot, evidence report and a concise Sarvam update draft | Report successes and failures; no unsupported benchmark/novelty claims |

These are proposed working estimates from the actual start, not deadlines or guaranteed results. The previously reported 1–1.5 hours/day is a conservative review assumption; the temporary 20-hour English sprint is not assumed as ongoing Sarvam capacity. If reviewing two languages is slower, reduce the family count while preserving both requested languages. Protect founder review time; adding coding hours cannot replace language validation.

## 9. Setup, model and budget

The current API docs mark [Sarvam-30B deprecated](https://docs.sarvam.ai/api/getting-started/models/sarvam-30b). Propose [Sarvam-105B](https://docs.sarvam.ai/api/getting-started/models/sarvam-105b) as the initial fixed extraction/answer model. It is documented for native, Romanized and mixed-language chat. This is a separate Sarvam experiment, not a model change to the fixed-Luna English study. No fine-tuning or GPU rental is needed for the initial API integration.

Before a live batch, verify workspace access, grant activation/current balance and special grant expiry; keep keys in a local secret environment and never in messages, logs, fixtures or Git. The founder's acceptance email states a ₹25,000 grant valid for six months; a generic FAQ statement about non-expiring credits does not settle that grant's terms. Current account facts are unknown.

Reference API prices checked today list Sarvam-105B at ₹29.28 input, ₹10.98 cached input and ₹73.20 output per million tokens; transliteration/translation at ₹20 per 10,000 characters. These are reference prices, not an approved budget or account invoice. Price the exact requests, output allowances, transformations and bounded retries before execution. [API pricing](https://docs.sarvam.ai/api/getting-started/pricing).

The [platform FAQ](https://docs.sarvam.ai/api/platform/faq) says workspace usage is attributable but credit balance is organisation-wide and per-key/workspace spending caps are unavailable. Our runner therefore needs a local dispatch limit and a receipt ledger; that does not prevent other applications from consuming shared credits. No auto-recharge or account monitoring is enabled here. The earlier ₹150 starter/₹2,000–₹3,000 monthly figures remain old proposals, not permission.

## 10. The first package worth showing Sarvam

A short real demo for a personal user and a business customer; a minimal integration/cookbook; a reviewed, versioned Hindi/Telugu pilot with English controls; predictions, sources and limitations; quality/cost/latency comparisons; and concrete reproducible issues attributed to the correct component. A later collaboration request could ask for technical feedback or independent language review. No messages or public claims are sent by preparing this brief.

The immediate task is to prove one small, correct memory path in both languages, then measure whether our architecture adds value. Recognition is outside our control; useful evidence and reproducible engineering are within it.
