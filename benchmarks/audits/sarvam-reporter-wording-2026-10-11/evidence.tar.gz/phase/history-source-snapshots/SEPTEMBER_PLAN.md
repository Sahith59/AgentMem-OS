# English closure and a solo Sarvam pilot: proposed 28-day plan

**September13 execution update:** English remains the active track; Sarvam is parked. The prepared150-pair source screen is offline-verified with59focusedtests, proposed$8.97cap, and exactnewapproval pending. Full500 is83.6%twice; source recovery is partial and QA uplift unknown. Follow [current snapshot](../../CURRENT_STATE.md) and [screen runbook](../../runbooks/ENGLISH_SOURCE_SCREEN.md); original September8calendar below is historical.

**September14 outcome and next gate:** Broad screen70→87 fails controls; precision screen73→85 passes. Exact all500 package`5d97a106…f3b3` then completes423/500=84.6%,+5cases/+1.0point versus each fixed83.6%repeat, with independent integrity andzero retry/error. Annotated-gain cases improve90/92→102, while no-annotated-gain cases regress.90% is not reached and defaults are not promoted. Freeze one identical repeat, require separate exact approval, then close English from repeated evidence without retuning exposed cases. Follow [full500 runbook](../../runbooks/ENGLISH_FULL500_PRECISION.md). Sarvam remains parked pending this final stability decision.

Prepared September 8, 2026 EDT. **Status: PROPOSED, not started.** Authority: founder requested an independently checked replacement plan and confirmed being the sole contributor/reviewer, available 1–1.5 hours daily. No Sanjana or external annotation capacity is assumed. Existing project files and old memories remain unchanged.

**Recommendation:** close English in at most three working days, then produce one real Sarvam-backed memory integration, a small creator-reviewed evaluation, and a reproducible evidence packet. Use the full [proposal review](PROPOSAL_REVIEW.md) for corrections and [artifact verification](artifact-verification.json) for recomputed results. The objective is credible engineering evidence within available time. An accuracy increase or a deeper Sarvam partnership is not guaranteed.

## 1. Constraints and definition of success

- Human budget: plan around **28 hours over 28 days**. An additional 0.5 hour/day is optional reserve, not required labor. Over a 20–30-day window the founder has roughly 20–45 total hours.
- Indic review: include Hindi and Telugu only to the extent the founder can judge meaning, script and identity. Start with the better-reviewed language if necessary. Self-review must be described as creator review; no inter-annotator agreement or independent validation claim.
- Proposed calendar: Day 1 September 9 → Day 28 October 6, if execution starts then. Shift with the actual start date. October 6 is not a confirmed Sarvam meeting; have a useful evidence packet by Day 20.
- Scope: text memory for a **multilingual appointment-and-preference assistant** using synthetic, non-sensitive examples. Voice, a new website, broad autonomous workflows, six baseline frameworks and a funded benchmark release are outside this month's core work.
- Day-20 minimum: working persistence/update/forget demo; at least 20 reviewed scenario families; frozen comparison or an explicit blocker report with saved reproductions; real usage accounting. A small negative result is an acceptable research outcome.
- Day-28 target: 40 reviewed families and four comparison arms, a reproducible local demo/cookbook, a dataset card and evidence summary. If time or cost exceeds measured capacity, reduce scope before accessing the test outcomes.

Suggested allocation: English 3 hours; protocol/integration decisions 4; dataset review 10; comparison/failure review 4; packaging 3; daily accounting/handoff and buffer 4. Total 28 hours. The assistant can prepare code, draft cases and reports during authorized implementation sessions; these are not assumed to run unattended between sessions. Founder time is for review and decisions, not every mechanical step.

## 2. English: freeze the campaign, not a desired score

The verified standing is **H1 80.0% ±0.529 percentage-point run SD across three 500-question repeats; W1 82.6% on one 500-question run**. H1/W1 remain stable claim IDs. “Best numbers” means the strongest honestly reproducible record, not repeating until a target appears.

### E0 — minimum preflight, before further paid answers

Prepare a reviewable execution package with the current W1 configuration, a unique run directory and isolated copies of every accessed store. Do not import project DB modules against live stores: imports and preflights can migrate data. Keep the Luna extraction DB, raw DB, profile source, vector/cache state and their fingerprints explicit. The verified Luna DB hash is in the artifact receipt; it is not committed to Git.

Record source commit plus any later instrumentation diff; dataset hash and exact 500 IDs; question text mapping for legacy outputs; corpus/schema hashes; model aliases/returned identifiers; exact prompts; retrieval/context settings; reasoning settings; output caps; provider usage; timestamps; retries and errors. Hash assembled contexts and save them where permitted so future answerer comparisons can actually reuse the same bytes. Do not put credentials in the manifest.

Minimum harness safeguards: unique output creation; manifest-bound resume or no resume; exact expected question-set validation; separate intended/completed/failed counts; no success report for missing rows; actual usage logging. Atomic checkpoints should retain valid previous output after interruption. These are narrow fixes for a later implementation session, not a prerequisite to resolve all 40 historical findings.

Keep the W1 nominal protocol: same corpus, raw/fact/profile sources, 0.35 facts share, hybrid off, dense retrieval configuration, 40,000-character cap, two neighbors, 800-character snippets, all six types, seed 42, Luna reasoning answerer and existing judge protocol. Do not silently add ledgers, change the judge snapshot or alter provider reasoning defaults in a purported repeat. Preserve actual settings and disclose mutable aliases. If historical configuration cannot be reconstructed reliably, label new runs as a fresh protocol series.

### E1 — two repeats, fixed stopping rule

Propose at most two additional full W1 repeats, only after the preflight and a concrete cost estimate. Start with a proposed **$10 maximum envelope** for English, subject to actual price/usage calculation and explicit execution authorization; this planning request did not authorize spending. If the projected cap cannot cover both, report that before launch. Do not buy another extraction corpus.

Publish all complete runs with counts, mean, sample run SD, range, per-type results and descriptive paired wins/losses versus H1. Do not select runs based on whether they reach 82–83%. A run may fail operationally; preserve it as an incomplete result, report its cost, and resolve completion within the fixed run/budget policy rather than quietly replacing poor answers.

The same 500 questions have been used repeatedly during development. Run SD measures repeat variability; it is not fresh generalization evidence. Do not call three repeats 1,500 independent examples. Pool the existing W1 with the repeats only if nominal protocol parity is defensible; disclose missing old fingerprints/provider drift even then.

### E2 — close by Day 3

Close with one of two honest outcomes:

1. **Repeated W1 result:** three comparable complete runs, all reported, with a preserved H1 comparison and reproducibility package.
2. **Existing-evidence closure:** retain repeated H1 80.0% and preliminary W1 82.6%, explicitly state repeats pending, and move to Sarvam. Inability to spend or reconstruct the protocol does not hold the entire project hostage.

Suggested closure language: “We freeze this English evaluation campaign at the reported configurations. The tested packing, routing, structured-answer and ledger interventions did not establish a reliable gain sufficient to justify further work in this cycle. Remaining errors include evidence-delivery and answer-construction questions that these experiments do not fully disentangle.”

Later authorized documentation changes should update a single metric registry and its public references together, retaining original artifacts and claim IDs. Do not overwrite old memory. Commit/push only as part of a requested publication task. Before presenting an installable release, resolve the current dependency-install CI failure and verify the actual installation path. That release check is distinct from recounting historical QA results.

Park additional English answerers, another extraction sweep, LoCoMo and Graphiti head-to-heads for this cycle.

## 3. Sarvam: a small evaluation with a real user path

### First five development fixtures

Before freezing the scored protocol, use five explicitly excluded fixtures to validate: rendering fidelity, schema, answer equivalence, language review time, API costs and the real integration path. These fixtures must never enter the final score. A small dry run prevents committing to an impossible specification; freeze before scored comparisons or optimization.

The actual path must ingest native-language text, extract/store supported facts with Sarvam, survive process restart, retrieve them in a later session and answer with Sarvam. The benchmark adapter and demonstration should use the same memory path. If native-only evidence fails the current support check, fix or explicitly constrain that path; do not translate an answer into the store by hand and call it native ingestion.

Use a short, repeatable demonstration:

1. A user gives an appointment or preference in a reviewed Indic language.
2. Restart the process; ask in a new session, with no history hidden in the prompt.
3. Correct the time or preference in another reviewed rendering; ask for the current value and a historical value.
4. Present a similar name belonging to a different synthetic person; preserve uncertainty instead of merging it automatically.
5. Forget the information; verify that raw, fact, profile and cache/vector retrieval paths do not resurrect it.
6. Use a second synthetic user scope to check isolation; an assistant suggestion must not silently become a user assertion.

Keep this local until the real access-control requirements of any shared deployment are implemented. A polished video is secondary to saved requests, source references, state transitions and repeatable execution.

### Dataset target: 40 families, 400 paired instances

A family is one independently authored synthetic event history with formal expected state, timestamps, source turns and explicit identity assumptions. Generate the state first; render its conversation second; review whether the rendering preserves the state. The gold graph is used only by the evaluator/oracle, never supplied to memory extraction or normal retrieval.

Use five slices, eight families each: preference replacement; appointment rescheduling; cancellation followed by a new booking; similar identities with insufficient evidence to merge; historical-time questions and justified abstention. Each has two locked queries, including current-state and temporal/negative behavior as appropriate. Keep complexity representative of the chosen use case rather than adding obscure traps solely to lower a baseline.

For the first controlled language experiment, keep the query and required answer language English and vary the memory source:

| View | History | Query / answer |
| --- | --- | --- |
| EN control | English | English |
| HI native | Hindi, native script | Same English query / answer contract |
| HI mixed | Reviewed Romanized/code-mixed Hindi | Same English query / answer contract |
| TE native | Telugu, native script | Same English query / answer contract |
| TE mixed | Reviewed Romanized/code-mixed Telugu | Same English query / answer contract |

40 families × 5 views × 2 queries = **400 instances per system**, not 400 independent families. Render each history once and reuse it for its queries. This specifically tests changing the history language while holding the reader question constant. It does not establish all query-language directions. Native-language questions belong in a separately labeled end-to-end demo/check set; expand the benchmark's query-language axis in a later version.

Split by family before rendering: 20 development and 20 held-out families, stratified four per slice on each side. Use different entities and genuinely different event skeletons across the split; renaming the same template is insufficient. All translations, scripts and queries of a family stay together. Hash/freeze test labels before predictions, and do not use test errors to tune the reported candidate. As sole author, the founder is not blind to test content; disclose this limitation.

Founder review verifies identity, dates, negation, cancellations, code-mix naturalness, source support and answer equivalence. Record minutes and pass/revise/drop per family and rendering. Reserve about ten human hours: 40 families fit only if mean review is around 15 minutes or less. Measure the first five; if longer, reduce to 20 balanced families before test access. For one reviewable Indic language, use EN plus native/mixed views: 40 × 3 × 2 = 240 instances (or 20 × 3 × 2 = 120 at the floor). Do not leave unreviewed languages inside a “reviewed” headline.

Re-review 10% after a delay to catch consistency errors, labeling this self-review. It is not a substitute for a second annotator. Release, if later authorized, as a **creator-reviewed alpha**, with exact exclusions, synthetic origins, license/source provenance and known language limits.

### Comparison design

Core arms: full history + Sarvam-105B; BM25 + that same reader; multilingual-e5 retrieval + that reader; AgentMem + that reader. Freeze an untuned AgentMem configuration before development changes. If development produces a candidate, freeze it before the held-out run and label both versions; omit the extra candidate arm if there is no change.

Use the same histories, query text, answer contract, reader model/API variant, reasoning/output settings and deterministic scoring across arms. Start with a proposed **2,048-token retrieved-context cap** for the three retrieval arms, using a specified tokenizer; validate it on excluded fixtures before locking. Log source lengths, truncation and actual provider usage. If a history already fits the cap, label that fact and interpret it as a language/state correctness test rather than a long-history compression win.

The full-history arm receives all available raw history and therefore intentionally has a different input budget. Its role is a quality/cost control. `sarvam-105b` supports a 128K context window; this is a ceiling, not a request to pad every prompt to 128K. The conversations variant has a different window. Check total input plus output headroom and the actual account's limits. Pin the standard model/API variant and reasoning setting in the new protocol. [Sarvam model guide](https://docs.sarvam.ai/api/getting-started/models/sarvam-105b)

Primary metric: answer/state correctness from the graph with predefined canonical forms, exact dates/sets and explicit abstention rules. Report invalid outputs and transport failures separately and within an all-intended-case success rate. Use human review for ambiguous semantic judgments, with system identity hidden where feasible. Do not let the generating model certify its own translations or serve as the only truth judge.

Secondary diagnostics: supported-fact precision/recall; required-evidence retrieval; stale-state answers; false identity merges; justified abstention; per-language/slice correctness; ingestion and query latency; input/cached/output usage; retries and total ingestion-plus-query cost. Publish numerator/denominator, not just F1. Estimate paired differences/uncertainty by resampling families, retaining all views together. Twenty held-out families have limited statistical power; no sweeping superiority claims.

Mem0/Graphiti are optional only after the core evidence exists. Bound any extra adapter attempt to one implementation day and at most one founder review session; save a concrete incompatibility/runtime finding if it exceeds that. Do not make a second framework integration the month's critical path.

### Targeted experiments, only after error diagnosis

Use 10–20 reviewed development families to compare Sarvam-105B extraction with the existing local llama baseline under the same schema/input. Add GPT-4o-mini only if its separate cash budget is justified and authorized. Count unsupported extra facts and missed updates, not just syntactically valid JSON. Fix the reader while studying extraction; fix extraction while studying retrieval.

Try transliteration if script-dependent misses dominate, preserving originals and storing derived aliases with provenance. Measure false merges as well as recall; do not enable irreversible automatic merging just because F1 improves. Use language ID only if it demonstrably helps the development set, with a no-routing comparator. The endpoint's 1,000-character input and single language/script result do not establish full code-mix segmentation. [Transliteration](https://docs.sarvam.ai/api/api-guides-tutorials/text-processing/transliteration), [language ID](https://docs.sarvam.ai/api-reference/text/identify-language)

The old 53-entity suite is a useful separate diagnostic, not a universal dependency. Keep unsupported language portions DRAFT. Re-score existing predictions only when their input pairs are unchanged; changed spellings or normalization need new calls. Recompute cosine and judge metrics on identical pairs before comparison. Do not lower the existing precision requirement to make a merge configuration pass.

## 4. Schedule and acceptance evidence

| Days | Main work | Required evidence / founder focus |
| --- | --- | --- |
| 1–3 | English closure; prepare five excluded Indic fixtures; establish account facts when access is available | Frozen English record or explicit preliminary label; repeat preflight if running; review use case and actual credit terms |
| 4–7 | Real Sarvam ingestion/restart path; fixture review; meter a small authorized batch; freeze alpha protocol | Source-supported native fact survives restart; measured minutes/cost; protocol and family split manifest |
| 8–14 | Review data within ten-hour allowance; run simple development baselines; fix actual integration failures | At least 20 reviewed families, aiming for 40; per-rendering review ledger; development error taxonomy; saved version before tuning |
| 15–20 | Freeze candidate; run held-out comparison once under the locked protocol; assemble minimum packet | Intended/completed counts, per-family outcomes, cost/latency table and real demo. Report blockers honestly if runtime work remains |
| 21–24 | Improve reproducibility and documentation; rerun smoke/demo in a clean isolated environment | Install/run instructions; data card; actual before/after evidence for any fix. No tuning on held-out errors |
| 25–28 | Buffer; concise check-in package; decide next research question from evidence | Final artifacts and remaining limits; draft one concrete collaboration ask, ready for review but not sent |

Daily routine: five minutes for status/cost/freshness; forty minutes on the day's review or decision; fifteen minutes for accepting evidence and writing the next handoff. Use optional extra time for review backlog, not automatic scope expansion. Each record must state expected outcome, actual result, artifact path, spend, human minutes and next action. A blank day is not progress; a blocker with a minimal reproduction is useful progress.

## 5. Budget: quote from units, then bound the run

Current 105B reference prices are **₹29.28 input / ₹10.98 cached input / ₹73.20 output per million tokens**. The API pricing page lists translation/transliteration at ₹20 per 10,000 characters; the public pricing page lists ₹0.005/character for several plans and ₹0.004 for Business under a differently labeled section. Reconcile endpoint/product scope and the startup account's applied rate before projecting scale. [API prices](https://docs.sarvam.ai/api/getting-started/pricing), [public prices](https://www.sarvam.ai/api-pricing)

Illustrative transformation sensitivity, not an invoice: 40 families × four transformed histories × 3,000 characters = 480,000 charged characters if each operation bills that assumed length. This is ₹960 at ₹0.002/character, ₹1,920 at ₹0.004 or ₹2,400 at ₹0.005, before LLM work. At 200 families, the same assumptions become ₹4,800–₹12,000. Actual output lengths and chained operations can change billed units; meter them. Reusing one rendering across questions avoids needless duplicate transformation calls.

For illustration only, 400 instances × four arms × 3,000 average input tokens = 4.8M input tokens, about ₹140.54 at the uncached rate; 500 output tokens/call adds about ₹58.56. Ingestion, rendering, longer full histories, hidden reasoning, retries and extra candidates are additional. These workload assumptions are not measured estimates and must not be substituted for receipts.

Proposed Sarvam envelope: a first metered stage of at most **₹150**, then revise the workload quote; aim for **₹2,000 total**, with a proposed **₹3,000 maximum** for the month. These are proposals, not authorization or provider-enforced caps. If confirmed pricing makes the workload exceed the envelope, reduce families/rendering length/optional arms before spending. Reserve at least 20% of the approved envelope for retries and unresolved in-flight work. Stop dispatch before projected maximum outstanding cost can exceed the remaining allowance.

Sarvam does not currently provide per-key/workspace spend caps; multiple keys share the organisation balance. A local run limit cannot stop other consumers spending the same credits. Reconcile app receipts to the dashboard and do not infer that ₹25,000 remains available just because it was awarded. No top-up, auto-recharge or paid account change is included. [Platform FAQ](https://docs.sarvam.ai/api/platform/faq)

Use the endpoint-specific 105B rate limit, not the generic Business rate. At review time the documented Business 105B limit is 120 RPM, shared across keys; verify the actual account before setting concurrency. [Rate limits](https://docs.sarvam.ai/api/getting-started/ratelimits)

## 6. Conditions that should change or stop the plan

| Trigger | Response |
| --- | --- |
| English goes beyond three working days or starts chasing a score | Close with existing evidence and label repeats pending |
| Native review exceeds capacity, or a language cannot be competently reviewed | Reduce the family/language scope before held-out evaluation; preserve DRAFT labels |
| Current install or real memory path cannot support persistence/update/forget | Prioritize a minimal reproducible fix on that path; do not substitute a mocked demo |
| Wrong-user disclosure, forgotten-data resurrection or unsupported automatic identity merge in the demo | Block a reliability claim/shared demo until fixed and behaviorally verified |
| Transport/parse failures exceed a proposed 5% in the small preflight | Stop expansion and diagnose; retain failures in reporting rather than treating them as correct refusals |
| Cost quote exceeds the remaining approved envelope, or usage is missing | Stop dispatch and reconcile; do not consume the credit grant blindly |
| No useful gap on the locked task | Report it. Consider cost, latency and correctness tradeoffs already specified; do not increase difficulty after seeing test results to manufacture a win |
| A held-out error suggests a fix | Explore later under a new version and fresh confirmatory holdout; label reused-test results exploratory |
| Check-in preparation crowds out actual evidence | Ship a shorter packet. One working example plus an honest failure report is better evidence than an unsupported claim |

## 7. What to have ready for Sarvam

One concise evidence package: (1) a runnable integration/cookbook and short real demo; (2) the reviewed alpha dataset, protocol and data card; (3) a quality/latency/total-cost comparison with limits; (4) minimal reproduction reports for actual issues found, with sanitized requests, model/version, source evidence, expected/actual output and fix status; (5) a one-page progress note with one concrete ask, such as engineering feedback on the native support failure or help obtaining independent language review.

Do not invent a quota of vendor bugs, imply model training contributions from an API wrapper, or promise a world-first benchmark. The defensible contribution is a tested memory integration and evidence about where Sarvam-backed systems succeed or fail. Any public release, message to Sehaj or funding request is a later explicit action. Re-cost a larger study from measured review yield; the earlier $13–30K/12–14-week proposal is not a validated delivery estimate.

Account access and the prepared monitoring workflow are in [MONITORING.md](MONITORING.md). Neither a scheduled task nor paid execution was enabled by writing this plan.

## September 11 paid character-retrieval checkpoint

The founder approved the frozen19-case word-versus-character gate. It completed all19 pairs: word12/19 and character16/19, four gains and zero losses. Answerable cases improved8/14→12/14; abstentions stayed4/5.69 provider calls plus7 shared judgments completed with zero errors/retries; usage-derived cost estimate was$0.0906938.

The frozen screen still fails because its required three-trip case remains wrong. Character retrieved exact Big Sur and Yosemite events plus a related Muir/Dipsea fact, but omitted the explicit completed family Muir day-hike fact. This corrects the earlier offline packet claim. Historical82.6% remains the only full500 headline and is still qualified by the source-date/role defects.

Immediate sequence: (1) test a small dated-event reserve offline across all500 scopes and the saved19 cases; (2) preserve the four gains and abstention behavior; (3) address the34 scopes with no stored gold-source facts; (4) freeze the complete corrected pipeline; (5) seek fresh approval for a corrected full500 only after those gates pass. Sarvam remains parked until the English closure decision.

## September 11 dated-event gate update

Steps1–2 now pass offline. The final one-turn reserve changes only the two target packets in the saved19 cohort, restores exact Muir/Met evidence, preserves the17 others byte-for-byte and loses no fact lines. Across all500 scopes, six admitted reserve messages pass complete manual review; proxy annotated-source coverage gains two turns and full packets for all19 triggered questions gain five, with zero loss. This is retrieval evidence only.

The next bound step is a two-case paid confirmation under a frozen package: four answers, at most eight calls, conservative reservation$0.1617645, proposed cap$0.20. It requires both candidate targets correct, at least one paired gain and no loss. Fresh approval is pending. After a pass, step3 remains the34 scopes without stored gold-source facts; only then freeze the combined candidate and consider a separately authorized full500. The historical82.6% headline remains unchanged.

The34-scope step is now narrowed by evidence:30 were already W1-correct and28 ask for prior assistant content. Target only the four W1 errors and preserve the30 as controls; avoid converting assistant recommendations into user facts. [Classification](../../runs/english-improvement-2026-09-11/no-gold-fact-scope-audit-001/REPORT.md).

## September 12 execution update

The two-case dated-event confirmation passed0/2→2/2. The subsequent four-case diagnosis found literal answer evidence in all four current packets; ranked recall display and a narrow last-weekday source-event route now put4/4 answer needles inside the first24k, from2/4. All54 recall and all500 dated-event offline screens pass their frozen no-loss gates, with complete manual review of nine event admissions and an independent artifact verifier.

PR#2 merged the four independent commits into `main` at `705772b`. The three byte-changed-case QA gate now passes2/3→3/3 with one gain and zero losses. Historical full500 accuracy remains82.6% because this is development-exposed and no combined full500 answers were generated. Freeze the corrected broader cohort offline next; only after its packet/control checks should another answer run be priced. Sarvam remains parked.

The broader cohort is now complete. Census001 caught an empty-reserve deduplication side effect; PR#4 fixes it and is merged with green CI at `c95a8a4`. Census002 passes110/110:63 intended changes,47 byte-identical controls, no annotated-session loss, positive evidence coverage in both frozen splits and exact reproduction of earlier54/24 packet artifacts.

The next exact decision is a35-case changed-confirmation QA, canonical package SHA `43a380c8f34e5fc0fc9dc038cd7f20000a24f807dd909ed767f561807018216e`, proposed$3 cap against$2.80198225 conservative reservation.27 cases are never-paid, but only one is a never-paid historical W1 miss; use this as a regression/mechanism gate. A pass leads to separately prepared full500 measurement. No new spend is authorized; Sarvam remains parked.

The founder-approved run is now complete and the gate failed despite a positive24/35→28/35 paired result with zero losses. Do not advance to full500. The new critical path is answer-span delivery for assistant recall and long messages, multi-event temporal collection, then a prospective combined retrieval plus evidence-sufficiency prompt confirmation. The prior$3 approval is exhausted; no repeat or larger run is authorized. Historical full500 remains82.6%; Sarvam stays parked until this English decision gate is repaired and re-evaluated.
