# Sarvam discovery preparation — October 9–10, 2026

**VERIFIED_COMPLETE locally:** reviewed fixtures, runnable comparison, separate evaluator, metering and offline failure tests. **No live Sarvam result.** GitHub PR44 CI/merge still in progress at this entry; final Git receipt will be recorded separately.

## Deliverables

- 38 synthetic renderings in English/Hindi/Telugu, 12 scenario templates, 9 underlying family groups, including verified-vs-ambiguous identity. All labels and original evidence are versioned. D01/D02/D03/D08 share a family; translations/repeats are correlated.
- Same Sarvam-105B answer settings in full-history and ordinary SQLite arms. SQLite has extracted facts AND all authorized original records, even if extraction misses a fact. Every SQLite case closes/reopens its store. Query/fields/gold are absent from extraction input.
- Two repeats: 76 extraction requests plus152 answer requests =228 maximum attempts, no retries. First request also verifies transport/response compatibility; any contract failure stops. This is not total-compute-matched; extraction belongs to SQLite cost.
- Deterministic exact-field and clarification scoring, separate required-source coverage, per-case wins/losses, family/language/repeat slices, per-arm token/cost totals, failed/unattempted denominators. No LLM judge or stronger model.
- Frozen package binds source/fixture/review hashes, requests, dependent request derivation and spend limits. Durable reservation before dispatch, raw receipt before parsing, failure usage retained, no silent fallback, no reasoning-output parsing, no automatic retry after timeout/interruption.

## Verification

46 focused tests pass, with network forbidden in the test suite. Covered complete228-call simulation, persisted-store tampering, altered manifests/requests/receipts, duplicate provider IDs, truncated/reasoning-only/malformed responses, missing usage, model mismatch, authorization/budget rejection, pending crash and zero-dispatch completed resume. Ruff and whitespace checks pass. A separate228-call simulated execution saved76SQLite databases, full receipts and a SIMULATED_TEST_ONLY report. Fake outputs deliberately abstain and never consume gold; no fake score is a Sarvam result.

A clean Git export with standard-library-only Python reproduces the frozen package checks; the new dataset is tracked under fixtures/ and avoids the old ignored data/ problem. See verification.json and tests.xml. Source commits:7e662b1fixtures,53818e4runner/tests/protocol. Peer review by the existing GPT-6-sol reviewer found and corrected seven issues; see REVIEW.md and committed review.json. All38cases have assistant peer review. Independent human/native validation remains pending.

## Proposed live boundary — not authorized or executed

Package SHA256: acf3956980d4acdc4cc8b740aaff6e4dd1f1908f310d98ed247ca2b2ef178b0c.

Fixed sarvam-105b, temperature0, reasoning_effort low, max_tokens4096, n1, JSON_object, no model fallback. Whole-package reservation ₹943.37630208 at frozen uncached input₹29.28/output₹73.20per1Mtokens. The conservative reserve uses131072input +4096output tokens per attempt, not a tokenizer estimate. Not an expected bill, account-wide limit, tax estimate or provider invoice guarantee. Actual token-based amounts reported separately; invalid outputs still cost money. Official rates/API/model pages rechecked October9; recheck before activation. Account credentials and provider behavior remain unverified.

Approval template is false with empty authorization text. Credits and general enthusiasm do not authorize this specific live spend. Ask approval for at most228calls and approximately₹944conservative reservation, explicitly accepting exploratory assistant-reviewed labels. Credentials must be configured locally in a standard Sarvam environment variable; never request a key in chat. No key values/localsecret files were read. This turn made0paid calls/spent₹0.

## Interpretation boundaries and next step

This answers whether fact augmentation helps or harms on these short controlled histories. It cannot establish an AgentMem production improvement, advanced retrieval performance, actual tool execution, authentication, erasure, native Sarvam CRM/hooks superiority or all-language quality. The withdrawn-address case retains audit originals and tests answer suppression only. All38published development cases are excluded from future held-out evaluation.

After approved live execution, review every miss/regression and both repeats. Both controls passing is a useful negative product-gap result. Full-history pass/SQLite fail suggests harmful extraction or misuse of facts. Both failing requires annotation/protocol/language review before blaming retrieval, because originals are present. SQLite gains require compute-matched controls and new held-out families before causal/novelty claims. Do not invent a product merely because the prototype can be built. Native platform/framework controls and remaining endpoint-supported languages remain required later. English stays in the original chat; no English score/configuration changed.

## Git completion update

PR #44 merged as4656fbc after full exact-head CI success on53818e4. Both independent commits are preserved. Main and Sarvam checkouts fast-forwarded; founder changes remain. Merged and reviewed trees are identical; frozen-package validation passes unchanged. See git-completion.json. Automatic main CI still running at this update. CASE_REVIEW.md supplies all38cases and their gold/source labels in readable form, evaluator-only.

Final verification: automatic main-branch CI passed on 4656fbc at 04:07:40 UTC. Preparation is complete, committed, pushed and merged. Both implementation commits are preserved. See completion.json for the final receipt. No live inference or paid spend; exact approval and local key remain the activation requirements.
