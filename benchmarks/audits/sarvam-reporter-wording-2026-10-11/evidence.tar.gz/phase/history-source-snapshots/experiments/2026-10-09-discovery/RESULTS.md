# Discovery grounding — October 9, 2026

**Outcome:** the simple delivery-state example is solvable using ordinary structured storage; it is not a differentiating mechanism by itself. The historical identity evidence also has concrete input/label and reproducibility limitations that must be addressed before fresh model experiments. No live Sarvam result or architectural accuracy gain is claimed.

## What executed

Ran [offline_checks.py](offline_checks.py) against explicit read-only source paths, Python AST data extraction, and isolated temporary SQLite stores. No project-module imports, environment-file reads, network requests or model inference. The script binds results to its own hash, the preceding [protocol](PROTOCOL.md) and source hashes, and refuses to overwrite old results. Evidence: [offline-results.json](offline-results.json).

### Ordinary storage control

Five synthetic structured receipts represent initial confirmation, a new request, rejection, a later accepted change, and an older delayed confirmation. All 120 arrival permutations retain the latest confirmed state. Replaying all five events in each permutation adds no new event or state change. Ten named checks pass for request-versus-confirmation, failure behavior, delayed state, explicit tenant/customer scoping, conflicting receipt rejection and close/reopen persistence.

This tests conventional persistence/versioning/idempotent ingestion of already-structured, trusted backend receipts. It does not test language understanding, model extraction, genuine authentication, live tool execution, concurrent database clients or a production deployment. No production DB was accessed. No conclusion about current Sarvam model behavior follows. The useful result is a scope correction: do not build or market an ordinary event-ordering fix as our novel memory contribution.

### Historical identity audit

The current local fixture reconstructs all 344 archived pairs exactly: 53 entity groups; TP 109, FP 17 and FN 16 under the original draft labels. Historical precision 86.51% and recall 87.20% are unchanged. They remain label-relative component metrics, not verified current-model or memory-answer accuracy.

Material findings:

1. **Input can lack the information needed by its gold label.** The pair-only prompt asks whether mentions must denote the same specific real-world entity. The fixture labels “Anand Krishnan”/“Anand K.” as a merge without supplying their account/alias context. The saved model asked for context. The offline two-world check shows identical name-only observations compatible with either one verified person or two different verified people. Context-free abstention must not automatically be interpreted as a retrieval or model-capacity defect.
2. **Task types are mixed.** Class D contains 24 positive pairs of code-mixed sentence fragments. For example, two versions of “send 5000 rupees” are labeled MERGE in an entity-identity task. Equivalent wording does not by itself identify a particular transaction or referent. Use separate semantic-equivalence and referent-identity tests with explicit context.
3. **Some negative rationales do not establish different entities.** “Vanarasi” is a negative because its string differs from “Varanasi.” String difference alone cannot decide typo/alias versus distinct place in a particular conversation. These labels need adjudication; no regrading was done.
4. **Ten of the sixteen draft-label misses were NEED_CONTEXT.** This is a breakdown of archived decisions, not proof that all ten labels are wrong or all refusals are correct. All 33 binary disagreements are preserved in the result file for review.
5. **Reproduction from a clean checkout is incomplete.** `benchmarks/data/xling_alias_eval_v1.py` exists in the founder's main working directory but is not tracked in Git. `git check-ignore` identifies the `data/` ignore rule. The tracked runner imports that file, so the clean Sarvam worktree lacks a required input. Source commit 9572a28 and file hashes are recorded. Do not edit the founder's already-modified .gitignore as a shortcut; publish reviewed, licensed fixtures explicitly with the eventual benchmark.
6. **The archived receipt is incomplete.** Saved rows omit raw model responses, returned model/fingerprint, usage and attempt receipts. The old runner permits verdict parsing from concatenated final content and reasoning text, and groups provider ERROR with no-merge for its effective decision. These are runner-design limitations; zero ERROR rows occur in this saved artifact, and we cannot infer that any particular verdict came from reasoning. A fresh runner must preserve raw final output and separate protocol failure from semantic abstention.

These findings concern our test and evidence quality. They do not prove Sarvam has a defect or justify erasing historical numbers. Original files, grades and saved outputs are unchanged.

## Current API preparation

Official docs checked October 9 still list both 105B variants and their different context limits. The model page and v1 reference disagree about default reasoning effort, so a future run must set it explicitly. Official pricing lists ₹29.28/1M input and ₹73.20/1M output for both variants. None of this verifies our account, quota or billing. [Model](https://docs.sarvam.ai/api/getting-started/models/sarvam-105b), [v1 reference](https://docs.sarvam.ai/api-reference/chat/chat-completions-v1), [pricing](https://docs.sarvam.ai/api/getting-started/pricing).

Only environment-variable presence was checked: neither SARVAM_API_KEY nor SARVAM_API_SUBSCRIPTION_KEY was present in this process. No values were printed and no local secret file was inspected. The founder reports credits and APIs; that status is user-reported, not contradicted by an unconfigured process. No access or spending request is needed for the completed offline work.

## What follows from these results

Use the simple delivery example as a control. Build the first live pack around valid, context-complete contrasts that can distinguish language conversion, extraction, retrieval, evidence delivery and answering. [PROTOCOL.md](PROTOCOL.md) defines 12 discovery families, strong simple controls, an explicitly diagnostic exact-evidence path, family-level exposure tracking and stop rules. It is a study design; native fixtures, live adapters and an exact request/cost manifest remain pending.

The all-language scope and required public benchmark remain. Start with reviewed slices and list the rest as pending. If strong full-history/native/ordinary-storage controls solve the cases, retain that positive finding and do not invent a gap. If a failure survives valid labels, repeats, matched configurations and a relevant real workflow, then investigate the smallest effective fix and compare against prior art. No unique product or Sarvam endorsement is promised.

Reproduce the offline instruments from the outer workspace:

```sh
python3 codex-memory-2026-09-08/tracks/sarvam/experiments/2026-10-09-discovery/offline_checks.py --workspace /Volumes/Sahith_SSD/AgentMem-OS --output /tmp/sarvam-discovery-new-result.json
```

The output path must not already exist. Historical source data currently requires the local ignored fixture described above; this command is not yet a public clean-clone reproduction contract. No product source file or Git branch was changed by this research experiment.
