# Sarvam decision log

## S-001 — October 7, 2026 — track ownership (founder decision)

The founder forked the chat and assigned this fork to Sarvam. The original chat owns English accuracy improvement. Create a dedicated worktree and Sarvam memory directory. Do not alter the English model/configuration or score gates. Supersedes the earlier instruction to park all Sarvam work until English exceeds 90%.

## S-002 — October 7, 2026 — languages and use cases (founder decision)

The founder selected Hindi and Telugu and both personal-assistant and small-business-assistant use cases. English supplies matched comparison histories. No assumption that language selection equals independent native validation. One shared engine and two scenario sets is the recommended implementation structure.

## S-003 — October 7, 2026 — integration before large benchmark (recommendation)

Use seven excluded development histories (five preserved, two new business drafts), then a small reviewed pilot. Larger dataset/framework coverage is conditional on actual review capacity and demonstrated runtime behavior. Source-preserving updates/identity remain hypotheses, not novelty claims.

## S-004 — October 7, 2026 — current provider and spending boundary

Official docs deprecate Sarvam-30B. Recommend a fixed Sarvam-105B first configuration; exact prompts/settings pending adapter preparation. GPT-4o retirement remains. No live calls authorized by this planning request. Credits/account access are not inferred from the grant email. No messages to Sarvam or publication initiated.

## S-005 — October 7, 2026 — native forgetting is an early correctness requirement

Static source inspection and a pure regex probe expose Latin-only matching in forget_about. No source fix is claimed. Verify native matching, scope, derived-state invalidation and restart/re-ingestion behavior in isolation before a reliability demo. Evidence: verification.json. Avoid presenting a raw-turn flag change as full-system erasure.

## S-006 — October 8, 2026 — all-language scope (founder correction)

Intended product/evaluation coverage is all languages supported by the relevant Sarvam routes, not Hindi/Telugu only. Supersedes the product-boundary reading of S-002. Hindi/Telugu may be initial review slices, not a release-wide support claim. Maintain endpoint-specific support, language/script review and actual test status. The documented 23-language Indian/English core differs from 105B's 11 languages; hosted beta coverage is not fully enumerated in reviewed docs. Never infer support from tokenizer metadata or a different endpoint.

## S-007 — October 8, 2026 — research before product, benchmark required (founder correction)

Supersedes S-003's integration-first sequence and the October 7 brief's immediate build recommendation. Deep public capability/market/prior-art research precedes final requirements. A public benchmark with reproducible artifacts is a required deliverable from the outset; staged execution must keep missing language coverage explicit. A blueprint is not a published benchmark, and a small founder-reviewed pilot is not independent proof.

## S-008 — October 8, 2026 — test against existing capability (research recommendation)

Official Sarvam docs/product material show existing CRM/context/tool integration; established memory frameworks already cover many proposed primitives. Treat cross-session state correctness as a testable hypothesis, not an established Sarvam gap. Require full-history 105B, ordinary persistent SQL/event-log retrieval and native Sarvam configuration where access allows. Separate unrestricted full history from compute-matched tests; compare on the same fit-eligible questions with output/reasoning capacity reserved. Framework internals or inaccessible products must not be falsely described as matched. One mechanism at a time, all-stage costs reported. If the simpler control works as well, prefer it or publish the negative result.

## S-009 — October 8, 2026 — claims and evidence boundary

Do not claim “first multilingual memory benchmark,” “Sarvam has no memory,” or known superiority. New Measure's reported failures are a causal lead, not isolated memory evidence or a current Sarvam score. Log existing broad README/Indic-roadmap copy as a correction backlog. Preserve October 7 snapshot and draft fixtures; write research/memory only in this turn. No paid inference, provider access, user outreach, product code change or benchmark publication occurred. [Research report](research/2026-10-08/RESEARCH_REPORT.md) is the current rationale.

## S-010 — October 9, 2026 — ordinary controls and valid evidence first

Founder asks for broad experiments and a meaningful contribution, and questions the generic delivery example. Executed offline structured SQLite controls and historical evidence audit before live inference. Delivery ordering/idempotent receipt ingestion succeeds under ordinary storage and remains a control, not a novelty claim. Broaden discovery through prespecified language/context/history/source-authority contrasts; do not accumulate unbounded experiments just to find a negative result. Product requirements depend on reproducible, consequential failures under strong controls. Evidence: experiments/2026-10-09-discovery/RESULTS.md.

## S-011 — October 9, 2026 — repair evaluation validity before new scores

Historical alias labels mix entity identity with sentence equivalence and sometimes omit necessary context. Preserve old scores as draft-label-relative; no retrospective relabeling. All 344 pairs reconstruct, but the required fixture source is ignored/untracked and absent from a fresh worktree. Public reproducibility requires complete reviewed inputs. Fresh runner must separate errors from abstention, parse final output only, retain raw receipts and record explicit model/reasoning settings. No current Sarvam defect follows from this audit.

## S-012 — October 9, 2026 — live readiness remains concrete

Founder reports credits/API access and wants to understand the experiments before jumping in. No live package was ready in this turn; no calls or spending occurred. Only process environment key-presence booleans were checked, both false; local secret files were not inspected. Prepare reviewed fixtures, tested adapters and a request/cost manifest before requesting live scope. Do not request an unbounded run or keys in chat. All-language scope and public benchmark requirement remain.


## S-013 — October 9–10, 2026 — preparation implemented (founder authorization)

Founder asks to prepare reviewed cases and a runnable metered comparison. Implemented only the Sarvam discovery harness/fixtures in its dedicated worktree; no production or English changes. 38renderings/12templates/9families, two repeats, 228calls in the proposed package. Separate assistant reviewer corrected actor/condition/duplication/ambiguity and baseline/accounting errors. Independent human/native validation remains pending; exploratory live approval must accept that level. Public development fixtures never become held-out data. Evidence: experiments/2026-10-09-comparison-preparation/REVIEW.md and RESULTS.md.

## S-014 — October 9–10, 2026 — strong ordinary baseline and accounting

SQLite retains every authorized original record independently of extraction. Fact-only retrieval would artificially weaken the control and is excluded from the primary comparison. Same answer model/settings/evidence, but SQLite adds extraction compute; do not call this compute-matched or a new retrieval architecture. Assign all extraction, including failures/repeats, to SQLite. Source coverage and exact answer correctness are separate from entailment precision. Pending/failed calls keep reservations and never automatically retry. Model errors are not abstentions. 46offline tests and clean Git export verified; no inference gain inferred.

## S-015 — October 10, 2026 — exact activation boundary

Frozen package acf3956980d4acdc4cc8b740aaff6e4dd1f1908f310d98ed247ca2b2ef178b0c permits a maximum228requests with explicit approval, no retries. Conservative frozen-rate reservation ₹943.37630208, not expected spend or an account-wide cap. Standard environment-only credentials, no key in chat. No live request was executed; approval template remains false. Product requirements still follow evidence; passing simple controls argues for simplicity, not for expanding until a failure is found. Supersedes S-012 only on offline readiness, not on spending permission or established model capability. Git CI/merge receipt to be added on completion.

S-015 completion receipt: PR #44 and automatic main CI both passed; merged as 4656fbc with the two commits preserved. The tested and merged trees match, and the frozen package still validates. See experiments/2026-10-09-comparison-preparation/completion.json. Spending approval remains pending.


## S-016 — October 10, 2026 — exploratory pilot approved (founder decision)

Founder explicitly says “cool I approve the exploratory pilot” in response to the concrete 228-call/no-retry/₹943.38-ceiling proposal. This authorizes one unchanged package acf3956980d4acdc4cc8b740aaff6e4dd1f1908f310d98ed247ca2b2ef178b0c at the disclosed assistant-reviewed exploratory level. Saved approval.json binds the exact package, budget, attempt count and output directory. This supersedes S-015's pending-approval status only. No automatic second run, fallback, changed scope or additional paid probe. Do not ask for the same approval again. Execution awaits key save in the designated private file; zero calls so far. Evidence: experiments/2026-10-10-pilot-authorization/.

## S-017 — October 10, 2026 — per-turn documentation required (founder decision)

Every Sarvam working turn must leave an append-only running-note/daily entry with actual progress, passes, failures, evidence, uncertainties, spending and next action. Maintain CURRENT_STATE.md as the compact current snapshot; log important decisions here and keep a dedicated report and raw evidence per experiment. Record failed and superseded approaches, not just positive outcomes. Store no API keys, passwords or OTPs in logs. Update necessary documents as facts change without rewriting immutable prior evidence. RUNNING_NOTES.md is now the chronological entry point alongside the existing memory. No unattended automation or guaranteed recall outside loaded memory is implied.


## S-018 — October 10, 2026 — preserve first pilot's configuration failure

Executed exactly one approved call, then stopped at the declared failure boundary. Low reasoning used 4,095 of 4,096 completion tokens and returned no final content. Zero accepted extractions or answers; no accuracy or architecture result. Preserve the error and raw receipt and count its usage. Current rates are lower than frozen rates; report both estimates, not the reservation as spending. Do not silently retry, parse reasoning as an answer, enlarge the cap or change the model. Evidence: experiments/2026-10-10-pilot-001/RESULTS.md. This supersedes S-016's awaiting-key/execution-pending state. The original approval remains recorded, but the stopped run cannot resume with changed settings.

## S-019 — October 10, 2026 — one-field follow-up prepared, proposed only

Official docs say JSON null disables optional reasoning. Prepared one identical D01-en extraction with only reasoning_effort changed from low to null: maximum one call, no retries, ₹4.14 displayed reservation ceiling. Probe hash: fa59041f381a10f971fe2afb361106e81482339519b47fc48c45519e4d2fc04f. No paid request or user approval exists for this changed configuration yet. A successful result must contain completed valid final JSON and a faithful source-grounded fact, not just an empty structure. It would not establish full-pilot readiness, memory accuracy or a product gap. Keep this distinct from the failed parent, preserve model and prompt, and request concrete approval after preparation/publication is complete.

S-018 publication verified: evidence commit 6ba5c8b merged through PR #45 at 43050da; exact-head and main CI both passed. Original failure and pending S-019 proposal remain unchanged. No paid follow-up has occurred.


## S-020 — October 10 — one diagnostic approved and consumed

Founder explicitly approved S-019's exact probe, superseding its unapproved status. Approval bound fa59041f381a10f971fe2afb361106e81482339519b47fc48c45519e4d2fc04f, one call/no retries/₹4.14 displayed ceiling. Executed once; completed final extraction with zero reported reasoning tokens. Original request, source/prompt/model/output cap unchanged except null reasoning. Preserve parent error; no broader or repeated paid execution follows. Evidence: thinking-off-probe/approval.json, live-run/checkpoint.json and RESULTS.md.

## S-021 — October 10 — distinguish protocol success from useful memory

The call preserved source meaning but echoed six metadata fields and one raw sentence. Schema success is not a compact-fact or final-answer gain. Retain actual extraction; do not replace it with hand-authored facts. Next prepare a smaller null-reasoning ordinary-control comparison with frozen prompts/model and all-stage cost accounting; inspect extraction semantics and answers separately. A later compact-extraction prompt is a separate intervention. This next comparison is not prepared or paid-authorized yet. Novel product requirements remain dependent on reproducible consequential failures under strong existing controls.


Final verification: exact-merge main CI 38109017501 passed on 366c239. PR #46 and main checks both pass; evidence commit 95e40c8 preserved. Reports, findings, decisions, runbook and running memory updated. Original and diagnostic raw evidence remain intact. Exactly one new paid call, no retry or automatic follow-up; zero scored answers. See thinking-off-probe/completion.json. No active paid process or allowance remains. The next 72-call comparison is a design proposal only, awaiting versioned implementation/offline checks/freeze and its own approval. CI emitted existing action-runtime/Ubuntu-image maintenance notices; they did not fail tests and no unrelated workflow change was made.


## S-022 — October 11 — separately versioned small comparison

Founder authorizes preparation and asks for plain-language findings. Implemented 72-call fixed subset (D01/D06/D07/D09×EN/HI/TE×2) with explicit null reasoning and unchanged model/prompts/fixtures/labels. Original frozen runtime/evidence stay unchanged; v2 reuses provider/parsers/storage/grades and versions only orchestration. Every extraction is fresh; no free reuse of the earlier probe. Equal originals, extra SQL extraction compute disclosed.84offline tests and clean-export reproduction pass; no live accuracy claim. Evidence: small-comparison-preparation/RESULTS.md.

## S-023 — October 11 — concrete next paid scope remains unapproved

Package 07cb99155472ad97d49234351870726f8df314c6c5a51b6db1212b8ecae84744,72 calls maximum/no retries/₹297.91 displayed conservative ceiling; approval template false. General encouragement to proceed with preparation does not reuse the consumed diagnostic approval. Ask exact scoped approval only after publication/checks finish. Semantic fact review remains separate from exact-field scoring. Product requirements follow measured failures under strong controls; simple success is a valid outcome.


Final verification: exact-merge main CI 38110861412 passed on 50d4847. PR #47 and main CI both pass; independent commits e79bb5f/0af26a1 preserved. Preparation/publication is complete. Frozen package and all prior evidence remain valid; 84 focused tests and complete offline simulation are software evidence only. No new paid call or credential read. The exact 72-call/no-retry/₹297.91-reservation package remains unapproved; ask only this concrete scope. Completion: experiments/2026-10-10-small-comparison-preparation/completion.json.


## S-024 — October 11 — exact small comparison approved

Founder authorizes one package07cb99155472ad97d49234351870726f8df314c6c5a51b6db1212b8ecae84744, at most72calls, no retries, frozen reservation₹297.90830592 within stated₹297.91. Approval accepts the disclosed assistant-reviewed developmental scope; no stronger model, prompt rewrite, second run or full228continuation. This supersedes S-023 pending approval only. Exact approval is saved beside the package; do not ask again for this scope. Outcome remains pending.


## S-025 — October 11 — preserve the first-call schema failure

S-024's approval was executed once and terminated at the declared first-failure boundary. No remaining scheduled call is permission to resume after error. Preserve invalid facts, receipt, schema, prompt and usage; report zero accepted extractions/answers and undefined accuracy. Do not hand-correct a timestamp, change frozen parsing, count a metadata copy as a semantic gain, or infer a model-wide failure rate. Evidence: experiments/2026-10-11-small-comparison-001/RESULTS.md and diagnosis.json.

## S-026 — October 11 — repair extraction admission before more paid comparison

The current V1 documentation advertises strict JSON schema mode; the frozen request used JSON-object mode. A new contract may use schema constraints and explicit source-metadata/semantic-fact separation, with independent local checks. Keep original evidence when generated augmentation is rejected, label the rejection/cost, and measure the independent control under a prospectively revised protocol. Format success cannot guarantee grounded dates or status. The exact-source empty-fact path has only been checked offline; no runtime fallback is implemented. NEXT_TASK.md specifies tests and version boundaries. This is engineering planning under the authorized project scope, not another paid authorization or proof of a novel memory product.


Final verification: PR #48 and exact-merge main CI 38112536449 both passed. Merge b0f9a36 preserves independent evidence/replay commits 889e17b and ed2683e. Tested and merged trees match; all ten public/local artifacts match; new and historical frozen packages validate. Current failed checkpoint and prior probe/original evidence remain unchanged. Founder local changes and English CURRENT_STATE preserved. Outcome: one paid extraction attempt, zero accepted extractions/answers, zero retries, 71 unattempted calls; current-rate estimate ₹0.02307. No further paid process/allowance. Reports, findings, decisions, runbook, daily and running memory are current. Next task remains offline extraction admission/strict-schema preparation and a new prospective control protocol; no live fix or new paid package is claimed. Final receipt: experiments/2026-10-11-small-comparison-001/completion.json.


## S-027 — October 11 — source-preserving admission implemented prospectively

Founder authorizes continuing the next offline engineering task. Separate v3 implements S-026 without changing prior source/checkpoints: immutable source metadata, documented schema-mode extraction, local structural admission, explicit rejected augmentation plus original-evidence answer path, and invalid-answer counting. Infrastructure/accounting failures still stop. Counterbalanced control is independent of valid extraction. No retry, model replacement or silent data repair. Scope/cutoff filters run before persisted originals; generated facts cannot set scope. Reserved slots and actual dispatch-start flags are reported separately.

138 tests and separate mixed/clean-export audits pass. Structurally valid false facts still pass admission with semantic review UNREVIEWED; no entailment guarantee. Models/answer prompts fixed, extraction/projection/schema/policy change together, extra SQL compute counted. This is a harness repair, not proven accuracy or a production architecture promotion. Evidence: experiments/2026-10-11-extraction-admission-v3/.

## S-028 — October 11 — new exact paid proposal prepared, not authorized

New package bf04d07dbe2a9b2fe2e77be5ce08cdc19eed511de6af2af075cf182ef5fa0b65 binds 72 maximum calls, no retries, reservation ₹297.90830592 (display ceiling ₹297.91), same 12 development renderings/2 repeats/fixed 105B. It prospectively continues after completed known-usage extraction rejection or malformed answer, retaining failures/costs/denominators; transport/schema API/receipt/usage/persistence failure still stops. First schema request is part of schedule, after first full-history answer. Old approvals are closed and do not authorize changed policy. Approval template false; exact live keyword support untested. Finish publication/CI/merge, then ask approval of only this reviewable scope. No paid call or key read this turn.


Final verification COMPLETE: PR #49 and exact-merge main CI 38114219361 passed on 3ecbe75. Commits 045f255/acbc4de retained; tested/merged trees, public hashes, historical sources/checkpoints and all three frozen packages verify. Both checkouts are at the merge; founder dirty files and English CURRENT_STATE preserved. Offline work is complete: 138 tests, mixed simulation and clean-export audit passed. No paid call, credential read, live directory or accuracy gain. New package bf04d07dbe2a9b2fe2e77be5ce08cdc19eed511de6af2af075cf182ef5fa0b65 remains unapproved. Next ask only one 72-call/no-retry/₹297.91 conservative-reservation comparison with its explicit rejected-extraction/invalid-answer policy; inspect actual semantics and answer gains/losses afterward. See completion.json.


## S-029 — October 11 — five bounded runs authorized

Founder explicitly approves the next five runs. Supersedes S-028 pending approval for the exact first v3 package; follow-ups selected prospectively from evidence. At most five run slots, 72 calls each, 360 total, no retries, fixed105B/null/4096; aggregate conservative reservation ₹1,489.54152960 (display₹1,489.55). Stopped runs consume a slot and retain reservations; never resume historical errors. Preserve all results; replicate gains, do not select only a favorable outcome. Credits are not an extra allowance. See experiments/2026-10-11-five-run-campaign/authorization.json and PLAN.md. Exact first approval saved under run-001.


## S-030 — October11 — versioned compatibility repair after run001

Run001 stopped at extraction HTTP500/upstream400 unsupported uniqueItems after one completed control answer. Two dispatched calls, one unknown usage, full reservations retained. No score and no retry. Second campaign slot is a new v4 package removing only provider uniqueItems while shared local validator still rejects duplicate citations. No model/prompt/data/score changes. Unknown first error usage does not become zero; reserved amount retained under aggregate bound. V4 is a prospective compatibility profile, not a silent fallback inside stopped v3.


## S-031 — October11 — explicit contract transport experiment

Run002 v4 stopped at call26 on known-usage length-truncated extraction; no retry or headline score. Schema accepted earlier calls, but one malformed repetition reached4096output with0reasoning. Candidate cause is contract/decoder interaction, not established fact. Run003 v5 uses documented JSON-object mode and the exact v4 schema as additional prompt text; shared local validators and all answer/model/data/settings/stop/budget controls unchanged. This declared transport/prompt experiment uses third approved slot. Preserve invalid D01-hi answer-field substitution and every failure.


## S-032 — October11 — replicate the first complete small signal

Run003 completed72calls. Memory24/24 vscontrol23/24,1win/0loss; answer+requiredsources19/24vs17/24. Two rejected extractions,0invalidanswers,allusageknown. This is oneextra correct answer on correlated development data, with extra memorycompute. Actual fact review finds unsupported observation-derived validitydates, so no trustworthy-memory/product claim. Run004 is exact unchanged replication under fourth slot; do not stop on lucky positive.


## S-033 — October11 — no replicated accuracy gain; last slot tests date admission

Run004 control24/24vsSQLite23/24 reverses run003; pooled47/48each. Reject the claim of an accuracy improvement. One wrong affirmative call authorization follows semantically false approval augmentation. Bothrunsalsoadmit unsupported validitydates. V6 finalslot uses identical extraction/answer requests/settings/data; changes local whole-set admission only: every nonnull validitydate must occur literally in a cited authorized original text. No observation/query/generated/uncited witness. Retain original evidence onrejection and allcost. Conservative derived/spelled-date false rejections are explicit. This cannot prove entailment and does not block the observed wrong-condition fact; test documents the limit. Never describe dategateasallsemanticgapsfixed.


## S-034 — October 11 — close five-run allowance without claiming a breakthrough

Five slots used: 244 calls, zero retries. Runs001/002 stopped;003/004 accuracy advantage reversed (47/48 each);005 tied24/24 with four additional date-witness rejections and three structural rejections. Secondary required-source coverage23/24vs17/24 in005 needs independent confirmation. Literal-date filtering is a demonstrated admission improvement, not full semantic support. No remaining paid slot, no sixth call series under this authorization. Known estimate₹4.10268 plus one unknown-usage HTTP500; retained reservation₹1,009.57814784.

Keep all losses, raw receipts and counterexamples. Next engineering priority is source-event/state semantics with separate modality, outcome and time roles, tested against ordinary controls. No model upgrade, production promotion, English score change or novelty claim. Full report and prospective acceptance criteria in five-run-campaign/. Publication/main verification pending.


Final verification COMPLETE: PR50 merged atb09f79e. Exact-head PR CI38146364011 and exact-merge main CI38146609603 passed. Four independent commits123c0df/8ec9950/4ecfc3c/3096685 preserved; tested/merged trees equal. 164focused tests and clean Git export evidence replay pass (5runs,80stores,244unique receipts,0replaynetworkcalls). All5authorized slots consumed,244paidcalls,0retries,1unknownusageerror,knownusageestimate₹4.10268. No replicated answergain:003+004 both47/48;005both24/24. Dateguardblocks4additionalsets; semanticcondition/status flaws remain. Founder dirt and rootEnglishstate preserved, Sarvamworktreeclean. Next is offline source-event/state design and tests; no sixth paidrun. Completionreceipt:experiments/2026-10-11-five-run-campaign/completion.json.


## S-035 — native capability discovery before memory architecture

Founder explicitly redirects work to native Sarvam model/API evidence first, with an INR6,000 investigation ceiling and assessment before execution. Supersedes the next source-event/state memory implementation. No live call this turn. Prepare a larger reviewed, grouped and metered study with ordinary controls; select architecture only after a reproducible, relevant gap survives simple fixes and fresh confirmation. Details: research/2026-10-11-evidence-first-reset/ASSESSMENT_AND_STUDY.md. Historical runs and their no-replicated-gain finding remain unchanged.


## S-036 — execute evidence-first native study under approved ceiling

Founder approves the proposed native capability investigation. Setup12calls passed; launch frozen490-rendering discovery with two105Bvariants and two ordinary controls. No AgentMem architecture. Detailed scope/caps, true template limitations, grouped split and scorer are frozen in native-study/PROTOCOL.md. Budget is reserved before dispatch and settled with25%headroom for known usage; unknowns retain worst-case reservations. Old five-run allowance remains historical. No guaranteed novelty or score improvement.


## S-037 — retain rate-limit failures; pace unattempted continuation

Original discovery stops on5HTTP429 at816episodes. Add35RPMsharedpacing and a separately frozen continuation of only1144unattempted episodes; never retry the five failed episodes. This preserves model/config/data and changes dispatch scheduling only. A later founder-confirmed rate change must be logged. The frozen matched8192cap null/low reasoning diagnostic remains a separate264episode stage. All within approved6000INR; no new blanket approval needed. See native-study/PACING_AND_CONTINUATION.md.


S-038: Start unchanged frozen confirmation concurrently with the remaining discovery/attribution after source review. This timing overlap is explicitly recorded before confirmation outputs; no candidate/settings selected using diagnostic results. Original null4096,210reservedrenderings,840episodes,shared90RPM,1500INRstage within6000INRtotal. No new model or memory architecture. See confirmation-start-decision.json.


S-039: Matched-cap reasoning diagnostic completed264episodes/426calls,0errors/retries,knownestimateINR9.61089. Base105B full-history14→20/33(10gains/4losses),SQLite15→15(5/5);conversations15→15botharms. Selected failure-enriched33renderings/10bases,notgeneralaccuracy. All31base-low misses inspected:20format/contract-primary,11substantiveoutputmismatches; frozen grades unchanged. Base-low realbackendcorrect66/66inthissample. Conversations reasoning usage details absent,notreportedzero; cannotproveinternalreasoningactive. Network-blocked replay passes. No universalreasoningfix,architecturegainornoveltyclaim. Main discovery/confirmation continue. See native-study/attribution/REPORT.md and assistant-failure-review.json.


S-040 — input-level overlap audit corrects the stronger confirmation wording. Hashing complete visible requests finds637distinct inputs across700rows,182distinctEnglishinputs across200Englishrows. Discovery451unique/490;confirmation192unique/210,with6visibleinputs also in discovery (conditional05/17 and06/18 in EN/HI/TE). Thus186distinct confirmation inputs are absent from discovery. Sources: parameterized conditional repeats and action_update/action_retry overlapping odd-index cases. Group-ID separation did not eliminate semantic/byte-identical overlap. Earlier descriptions of all210being unseen are superseded. Preserve frozen scores/outputs; add output-independent lexicographic de-duplication sensitivity and exclude discovery-overlapping inputs only in that separate view. No quiet data replacement or paid rerun. This remains a synthetic diagnostic; stronger independent-holdout/700unique-workflow claims are invalid. Report data design weakness candidly. Audit: native-study/input-duplication-audit.json.


## S-041 — native study complete; no premature memory-product conclusion

All frozen phases completed: 2,800 main + 264 diagnostic episodes, 4,928 calls including setup, zero retries, five original429s and no new errors after pacing. Main discovery strict successes: base full312/490, base SQL298/490, conversations full317/490, conversations SQL300/490; reserved confirmation127/210,126/210,127/210,126/210 respectively. De-duplicated confirmation is117/186 for each full-context model and114/186 for each SQL model. These are custom strict synthetic scores, not general/model/English benchmark accuracy.

Conversations SQL maintains correct state in140/140mainactioncases, while answer failures remain. Base105B has17forbidden update attempts across main episodes; the earlier five source-reviewed examples and fresh English conditional checks substantiate the failure class, not independent native quality. Matched diagnostic full-base14→20/33; other cells no net gain. No memory architecture was built or shown superior. Test strong ordinary structured-output/current-state/authorization controls next, then fresh diverse reviewed cases; product choice stays open.

Known estimate INR58.280115; accounting with25%headroom/fullunknown reservations INR86.675931. 18focusedtests pass; clean Git export verifies19,693archivefiles, all3,064taskepisodes and4,928calls with zero inference/credential access. Credential scan passed; private account report excluded. Nine independent commits through a21e57f are prepared/pushed for PR51; final CI/merge pending. No inference remains active; rootEnglishstate and founder dirt preserved. Complete result: native-study/REPORT.md; clean-export-verification.json.


## Final publication verification — COMPLETE

PR #51 merged nine independent commits at cbc1712e80f8f313943383e75e85c9ebfcd77bbd. Exact-head PR CI38159779805 and exact-merge main CI38160189778 both passed. Tested/merged trees match; localmain=origin/main and Sarvamworktree clean. Founder .gitignore change, two benchmark files and website remain untouched. Initial HTTP400 upload error was resolved via ordinary non-force push using per-command HTTP settings; no persistent Git config or evidence changed.

All 2,800 main +264 diagnostic episodes and4,928APIrequests accounted for;5original429s preserved,0retries,0furthererrorsafterpacing,0inferenceprocessesremaining. Known estimate INR58.280115; retained accounting INR86.675931. 18focusedtests, fullCI and clean-export replay pass. 19,693publicfiles hash-verified; privateaccountobservations/keyexcluded. All summaries preserve637unique-input/700rowlimit,6cross-splitrepeats andlackofindependentnativevalidation. No newmemoryarchitecture, generalaccuracyorindustrynoveltyclaim. Outcome/nextcontrols in native-study/REPORT.md andFOLLOWUP_CRITERIA.md; finalreceipt completion.json.


## S-042 — next ordinary response-format control authorized and prepared
Founder requests next phase and a simple recap. Starting single-lever schema control before state/permission changes:24synthetic workflows/72EN-HI-TErenderings,288episodes, fixed per-model settings and matched caps; no independent native review. Excluded6episode/12call compatibility gate must pass first. New phase retained cap INR350 carries prior INR86.675931 inside INR6000; shared90RPM/no retries. Fresh wording has no exact duplicates; known failure-family ancestry remains. Existing results and English state preserved. Protocol and assistant review: experiments/2026-10-11-structured-output-control/. No inference yet at preparation.


S-043: First strict-schema compatibility gate FAILS:6validJSON/6responses but only2/6task successes. Base105Bclaimedconfirmedwithouttool;Conversationsmade no update; bothunknown-addressresponseswrong. Comparison288episodesclosedunattempted. To distinguish interface effects from general failures, freeze a separate12episode/24callmatched control-versus-schema attribution on the3excludedcases before calls. Original6unchanged; no automaticretry or broadpromotion. NewINR80capcarries priorINR86.829044 insideINR6000.


## S-044 — combined strict-schema/action control rejected with matched evidence
20newcalls/18excludedepisodes complete;0errors/retries. Initialschema6/6valid,2/6tasks. Matched6pairs:control4/6valid,1/6tasks;schema6/6valid,2/6tasks, but actualactionupdatescontrol2/2 vs schema0/2. Same1Teluguactioncase×2models, not an accuracybenchmark or universalAPIbug. Missing-address misses are contract/clarification ambiguity, not fabricatedaddresses; preservegradesandnarrowclaim.288plannedepisodesclosedunattempted; gate-block verifiedbeforekeyread.25focusedtests and offlineallreceipt/state/ledgerreplaypass. KnownnewINR0.406440,retainedINR0.508053; researchcumulativeknown58.686555/retained87.183984. Nextseparateactionphasefromfinalschema,thenauthoritativestate/approval; no memoryarchitectureorEnglishscorechange. Report: experiments/2026-10-11-structured-output-control/REPORT.md. Publication/CIpending.


## Final publication verification — complete
PR52 merged code9d09819 and evidence de01c08 at1ae8d89. Exact-head PR CI38163453705 and exact-merge main CI38163801405 both passed. Tested and merged trees match; both local worktrees equal origin/main. All154public artifact hashes and full offline replay verify; archive SHA2566859f8b783800549f5cf3cd6c26d6534c02c90be2ffa30e8793a459603a2cbc8. Founder dirt, English memory ownership and historical native receipts are preserved.

Candidate remains rejected despite completed engineering/publication.20newcalls/18excludedepisodes, zero API errors or retries;288plannedepisodes never started. Known new estimate INR0.406440; cumulative research retained INR87.183984. No inference process remains. The matched action result is one Telugu situation across two models, not general accuracy. The next planned control separates execution and final formatting and defines missing-information contracts explicitly. Nothing further is needed from the founder for offline preparation within the standing scope. See completion.json and post-merge-ci.json; these supersede earlier pending publication notes only.


## S-045 — separated execution/final formatting frozen before calls
Founder requests continuation. New phase uses shared real native-tool prefixes and two non-executable final formats; onlyresponse_format differs within final pairs. Same fixed models/profiles and8192caps; explicit unknown-value policy in both arms. Excluded7situations×2models must pass14/14candidate tasks before72input/288answer comparison. PhasecapINR500 carries priorretainedINR87.183984 withinINR6000. No historicalrerun,regrading or memory engine.31focusedchecks pass; comparison will distinguish format admission from gains with both outputs already valid. Shared trajectories cannot prove independent action-policy improvement. Source/labels/protocol/budget frozen before inference.


## S-046 — separated setup stopped; distinguish integration, policy and rubric failures
22requests:16successful replies and6HTTP400s. Native history requires tool definitions even during finalization; this is our integration error, not model accuracy. Stop preserved after8/14pairs;288answer comparison closed unattempted. Base105B performed a real isolated SQLite update despite pending approval before its final400. Conversations correctly refused a denied change but strict status not_requested versus not_performed is ambiguous; preserve grade without calling it unsafe. Closed-case receipt requirement is artificial. One already-applied answer improved with schema; no broad gain. KnownnewINR0.602385;retained19.184985; cumulativeknown59.288940/retained106.368969,4970calls. Prospective4call transport-only check will retain definitions withtool_choice none on2saved successful native histories; no repeated actions, no old-manifest restart. Budget capINR20 carries actualretained; no architecture or novelty claim.


## S-047 — transport repair admits requests but full candidate remains failed
Separate4callswithoriginaldefinitions/tool_choice none produced4HTTP200/knownusage;Conversationscorrect2/2,base105Bemptycontent2/2(stop,32completion/31reasoningtokens). No new actions,sourceDBsunchanged. HTTPadmissionfixedinthisdiagnostic; finalanswercompatibilitynotfixed. Originalfailedgateand288answersstayclosed. Allcurrent26calls preserved:knownINR0.658995,retained19.255748; cumulative4974calls,known59.345550,retained106.439732. No generalgain/noveltyclaim. Nextsourcepreservingno-toolsfinalization,ordinaryserverapprovalandclearerprospectivestatuscontracts;noarchitectureyet.37focusedtests andofflinebothreplayspass; publicationpending. See separated-finalization/REPORT.md andNEXT_PHASE.md.


## Final publication verification — separated finalization complete
PR53 merged three independent commits b73e659,ee89633,f0edbb1 at846a487. Exact-head PR CI38166978427 and exact-merge main CI38167323908 both passed.37focusedtests and clean-export replay pass; all190artifact hashes verify, archiveSHA256 d46971387dc11b8ceeb394e11e31b65d9866c081c20411e61ef142445e40d238. Tested/mergedtreesmatch,bothworktreesequalorigin/main,Sarvamclean,andall6992founderfiles/statuspreserved. No inference remains from either completed process.

Research outcome stays failed:26calls,6originalHTTP400s,0retries,288plannedanswersunattempted. NewknownINR0.658995;cumknown59.345550/retained106.439732,4974calls. Repairadmits4requestsbutbaseempty2/2;Conversationscorrect2/2. Pendingapprovalwriteandgradingambiguitiespreserved. No broadgain,memoryarchitectureorindustrynoveltyclaim. Nextsourcepreservingno-toolsfinalizationandordinaryapprovalcontrols; APPROVAL_CONTRACT_DRAFT.md has12contrastsbutisnotimplemented. No newkey/blanketapprovalneededforofflinepreparation. completion.json/post-merge-ci.json supersede pendingpublicationnotesonly.


## S-048 — transcript finalization and ordinary permission work begins
Founder requests continuation and positive measured progress. Freeze two separate deliverables before results: lossless transcript-only finalizer with a bounded4call format diagnostic (same fixed models/profiles;INR20cap;priorretained106.439732) and an ordinary SQLite approval backend with positive/negative/concurrency checks. No large comparison or memory architecture this phase. Historical failed manifests remain closed. See experiments/2026-10-11-transcript-approval-control/PLAN.md. New observations will be logged, not converted into promised gains.


## S-049 — transcript compatibility positive, narrow result
Newlosslesstranscriptfinalizercompleted4/4correctrawJSONanswers,allHTTP200/knownusage,0toolrequests/retries. Base105Blow nowanswersbothformatscorrectlywherepriornative-historypathreturnedempty;Conversations2/2stillcorrect. Same original histories/models/caps, changed representation/reporting instructions; not a clean causal comparison or a new end-to-end score. Frozen native histories/expectedvalues/sourceDBsunchanged; offline replaypasses. NewknownINR0.346440,retained0.433053;researchcum4978calls,known59.691990/retained106.872785. No furtherpaidcallsplannedthisphase. Approvalbackendimplementation/testsinprogress. Source c13acfb pushed.


## S-050 — ordinary approval backend verified offline
22 frozen cases×2enforcementarms=44actualSQLite variants pass.14permission contrasts plus1observed-pending reconstruction write under unenforcedcontrol and are allblocked byserverguard.3legitimate firstwritespreserved;duplicate/conflicting-key,closed/stale,identity/readchecksallpass.34backendtests include8-wayconcurrency andtransactionrollback;75totalfocusedtests/Ruffpass. Counterfactualpendingreconstructionaddssyntheticserverapprovalmetadata;notnewmodelbehaviororexactoldpipeline. Serverguardisstandardengineering,notmemorynovelty. Backendcodef8e0dc3 committed/pushed;publicationpending.

Compute review: same8192cap butbase105Btranscriptanswersconsume2990/1700completiontokens(2960/1670reasoning) and13.48/8.98seconds versus oldempty32tokenoutputs. Conversations41/40completiontokens remainsabout1second. No equal-actual-compute or schemaaccuracyadvantageclaim. Initialreportinghelperencounterednullusage-detailsmetadata;fixedreaderpreservesunknownreasoningcounts, noAPIretryoroutputchange. Nextintegrateaction/guard/finalizerandreviewfreshcasesbeforelargercomparison;historicalfailedmanifestsstayclosed.


## S-051 — transcript/approval publication and verification complete
PR54 merged c13acfb,f8e0dc3,0179d08 at6bc8cc7. Exact-head PR CI38176909878 and exact-merge main CI38177228115 passed.75focusedtests,Ruff/diff and clean-export replaypass;113artifacthashesverify,archiveSHA2563e156ed35169369b5eaf253e20310ac42aab6d54759e6b480681cc2211051eff. Tested/mergedtreesmatch;bothworktreesmatchorigin/main,Sarvamclean;all6992founderfiles/statusandEnglishCURRENT_STATEhashpreserved. No inference remains active.

Scopedpositive results:4/4livefinalanswersontwosavedhistories;44/44offlineSQLitevariantsacross22cases,15deliberatelyunapprovedwritesblockedand3legitimatefirstwritespreserved. Model/profilesunchanged;basemodelconsumesmoreactualreasoning/latency. No broaderaccuracyscore,integratedbaseline,productionauth,memoryadvantageornoveltyclaim. NewknownINR0.346440;cum4978calls,known59.691990/retained106.872785. Nextintegratedaction/guard/finalizationinclread/refusal/errorpathsandfreshreviewedbank;oldpaidmanifestsclosed. completion.json/post-merge-ci.json supersedependingpublicationnotes.


## S-052 — integrated ordinary baseline setup begins

The founder requests continuation under the existing INR 6,000 native research ceiling. Freeze six situations × two models × two server-enforcement arms, at most 96 calls and INR 220 retained accounting. Models/profiles/caps are unchanged. Initial source evidence and tools match across arms; only the backend approval flag differs. Reporting semantics are prospective; historical grades stay unchanged. Test approved, blocked, read-only, refusal, duplicate, malformed and rollback paths. The setup gate requires complete truthful reports and guarded desired state including useful approved writes. Report attempted violations separately. No larger comparison starts in this phase. See the frozen protocol in `experiments/2026-10-11-integrated-ordinary-control/PROTOCOL.md`.


## S-053 — integrated execution works; reporting gate fails; status corrected offline

All 24 episodes completed in 61 new calls, with no errors or retries. All 24 current dates and stored states are correct; all four approved new writes succeed. No prohibited change or false confirmation. Raw correct reports: 21/24; strict tasks: 19/24. Three failures are status-label distinctions; two are unnecessary closed-booking attempts, safely blocked. No pending or revoked change was attempted, so this live sample does not demonstrate a guard advantage. The frozen gate remains false and the larger comparison is unstarted.

A separate post-hoc receipt-owned status candidate changes exactly three fields: 24/24 correct application reports and 22/24 strict tasks on the same saved histories. Both unnecessary attempts remain. Zero new API calls; raw answers, original scores and failed gate are preserved. This is ordinary execution-metadata ownership, not model improvement or a novel memory design. The six synthetic situations provide current server state and have no independent native review.

113 focused tests pass. Full live request/state/usage replay and clean-export verification pass for all 277 public artifact files. New known estimate INR 3.364035, retained INR 4.205069; native cumulative 5,039 calls, known INR 63.056025, retained INR 111.077854. Commits c26268a, 7f66dc7 and 3f7ac1f are pushed through PR55; CI/merge pending. No inference remains. See the integrated experiment REPORT.md, verification.json and receipt-projection.json. Publication completion will be recorded separately.


## S-054 — integrated study publication and verification complete

PR55 merged all three independent commits c26268a, 7f66dc7 and 3f7ac1f at fa648204cddaaeb8014b81b843af398af684ac75. Exact-head PR CI38181120756 and exact-merge main CI38181374436 passed. All 113 focused tests and clean-export replay passed; 277 artifact files verify, archive SHA2560540146b2f12186b4a163f2fc13f4a72110c157b3a2c1ce562e341df1307c14a. Both local worktrees equal origin/main; tested and merged trees match. All 6,992 founder files/status and root English CURRENT_STATE are preserved.

Research conclusion remains mixed: all 24 dates/states and all four approved new writes correct, but raw reports 21/24 and strict tasks 19/24. Three status mismatches plus two unnecessary closed attempts remain in the original evidence. The offline receipt-status candidate gives 24/24 application reports and 22/24 strict tasks on the same histories, with no new calls or fresh model-gain claim. Original gate stays false; larger comparison unstarted. Native research cumulative 5,039 calls, known INR 63.056025, retained INR 111.077854. No inference is active. completion.json and post-merge-ci.json supersede earlier pending publication notes only.

Next: version the application-owned status contract, then prepare the larger source/currentness challenge bank and prospective integration gate. This phase does not establish a memory need, novelty or general multilingual accuracy. No further founder action is needed for that authorized engineering preparation.


## S-055 — receipt-owned live integration and source challenge preparation

Founder requests the next planned step. New version connects the existing receipt-status projector after finalization while preserving raw answers. It also removes the current-date-only reporting instruction so questions can ask about requested dates. Models, ordinary SQLite backend and caps stay fixed. The72rendering bank contains24related scenarios in8families; no independent/native/holdout claim. Preflight removed a contradictory unused approval in readonly fixtures before any call. Scope this turn:12episode guarded integration check, then prepare288comparison episodes only if its prospectively frozen gate passes. No larger paid execution this turn. Existing INR6000 authorization remains; capINR110 for setup, future comparison capINR2590, phaseINR2700. Prior native carry5039calls/known63.056025/retained111.077854. Historical failed gates remain unchanged.


## S-056 — receipt-owned live integration passes; larger comparison prepared

New12episode check completes30calls: application reports/state12/12, useful approved writes2/2, strict tasks11/12. Raw model reports8/12; four status mismatches corrected at runtime without changing dates or clarification. One unnecessary closed-booking attempt remains, safely rejected. Zero provider/backend errors, unknown usage or retries. New prospective application gate passes; original PR55 raw gate remains false. This is application integration evidence, not improved model reasoning or a new memory score.

Prepared/frozen288comparison episodes from72distinct EN/HI/TEinputs:24related scenario instances in8known families. Thirty of45read-only questions require more than copying current date; six additional renderings require new writes. No exact question/source repeats against prior native bank; shared semantic ancestry/translation correlation and lack of independent native review disclosed. Comparison is unstarted. Scope is ordinary storage/source interpretation, with server snapshots and supplied action arguments; no extraction, long-context, voice or memory claim.

123tests/Ruff/diff and full live offline request/SQLite/projection/meter replay pass. NewknownINR2.990055,retained3.737582;native cumulative5069calls,known66.046080,retained114.815436. Implementation89ed359 is committed/pushed; publication/CI pending. No inference active. Next task:execute the frozen larger comparison once under the standing scope and inspect every miss. No duplicate key/budget approval needed. See ordinary-source-challenge/REPORT.md andcomparison/readiness.json.


## S-057 — distinguish desired task success from factual reporting before comparison

October 11, VERIFIED_COMPLETE preparation. Pre-publication review identified a metric attribution risk: if an unenforced backend permits a prohibited date change, truthfully reporting the actual new date is not a factual mistake, although the task is unsafe. Preserve the frozen primary desired-task grades and add a prospectively frozen evaluator supplement. It checks actual current-state truth for 42 questions and frozen request/condition truth for 30, alongside desired state, receipt status and prohibited effects. Runtime model inputs, raw answers, original labels and source remain unchanged. No larger-comparison output exists or was used.

Use `sarvam_source_attribution run ROOT`; it binds the supplement before the unchanged original runner's source/gate/key checks. The extra contract cannot be changed after execution for regrading. 129 focused tests pass; six supplemental tests include unsafe-but-truthful, safe-but-wrong and dispatch/restart protections. Two transient test-fixture failures (missing temporary comparison directory) were corrected without API calls. Commit ded9eb5 accompanies 89ed359. Comparison remains unstarted. See ATTRIBUTION_CONTRACT.md and comparison/readiness-v2.json. This supersedes the direct execution command in S-056/runbook, not any result or original grade.


## S-058 — ordinary source integration publication complete

October 11, VERIFIED_COMPLETE. PR56 preserves all three commits at `adcbe7560bb56140e73dfb20ad0a68ac5ac0ef1c`. Exact-head CI 38183884104 and main CI 38184154736 pass. 129 tests, 201 artifact hashes and clean-export replay verify. Both worktrees match origin/main and the tested tree; 6,992 founder files/status and the English current state are preserved. No additional paid calls were made during attribution, publication or verification.

The live setup remains 12/12 correct application reports/states, 8/12 raw reports, 11/12 strict tasks, two approved writes; historical gates and all raw failures are preserved. The supplementary factual-attribution contract is frozen before comparison outputs. Native cumulative 5,069 calls, known INR 66.046080, retained INR 114.815436. The 288-episode comparison is ready and unstarted. Next execute once through `sarvam_source_attribution run ROOT`, preserve the phase ledger, replay both grading views and inspect every miss. No new key or blanket approval is needed within the standing INR 6,000 scope. Completion supersedes publication-pending notes only; no larger result or novelty is asserted.


## S-059 — execute the frozen source comparison within the reconfirmed ceiling

Founder explicitly says to proceed and permits up to INR 6,000 API credits. Treat this as the existing total native-research ceiling, carrying 5,069 calls / known INR 66.046080 / retained INR 114.815436; do not add another INR 6,000. PR56 source and all 201 prepared artifact hashes verify, setup gate reproduces, both contracts bind, and 6,992 founder files/root English state remain unchanged. Execute the frozen 288 episodes once through the attribution wrapper, at most 1,152 calls, comparison cap INR 2,590, phase cap INR 2,700, four workers/shared 90 RPM, no retries or restart. No prompt/model/input/scoring edits. This supersedes the prior turn's preparation-only status. Comparison launch follows this preflight; results are not yet known. See experiments/2026-10-11-source-comparison-results/PLAN.md and authorization-and-preflight.json.


## S-060 — separate offline diagnosis from the ongoing native comparison

Added descriptive aggregation with paired/missing denominators, raw-versus-application reporting and absent-output-versus-false-statement separation. Nine targeted tests pass; the original 129 tests remain unchanged and an intermediate full 137-test suite passed before the final missing-answer test was added. A separate post-hoc backend replay executes exactly the observed tool calls with approval enforcement flipped, preserving caller/version/idempotency checks. Five tests cover premature approval, positive completion, duplicate/newer state and tampered receipts. It explicitly does not invent model responses after changed receipts and makes no new model-score claim. These new root-level analysis modules are not imported by the live runner; frozen runtime hashes remain unchanged. Commits cf034a8, 1d5a5ae and 57483c7 are preserved separately. Full combined/export validation follows execution. No additional paid probe is launched.


## S-061 — source comparison complete; diagnose reporting before memory

288episodes/723calls finish with zero API/backend errors, unknown usage or retries. Frozen primary, prospective attribution, SQLite/receipt/meter replay and independent aggregation pass. Conversations safe67/72off→69/72on,strict67both;base66/72off,57/72on. These are descriptive separate trajectories, not a broad accuracy or causal answer-gain claim. Four unsafe writes occur in Conversations/off; three live guarded attempts block;23/24legitimate writes complete. Offline same-call policy flips isolate seven enforcement-sensitive traces, preserving23actual approved writes; no model response is invented after changed receipts.

18empty basefinals(16token-cap,2stop/nullbelowcap) follow15correct native date answers and3successful writes. Six valid mismatches are separately reviewed; do not call them six fabricated dates.59statusfields corrected without answer changes;rawdesiredreports201→259application. All89flaggedepisodes/51renderedcases reviewed byassistant, not independent native reviewer. Shared templates/translation correlation, supplied state/arguments, frozenclock and awkward Hindi wording limit claims. Comparison gate_pass=false is a setup-only field, not a new comparison gate failure.

Next isolate only first-sentence finalizer wording, all144savedguardedhistories×control/candidate, fixedmodels/caps; preflight/freeze before any call. No extra paid diagnostic this turn. No memory architecture promoted. NewknownINR65.255115/retained81.569158;nativecarry5792calls/known131.301195/retained196.384594 within original6000.143focusedtests plus full audits pass; publication/export/CI pending. See source-comparison-results/REPORT.md, FAILURE_REVIEW.md and NEXT_PHASE.md.


## S-062 — source comparison publication complete

PR57 merged five independent commits at `1829cab4c1c19698e3b9649da56abe80e52c8568`. Exact PR CI 38188399170 and main CI 38188675356 passed. 143 focused tests and four clean-export audit reproductions pass; all3,083artifacthashes verify, archiveSHA256aaaa9dfbe79e8296d10465964ef82150f957a5e07d57c26526a08169f9e8075f. Both worktrees match origin/main and the tested tree. All6,992founderfiles/status and Englishcurrentstate are preserved. No inference active, no additional paid probe, no new memory architecture promoted.

Completed288episodes/723newcalls. Conversations safe67/72off,69/72on;strict67both. Base66off/57on.18emptybasefinals,6validanswermismatches,4unsafeunguardedwrites,1missedapprovedwrite and2additionalstrict-onlyattemptfailures remain recorded.59statusfields corrected byordinary receipt ownership.89flaggedepisodes/51renderings assistant-reviewed, independentnative review absent. Carry5792calls/knownINR131.301195/retained196.384594. Next one-variable finalizer-wording comparison proposed on allsavedguardedhistories, notstarted; fresh end-to-end confirmation required beforepromotion. Existing total6000authority persists; no duplicate blanketapproval/key needed. Completion supersedes publication-pending statements only.


## S-063 — execute the predeclared one-sentence reporter comparison

Founder asks to continue the next plan and explain the Sarvam history end to end. Preparing all144savedguardedhistories with fresh control/candidate,288calls max, same models/source/profiles/schema/caps; first sentence only changes. Existing INR6000total authority persists. Full-context conservative reservation calculatesINR619.3152; revised phasecap625 supersedes provisional300 before execution, cumulative maximum815.699794 including prior196.384594. No new blanket approval needed. Full parent288episode replay matches, all6992founderfiles/Englishstate preserved. No newmemory or answerrepair.11newtests pass after four lint-only wraps; complete288fixture simulation passes and rejects altered result. Offline simulation is not a model score. Live execution will begin only after focused tests/codecommit. History/report work proceeds during execution; no additional paid stage this turn.
