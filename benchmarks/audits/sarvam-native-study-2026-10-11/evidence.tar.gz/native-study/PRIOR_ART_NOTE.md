# Prior-art check during native investigation

Checking actual backend state and repeated task reliability is established methodology: tau-bench (Yao et al., 2024) describes database end-state evaluation and repeated-trial reliability. https://arxiv.org/abs/2406.12045 . Our SQL task checks are not claimed as a new invention.

Sarvam's own model release documents reasoning and agentic evaluation, including native and Romanized language styles: https://www.sarvam.ai/blogs/sarvam-30b-105b . Do not compare our custom synthetic percentages with its published benchmark scores or infer a failure unique to Sarvam. Its documentation rates/configuration were rechecked this turn.

Search also surfaced an Indic VoiceAgentBench OpenReview paper (https://openreview.net/pdf?id=mi9q49AR3d), but the full text was blocked by browser verification; not used to support a definitive novelty claim. No whole-internet or complete-prior-art claim.

Potential contribution remains a carefully reviewed, reproducible Indian-language failure corpus with configuration-sensitive diagnosis and real backend outcomes. Priority, real-user relevance and a beneficial new component are not established by this synthetic screen.
