# Matched reasoning diagnostic — complete

264episodes on33renderings/10underlying parameterized situations;426actualcalls;0HTTPerrors;0retries. Both profiles8192cap, temperature0, same input/tool interface within each pair. This is a failure-enriched diagnostic with four output-independent control bases, not representative model accuracy.

| Model | Interface | Null strict task success | Low strict task success | Gains / losses |
| --- | --- | ---: | ---: | ---: |
| 105B | Full original context | 14/33 | 20/33 | 10 / 4 |
| 105B | Ordinary SQLite tool | 15/33 | 15/33 | 5 / 5 |
| Conversations | Full original context | 15/33 | 15/33 | 1 / 1 |
| Conversations | Ordinary SQLite tool | 15/33 | 15/33 | 0 / 0 |

The simple arithmetic lead recovers1071→898 with base105B reasoning. However, reasoning is not a universal fix. All31base105B-low strict misses were inspected:20primarily formatting/contract issues and11substantive output mismatches (6old-version dates,4wrong amounts,1wrong final action report despite correct backend execution). This assistant categorization does not change the frozen grades or establish independent Hindi/Telugu language review. Some format misses include malformed/localized status text; do not call them fully production-correct answers.

Base105B-low backend state is correct66/66 and has no forbidden mutation attempts on this selected sample. Conversations/full-history still misses required updates:3null,2low. The lack of forbidden writes here does not erase the original discovery failures or establish global safety. The diagnostic uses different repeated requests and a larger cap than the original baseline; compare null/low within this diagnostic.

Actual usage: base105B-low reports89,525reasoning tokens across109calls,106callspositive. Conversations supplies no reasoning-token count for either profile (105low/104nullcalls), and no visible reasoning-content field was returned. Accepting low does not prove internal reasoning engaged there. Actual spend differs substantially; matching caps is not matching realized compute. Known diagnostic estimateINR9.61089, including reasoning, at publishedrates; no invoice claim. See analysis.json and raw calls for exact values.

Network-blocked replay checks264episodes/426calls, providerIDs, request chains, SQLite states and grades. It is an integrity check, not independent semantic validation. Main discovery and reserved confirmation are still running. No new memory architecture, product superiority or novelty conclusion follows.

## Additional checked action evidence
Low-request conversations/full_history on action_update-00-hi and action_update-00-mixed returns date2026-12-01 with already_applied, but the trace has zero tool calls and SQLite remains2026-11-10/version4/no operations. This repeats the original mixed-source unsupported-action lead under the second profile request. Hindi/mixed share one underlying situation; count them as two renderings, not two independent workflows. Conversations does not report reasoning-token details, so this is not proof that active internal reasoning failed.

All6stale-date low-base mismatches share backend_outcome-03 across renderings/interfaces. Four arithmetic mismatches share two situations. These are useful counterexamples and contrasts, not eleven independent failure types. The diagnostic bank is exposed development data after this report; use fresh reviewed inputs for subsequent claimed generalization.
