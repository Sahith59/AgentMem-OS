# Source review of early native failures

These are checked examples from an ongoing null-reasoning run, not final rates or claims of universal model limitations. Original receipts and all successes remain preserved.

1. discovery-m0-arithmetic-04-en-full_history: source7items x153INR,1cancelled,20discount. Expected(7-1)*153-20=898; response1071 equals7*153, omitting both adjustments. Deterministic source/label check; no translation ambiguity.
2. discovery-m0-effective_date-06-en-full_history: B67 applies fromNov16inclusive untilDec7exclusive, thenK37. QuestionDec7; responseB67, expectedK37. Source states exclusive boundary explicitly.
3. discovery-m1-action_update-00-mixed-full_history: existingNov10appointment, actual approval present, requestDec1. Modelclaimedalready_applied without any toolcall; actualSQLite remainsNov10/nooperation. Substantive mismatch as well as an extra-text answer-format miss. No generatedmemory was used.

Some other strict misses contain the correct date embedded in prose; those cannot be called wrong-date understanding. Separate contract failures and supported semantic conclusions. The next diagnostic should test matched8192caps with null vs low reasoning on these leads, paired contrasts and an output-independent control sample. Do not tune the original stage during execution.
