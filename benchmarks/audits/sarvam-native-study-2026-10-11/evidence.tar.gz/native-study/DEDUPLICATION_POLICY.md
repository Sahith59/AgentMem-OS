# Input-duplicate sensitivity policy — October11

This policy is recorded after the diagnostic and partial main outputs, before final main scoring. It is a post-discovery data-quality sensitivity, not the original primary measure. No outcome is used in the selection.

Hash the complete full-history request at fixed base105B with original records, question and available tool definitions. Cases differing only in evaluator identifiers or unexposed backend data may share visible inputs. Audit finds637distinct full-history inputs from700rows;451discovery,192confirmation,6overlap. English slice has182distinct inputs from200parameter rows. The SQL evidence exposed through read_records is the same; initial SQL request hashes alone cannot identify duplicates because records arrive in a later turn.

For discovery select the lexicographically smallest case_id per visible-input hash. For confirmation first remove every input hash found anywhere in discovery, then select the smallest case_id per remaining hash. Apply the same case selection across models and arms. Expect451discoveryrenderings and186confirmationrenderings per cell. Preserve all700rawcases/all2800primaryepisodes including errors; never select a successful member of a duplicate cluster. Even this de-duplicated view shares linguistic templates and is not an independent natural-workflow benchmark.

This corrects the earlier overly strong claim that all210reserved cases were unseen. The test labels remain interpretable; the defect is independence/diversity, not a reason to delete bad answers. Future benchmark versions must group by visible-input/semantic ancestry before splitting, and use new reviewed workflows rather than merely more parameter variants.
