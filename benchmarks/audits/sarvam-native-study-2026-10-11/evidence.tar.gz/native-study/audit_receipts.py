"""Offline whole-campaign dispatch/ledger/setup verification; no key access."""
import hashlib
import json
import sqlite3
import math
import statistics
import sys
from collections import Counter, defaultdict
from pathlib import Path


def digest(obj):
    text = json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(text.encode()).hexdigest()


def audit(root):
    root = Path(root)
    request_paths = {p.name.removesuffix(".request.json"): p for p in (root / "calls").glob("*.request.json")}
    receipt_paths = {p.name.removesuffix(".receipt.json"): p for p in (root / "calls").glob("*.receipt.json")}
    with sqlite3.connect(root / "calls/meter.sqlite") as db:
        ledger = {r[0]: r[1:] for r in db.execute("SELECT id,stage,reservation,charged,usage_cost,status FROM calls")}
    assert request_paths.keys() == receipt_paths.keys() == ledger.keys(), "dispatch/receipt/ledger inventory mismatch"
    ids, status, costs = set(), Counter(), Counter()
    latency = defaultdict(list)
    for job, path in request_paths.items():
        req = json.loads(path.read_text())
        rec = json.loads(receipt_paths[job].read_text())
        stage, reserved, charged, cost, state = ledger[job]
        body = json.loads(rec.get("body_text", "{}"))
        assert req["sha256"] == rec["request_sha256"] == digest(req["request"])
        assert req["endpoint"] == "https://api.sarvam.ai/v1/chat/completions"
        assert stage == job.split("-", 1)[0]
        max_input = {"sarvam-105b": 131072, "sarvam-105b-conversations": 32768}[req["request"]["model"]]
        assert reserved == (max_input * 15 + req["request"]["max_tokens"] * 60) * 5 // 4
        status[str(rec.get("status"))] += 1
        key = "|".join((stage, req["request"]["model"], str(req["request"]["reasoning_effort"])))
        assert rec["elapsed_seconds"] >= 0
        latency[key].append(rec["elapsed_seconds"])
        if rec.get("status") == 200:
            assert body["model"] == req["request"]["model"]
            assert body["id"] not in ids
            ids.add(body["id"])
            u = body["usage"]
            assert all(type(u[k]) is int and u[k] >= 0 for k in ["prompt_tokens", "completion_tokens", "total_tokens"])
            assert u["total_tokens"] == u["prompt_tokens"] + u["completion_tokens"]
            assert u["prompt_tokens"] <= max_input
            assert u["completion_tokens"] <= req["request"]["max_tokens"]
            expected = u["prompt_tokens"] * 15 + u["completion_tokens"] * 60
            assert (cost, charged, state) == (expected, (expected * 5 + 3) // 4, "known")
            costs["known_micro_inr"] += cost
        else:
            assert state == "unknown" and cost is None and charged == reserved
        costs["retained_with_headroom_micro_inr"] += charged
    assert costs["retained_with_headroom_micro_inr"] <= 6000000000
    expected_jobs = set()
    for phase in ["discovery", "discovery-continuation-001", "confirmation", "attribution"]:
        execution = json.loads((root / phase / "execution.json").read_text())
        for outcome in execution["outcomes"]:
            row = json.loads((root / phase / "episodes" / outcome["id"] / "result.json").read_text())
            assert row["terminal"] == outcome["terminal"]
            for jid in row["calls"]:
                assert jid not in expected_jobs
                expected_jobs.add(jid)
    setup = root / "setup"
    manifest = json.loads((setup / "manifest.json").read_text())
    for name, sha in manifest["source_sha256"].items():
        assert digest((setup / (name + ".frozen")).read_text()) == sha
    with sqlite3.connect(setup / "ordinary.sqlite") as db:
        assert db.execute("SELECT * FROM parcels").fetchall() == [("P-setup", "X7")]
    passed = 0
    for spec in manifest["jobs"]:
        jid = spec["id"]
        expected_jobs.add(jid)
        request = spec["request"]
        assert json.loads(request_paths[jid].read_text())["request"] == request
        response = json.loads(json.loads(receipt_paths[jid].read_text())["body_text"])
        if spec["kind"] == "tools":
            message = response["choices"][0]["message"]
            tc, = message["tool_calls"]
            assert tc["function"]["name"] == "get_counter"
            assert json.loads(tc["function"]["arguments"]) == {"parcel_id": "P-setup"}
            request["messages"] += [
                {"role": "assistant", "content": message.get("content"), "tool_calls": [tc]},
                {"role": "tool", "tool_call_id": tc["id"], "content": json.dumps({"counter": "X7"})},
            ]
            jid += "-answer"
            expected_jobs.add(jid)
            assert json.loads(request_paths[jid].read_text())["request"] == request
            response = json.loads(json.loads(receipt_paths[jid].read_text())["body_text"])
        stored = json.loads((setup / (spec["id"] + ".result.json")).read_text())
        final = response["choices"][0]
        assert stored["content"] == final["message"]["content"]
        expected = {"sum": 65} if spec["kind"] == "reasoning" else {"counter": "X7"}
        ok = final["finish_reason"] == "stop" and json.loads(stored["content"]) == expected
        assert stored["pass"] == ok
        passed += ok
    assert expected_jobs == request_paths.keys(), "unassigned or missing calls"
    latency_summary = {}
    for key, values in latency.items():
        values.sort()
        latency_summary[key] = {"calls": len(values), "median_seconds": statistics.median(values), "p95_seconds": values[math.ceil(len(values) * 0.95)-1], "maximum_seconds": max(values)}
    return {"api_call_latency_excluding_pacing_and_tool_time": latency_summary, "calls": len(request_paths), "unique_successful_provider_ids": len(ids), "http_status": dict(status), "setup_passed": passed, "setup_checks": len(manifest["jobs"]), "costs": dict(costs), "new_network_calls": 0, "scope": "Saved evidence integrity; not provider-signed attestation or independent semantic review"}


if __name__ == "__main__":
    def block(event, args):
        if event.startswith("socket."):
            raise RuntimeError("Network disabled")
    sys.addaudithook(block)
    print(json.dumps(audit(sys.argv[1]), indent=2))
