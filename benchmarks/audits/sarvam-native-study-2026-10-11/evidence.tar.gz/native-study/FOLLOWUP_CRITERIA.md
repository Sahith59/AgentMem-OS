# Follow-up choices must depend on the native evidence

This is a research decision aid, not an implemented product or another paid-run authorization.

| Observed pattern after fair configuration checks | Appropriate next control | What it does not justify |
| --- | --- | --- |
| Low reasoning fixes arithmetic or date interpretation | Native low profile plus a normal calculator/date function, recording latency and cost | A new memory engine for a computation error |
| Correct prose fails exact structured output | Small supported strict schema or a final response tool; keep original grades | Claiming the model forgot a fact or silently repairing historical scores |
| Update attempted without approval | Ordinary server-side authorization and a read/decision/action separation control | Claiming authorization gates are novel or blaming Sarvam's own backend |
| Tool success claimed without an actual receipt | Ordinary tool-result validation and truthful action-status rendering | Claiming that a memory database alone fixes execution |
| Stale textual version wins over a newer receipt | Test typed versions with ordinary SQL and the same model; fresh language/wording controls | Premature claim of a persistent-memory limitation |
| Current information is missing after a genuine restart/long history | Full original history, SQL retrieval and a bounded memory candidate with matched compute | Using our current all-records tool as a retrieval benchmark |
| Weakness appears only in native or mixed wording | Independent language review and meaning-matched English controls first | Treating a mistranslation or uncommon phrasing as a model defect |

A useful next corpus needs independently written workflows, more natural conversation turns, variations of task descriptions/tool contracts, and qualified review. Parameter expansion of the present10families must not substitute for diversity. Expand endpoint-supported languages in reviewable waves; Hindi/Telugu are the current measured slices, not the product boundary. Speech/STT and translation deserve separate attribution experiments so an upstream transcription error cannot masquerade as a memory error.

For a defensible product claim, first establish a failure that persists under an ordinary strong setup, demonstrate that the proposed mechanism addresses that cause, and confirm it on fresh reviewed workflows with all compute/cost/latency recorded. This study can supply reproducible counterexamples and prioritize those controls. It cannot establish novelty or customer demand by itself.


The present ordinary-SQL arm is a read-all-originals tool, not the strongest possible business integration. A normal authoritative current-state query could resolve version/order questions without asking a language model to choose among textual receipts. Likewise, an application should enforce approval before mutation rather than trusting model judgment alone. These ordinary controls must be tested before presenting either behavior as a reason for a new memory architecture. Give the model legitimate backend state, never evaluator labels disguised as a helpful fact store. Change response constraints, reasoning and state/tool design in separately attributable comparisons.

The input-overlap audit also narrows this study:637distinct visible inputs/700rows,186distinct confirmation inputs absent from discovery after deterministic de-duplication. Preserve those limits in any public pitch. A future diverse corpus must split by semantic/visible-input ancestry and independently authored workflows, not just identifier group IDs.
