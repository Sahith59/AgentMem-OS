"""Offline replay and accounting. Run from a checkout containing the frozen code."""

import argparse
import hashlib
import json
import socket
import sqlite3
import tempfile
from collections import defaultdict
from pathlib import Path

from benchmarks.sarvam_native_controls.engine import episode, grade
from benchmarks.sarvam_native_study import backend
from benchmarks.sarvam_native_study.transport import ENDPOINT, INPUT, OUTPUT, digest


def read(path):
    return json.loads(path.read_text())


def audit(root):
    # Runtime has no route to a network even if a future dependency attempts one.
    def denied(*args, **kwargs):
        raise RuntimeError("Offline verification forbids networking")

    socket.socket = denied
    socket.create_connection = denied
    provider_ids = set()
    totals = {"calls": 0, "known_microinr": 0, "retained_microinr": 0}
    phases = []
    for study in (root, root / "matched-attribution"):
        package = read(study / "probe/manifest.json")
        config = read(study / "budget.json")
        cases = {c["id"]: c for c in read(study / "probe-runtime.json")}
        gold = read(study / "probe-gold.json")
        review = read(study / "probe-review.json")
        assert digest(list(cases.values())) == package["runtime_sha256"]
        assert digest(gold) == review["gold_sha256"]
        assert digest(review) == package["review_sha256"]
        assert digest(config) == package["budget_sha256"]
        assert digest((study / "PROTOCOL.md").read_text()) == package["protocol_sha256"]
        for relative, expected in package["source_sha256"].items():
            assert digest((study / "probe/source" / relative).read_text()) == expected
            assert digest(Path(relative).read_text()) == expected
        assert read(study / "probe/started.json")["manifest_sha256"] == digest(package)
        results = []
        seen = set()
        for spec in package["jobs"]:
            case = cases[spec["case_id"]]
            original = read(study / "probe/episodes" / spec["id"] / "result.json")
            assert backend.state(study / "probe/episodes" / spec["id"] / "backend.sqlite") == original["final_backend"]
            with tempfile.TemporaryDirectory() as tmp:
                calls = []

                def dispatch(job, request):
                    assert job not in seen
                    saved = read(study / "calls" / (job + ".request.json"))
                    receipt = read(study / "calls" / (job + ".receipt.json"))
                    assert saved["endpoint"] == ENDPOINT
                    assert saved["request"] == request
                    assert digest(request) == saved["sha256"] == receipt["request_sha256"]
                    assert receipt["job"] == job and receipt["status"] == 200
                    body = json.loads(receipt["body_text"])
                    assert body["model"] == spec["model"]
                    assert body["id"] not in provider_ids
                    provider_ids.add(body["id"])
                    calls.append(job)
                    seen.add(job)
                    return body

                replay = episode(Path(tmp), spec, case, dispatch)
                assert replay == original
                assert calls == original["calls"]
            results.append({**spec, **grade(case, gold[spec["case_id"]], original),
                            "content": original.get("content"),
                            "tool_count": len(original["tool_trace"]),
                            "actual_state": original["final_backend"]})
        receipts = list((study / "calls").glob("*.receipt.json"))
        requests = list((study / "calls").glob("*.request.json"))
        assert {p.name.removesuffix(".receipt.json") for p in receipts} == seen
        assert {p.name.removesuffix(".request.json") for p in requests} == seen
        with sqlite3.connect(f"file:{study}/calls/meter.sqlite?mode=ro", uri=True) as db:
            ledger = db.execute("SELECT id,charged,usage_cost,status FROM calls").fetchall()
        assert {r[0] for r in ledger} == seen
        known = retained = 0
        timing = []
        usage_by_arm = defaultdict(lambda: {"calls": 0, "input_tokens": 0, "output_tokens": 0,
                                           "known_microinr": 0, "sum_request_seconds": 0.0})
        for job, charged, cost, status in ledger:
            receipt = read(study / "calls" / (job + ".receipt.json"))
            request = read(study / "calls" / (job + ".request.json"))["request"]
            usage = json.loads(receipt["body_text"])["usage"]
            assert usage["prompt_tokens"] + usage["completion_tokens"] == usage["total_tokens"]
            assert cost == usage["prompt_tokens"] * INPUT + usage["completion_tokens"] * OUTPUT
            assert charged == (cost * 5 + 3) // 4 and status == "known"
            known += cost
            retained += charged
            timing.append(read(study / "calls" / (job + ".dispatch.json"))["dispatch_time"])
            k = request["model"] + "|" + ("schema" if request.get("response_format", {}).get("type") == "json_schema" else "control")
            u = usage_by_arm[k]
            u["calls"] += 1
            u["input_tokens"] += usage["prompt_tokens"]
            u["output_tokens"] += usage["completion_tokens"]
            u["known_microinr"] += cost
            u["sum_request_seconds"] += receipt["elapsed_seconds"]
        assert retained <= config["phase_cap_microinr"]
        assert retained + config["prior_retained_microinr"] <= config["campaign_cap_microinr"]
        assert len(seen) <= config["stages"]["probe"]["calls"]
        counts = defaultdict(lambda: defaultdict(int))
        for row in results:
            g = counts[row["model"] + "|" + row["variant"]]
            g["episodes"] += 1
            for field in ("valid_output", "task_success", "backend_correct", "forbidden_mutation_attempt"):
                g[field] += row[field]
        timing.sort()
        phases.append({"phase": "initial_schema_probe" if study == root else "matched_attribution",
                       "rows": results, "groups": {k: dict(v) for k,v in counts.items()},
                       "usage": dict(usage_by_arm), "calls": len(seen),
                       "known_microinr": known, "retained_microinr": retained,
                       "maximum_dispatches_in_rolling_60s": max(sum(t <= s < t+60 for s in timing) for t in timing)})
        totals["calls"] += len(seen)
        totals["known_microinr"] += known
        totals["retained_microinr"] += retained
    original_budget = read(root / "budget.json")
    later_budget = read(root / "matched-attribution/budget.json")
    assert later_budget["prior_retained_microinr"] == original_budget["prior_retained_microinr"] + phases[0]["retained_microinr"]
    assert hashlib.sha256((root / "calls/meter.sqlite").read_bytes()).hexdigest() == later_budget["closed_schema_probe_ledger_sha256"]
    assert not read(root / "probe/gate.json")["pass"]
    assert not (root / "comparison/started.json").exists()
    assert not (root / "comparison/episodes").exists()
    assert len(read(root / "comparison/manifest.json")["jobs"]) == 288
    pairs = []
    indexed = {(r["case_id"], r["model"], r["variant"]): r for r in phases[1]["rows"]}
    for cid, model, variant in indexed:
        if variant != "control":
            continue
        a, b = indexed[cid, model, "control"], indexed[cid, model, "schema"]
        reqs = []
        for row in (a,b):
            req = read(root / "matched-attribution/calls" / (row["id"] + "-t0.request.json"))["request"]
            req.pop("response_format", None)
            reqs.append(req)
        assert reqs[0] == reqs[1]
        pairs.append({"case_id": cid, "model": model,
                      "task_gain": not a["task_success"] and b["task_success"],
                      "task_loss": a["task_success"] and not b["task_success"],
                      "control_tools": a["tool_count"], "schema_tools": b["tool_count"]})
    return {"verified": True, "network_blocked": True, "phases": phases,
            "paired_results": pairs, "new_calls": totals["calls"],
            "new_known_inr": totals["known_microinr"] / 1e6,
            "new_retained_inr": totals["retained_microinr"] / 1e6,
            "research_known_inr": (totals["known_microinr"] + original_budget["prior_known_microinr"]) / 1e6,
            "research_retained_inr": (totals["retained_microinr"] + original_budget["prior_retained_microinr"]) / 1e6,
            "provider_ids_unique": len(provider_ids), "broad_episodes_attempted": 0,
            "retries": 0, "limitations": "Same-code replay verifies integrity, not independent semantic truth."}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    result = audit(args.root)
    with args.output.open("x") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
        f.write("\n")
    print(json.dumps({k: v for k,v in result.items() if k not in ("phases", "paired_results")}))
