# Ordinary response-format control — frozen before calls

Founder approves the next evidence-first phase inside the standing INR6,000 research ceiling. This phase caps retained reservations at INR350, including INR40 setup and INR310 comparison. Carry prior retained INR86.675931: the combined bound is INR436.675931, not a new INR6,000 allowance. Published token rates remain INR15/M input and60/M output; reserve full context+8192 output with25% headroom, retain unknown usage, no cache discount. Not an invoice.

## Question and one change
Does the documented strict JSON-schema response format improve correct, usable answers without damaging tool execution? Ordinary native APIs and isolated SQLite only. No memory architecture, new model, prompt repair, extracted fact store, retry, or historical regrading.

Base105B uses low reasoning and Conversations explicitly null; each within-model pair keeps the same setting, temperature0,8192 output cap, full original evidence, four-call limit and actual SQLite backend. Models must be reported separately; this is not a causal model comparison. Control uses JSON-object mode for read-only and prompt JSON with action tools. Candidate changes ONLY response_format to the same small strict schema, including null,string,boolean and finite status values. Schema applies on every turn, including with tools. Compatibility must be verified; no silent fallback. Actual tokens/calls/latency remain measured because equal caps do not mean identical consumed compute.

## Excluded compatibility gate
Three distinct mechanics checks (unknown address, Hindi string, Telugu authorized mutation), two models:6 episodes,2 calls each maximum,12 requests maximum. Require6/6 strict expected responses, correct stored state, and actual successful tool receipts for the action. Any failure blocks the large comparison. Preserve all calls and diagnose before selecting a different control. Setup never contributes to the study score.

## Frozen comparison
24 authored situations,3 matched language renderings each:72 inputs,288 episodes,1152 request maximum.18 read-only situations and6 action situations. EN/HI/TE source/question text, with typed English backend field names in action records. Fresh wording and values, zero exact input overlap with the old700 or within this bank; known failure-family ancestry remains. All cases are synthetic and same-assistant authored/reviewed. No independent native annotation or real workflow holdout exists. Translations are correlated; do not claim72 independent workflows. No outcome-based exclusions or early stop for low accuracy. One pass, no retries.

Randomized interleaving seeded202610113; four workers, shared90RPM below founder-reported120RPM. Stop after two infrastructure errors in a batch of up to8, or a budget failure. Preserve all attempted/unattempted identities. Stop is not permission to rerun failed calls. Schemas unsupported with tools must not be silently changed after seeing answers.

## Grading and gates
Runtime never reads gold. Offline strict parse demands exactly answer,needs_clarification,action_status; duplicate keys,fences and translated keys are failures. Check exact response, actual final SQLite state, forbidden action attempts, and actual receipt for confirmed/rejected outcomes separately. Correct words do not establish a database update. Closed-attempt scenario explicitly asks for a real rejection receipt; this is an artificial diagnostic contract, not a recommended production action. Approval is intentionally still model-enforced in this comparison, so a schema gain is not a production authorization fix.

Report all paired gains AND losses by model,language,workflow and action/read-only. Mechanism lead: valid output improves at least8/72, strict task success has positive net change, and forbidden attempts do not increase in that model. Failing any condition is a failed lead, not hidden with a pooled score. Even passing is only a lead: no production promotion, general accuracy or novelty claim. A subsequent authoritative-state/permission control must be separately frozen. Never turn better formatting alone into a memory gain.

## Verified sources, 2026-10-11
Sarvam documents strict JSON-schema and alternative response tools, and recommends application validation: https://docs.sarvam.ai/api/api-guides-tutorials/chat-completion/overview . Feature availability with our exact combined tool/schema requests is tested by the excluded gate. https://docs.sarvam.ai/api-reference/chat/chat-completions-v1 confirms model IDs and explicitly disabling reasoning; the overview and reference disagree about the default, so neither arm relies on a default. https://docs.sarvam.ai/api/getting-started/pricing supports the rates. Existing research receipts remain immutable.
